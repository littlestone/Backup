
ALTER PROCEDURE dbo.sp_Insert_TarifClass AS
INSERT	DataWarehouse..TarifClass
		(TarifClassCode
,		TarifClassName
,		CanadianHarmonizedSystemTarifCode
,		AmericanHarmonizedSystemTarifCode
,		Active)
SELECT	SYSTBL_I34.DF_PL
,		ISNULL(SYSTBL_I34.DF_PL_DESC, '')
,		ISNULL(SYSTBL_I34.DF_PG, '')
,		ISNULL(SYSTBL_I34.GL_DB, '')
,		0
FROM		Source..SYSTBL_I34 SYSTBL_I34
		LEFT JOIN DataWarehouse..TarifClass TarifClass
			ON SYSTBL_I34.DF_PL = TarifClass.TarifClassCode
WHERE	TarifClass.TarifClassCode IS NULL
GO
