

ALTER  PROCEDURE dbo.sp_Update_InventoryTrail_Year
(		@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryTrail_' + @strYear)
BEGIN
	SELECT	@strSQL =	'UPDATE	DataWarehouse..InventoryTrail_' + @strYear + ' ' +
				'SET	GeneralLedgerGroupCode = ISNULL(INVTRAIL.GLG_CODE, '''')' + ' ' +
				',	TransactionQuantity = CASE' + ' ' +
				'		WHEN INVTRAIL.CHG_QTY IS NULL THEN CONVERT(numeric(19, 4), 0)' + ' ' +
				'		WHEN INVTRAIL.CHG_QTY LIKE ''[+-]'' THEN CONVERT(numeric(19, 4), 0)' + ' ' +
				'		ELSE CONVERT(numeric(19, 4), INVTRAIL.CHG_QTY)' + ' ' +
				'		END' + ' ' +
				',	UnitOfMeasureCode = ISNULL(INVTRAIL.UM, '''')' + ' ' +
				',	InventoryAmount = ISNULL(INVTRAIL.INVT_DLRS, 0)' + ' ' +
				',	ReceiptAmount = ISNULL(INVTRAIL.RECPT_DLRS, 0)' + ' ' +
				',	ReferenceNumber = ISNULL(INVTRAIL.REFERENCE, '''')' + ' ' +
				',	WarehouseCode = ISNULL(RIGHT(INVTRAIL.WHS, LEN(INVTRAIL.WHS) - CHARINDEX(''.'', INVTRAIL.WHS)), '''')' + ' ' +
				',	OnHandQuantity = ISNULL(LEFT(INVTRAIL.PREV_QOH + ''�'', CHARINDEX(''�'', INVTRAIL.PREV_QOH + ''�'') - 1), 0)' + ' ' +
				',	AdjustmentReasonCode = ISNULL(INVTRAIL.ADJ_RSN_CD, '''')' + ' ' +
				',	InventoryTransactionTypeCode = ISNULL(INVTRAIL.TRAN_CD, '''')' + ' ' +
				',	InventorySubTransactionTypeCode = ISNULL(INVTRAIL.SUB_TRAN_CD, '''')' + ' ' +
				',	UserCode = ISNULL(INVTRAIL.USER_ID, '''')' + ' ' +
				',	TransactionDateTime = ISNULL(LEFT(CONVERT(varchar(100), ISNULL(INVTRAIL.TRANS_DATE, INVTRAIL.ENTRY_DT), 120), CHARINDEX('' '', CONVERT(varchar(100), ISNULL(INVTRAIL.TRANS_DATE, INVTRAIL.ENTRY_DT), 120)) - 1), ''1900-01-01'') + '' '' + ISNULL(RIGHT(CONVERT(varchar(100), INVTRAIL.TRANS_TIME, 120), LEN(CONVERT(varchar(100), INVTRAIL.TRANS_TIME, 120)) - CHARINDEX('' '', CONVERT(varchar(100), INVTRAIL.TRANS_TIME, 120))), ''00:00:00'')' + ' ' +
				',	EntryDate = ISNULL(INVTRAIL.ENTRY_DT, ''1900-01-01'')' + ' ' +
				',	SalesPostingCode = ISNULL(INVTRAIL.SPC_CODE, '''')' + ' ' +
				',	RegisterTypeCode = CASE' + ' ' +
				'		WHEN INVTRAIL.REGISTER_NAME IS NOT NULL THEN INVTRAIL.REGISTER_NAME' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''40'' THEN ''MTLREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''41'' THEN ''RCVGREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''42'' THEN ''INVAJREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''44'' THEN ''MTLREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''49'' THEN ''ICEREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''50'' THEN ''INVAJREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''52'' THEN ''INVAJREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''60'' THEN ''RTRNREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''97'' THEN ''WTRREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''98'' THEN ''WTRREG''' + ' ' +
				'		ELSE ''''' + ' ' +
				'		END' + ' ' +
				',	RegisterNumber = ISNULL(INVTRAIL.REGISTER_KEY, '''')' + ' ' +
				',	AdjustmentReasonComment = ISNULL(LEFT(INVTRAIL.ADJ_REASON_COMMENTS, 200), '''')' + ' ' +
				'FROM	DataWarehouse..InventoryTrail_' + @strYear + ' InventoryTrail' + ' ' +
				'	INNER JOIN Source..INVTRAIL INVTRAIL' + ' ' +
				'		ON InventoryTrail.ComputerizedPartNumber = INVTRAIL.CPN' + ' ' +
				'		AND InventoryTrail.SequenceNumber = INVTRAIL.DF_SEQ' + ' ' +
				'WHERE	InventoryTrail.GeneralLedgerGroupCode != ISNULL(INVTRAIL.GLG_CODE, '''')' + ' ' +
				'OR	InventoryTrail.TransactionQuantity != CASE' + ' ' +
				'		WHEN INVTRAIL.CHG_QTY IS NULL THEN CONVERT(numeric(19, 4), 0)' + ' ' +
				'		WHEN INVTRAIL.CHG_QTY LIKE ''[+-]'' THEN CONVERT(numeric(19, 4), 0)' + ' ' +
				'		ELSE CONVERT(numeric(19, 4), INVTRAIL.CHG_QTY)' + ' ' +
				'		END' + ' ' +
				'OR	InventoryTrail.UnitOfMeasureCode != ISNULL(INVTRAIL.UM, '''')' + ' ' +
				'OR	InventoryTrail.InventoryAmount != ISNULL(INVTRAIL.INVT_DLRS, 0)' + ' ' +
				'OR	InventoryTrail.ReceiptAmount != ISNULL(INVTRAIL.RECPT_DLRS, 0)' + ' ' +
				'OR	InventoryTrail.ReferenceNumber != ISNULL(INVTRAIL.REFERENCE, '''')' + ' ' +
				'OR	InventoryTrail.WarehouseCode != ISNULL(RIGHT(INVTRAIL.WHS, LEN(INVTRAIL.WHS) - CHARINDEX(''.'', INVTRAIL.WHS)), '''')' + ' ' +
				'OR	InventoryTrail.OnHandQuantity != ISNULL(LEFT(INVTRAIL.PREV_QOH + ''�'', CHARINDEX(''�'', INVTRAIL.PREV_QOH + ''�'') - 1), 0)' + ' ' +
				'OR	InventoryTrail.AdjustmentReasonCode != ISNULL(INVTRAIL.ADJ_RSN_CD, '''')' + ' ' +
				'OR	InventoryTrail.InventoryTransactionTypeCode != ISNULL(INVTRAIL.TRAN_CD, '''')' + ' ' +
				'OR	InventoryTrail.InventorySubTransactionTypeCode != ISNULL(INVTRAIL.SUB_TRAN_CD, '''')' + ' ' +
				'OR	InventoryTrail.UserCode != ISNULL(INVTRAIL.USER_ID, '''')' + ' ' +
				'OR	InventoryTrail.TransactionDateTime != ISNULL(LEFT(CONVERT(varchar(100), ISNULL(INVTRAIL.TRANS_DATE, INVTRAIL.ENTRY_DT), 120), CHARINDEX('' '', CONVERT(varchar(100), ISNULL(INVTRAIL.TRANS_DATE, INVTRAIL.ENTRY_DT), 120)) - 1), ''1900-01-01'') + '' '' + ISNULL(RIGHT(CONVERT(varchar(100), INVTRAIL.TRANS_TIME, 120), LEN(CONVERT(varchar(100), INVTRAIL.TRANS_TIME, 120)) - CHARINDEX('' '', CONVERT(varchar(100), INVTRAIL.TRANS_TIME, 120))), ''00:00:00'')' + ' ' +
				'OR	InventoryTrail.EntryDate != ISNULL(INVTRAIL.ENTRY_DT, ''1900-01-01'')' + ' ' +
				'OR	InventoryTrail.SalesPostingCode != ISNULL(INVTRAIL.SPC_CODE, '''')' + ' ' +
				'OR	InventoryTrail.RegisterTypeCode != CASE' + ' ' +
				'		WHEN INVTRAIL.REGISTER_NAME IS NOT NULL THEN INVTRAIL.REGISTER_NAME' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''40'' THEN ''MTLREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''41'' THEN ''RCVGREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''42'' THEN ''INVAJREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''44'' THEN ''MTLREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''49'' THEN ''ICEREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''50'' THEN ''INVAJREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''52'' THEN ''INVAJREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''60'' THEN ''RTRNREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''97'' THEN ''WTRREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''98'' THEN ''WTRREG''' + ' ' +
				'		ELSE ''''' + ' ' +
				'		END' + ' ' +
				'OR	InventoryTrail.RegisterNumber != ISNULL(INVTRAIL.REGISTER_KEY, '''')' + ' ' +
				'OR	InventoryTrail.AdjustmentReasonComment != ISNULL(LEFT(INVTRAIL.ADJ_REASON_COMMENTS, 200), '''')'

	EXEC	(@strSQL)
END

GO
