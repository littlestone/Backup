SELECT	vw_SalesOrder.OrderNumber
,	CompanyCodeDivisionCode
,	vw_SalesOrder.CustomerCode
,	vw_SalesOrder.ShipToName
,	OrderDate
,	RequestDate
,	CustomerOrderDate
,	CustomerPurchaseOrderNumber
,	OperatorCode
,	CountryCode
,	SalesOfficeCode
,	CompleteDate
,	vw_SalesOrder.ComputerizedPartNumber
,	LineItemOrderQuantity
,	FillRateOrderQuantity
,	FillRateAllocatedQuantity
,	FillRateAllocatedDate
,	Product.ProductName
FROM	DataWarehouse..vw_SalesOrder_2008 vw_SalesOrder
	LEFT JOIN DataWarehouse..vw_BillOfLading vw_BillOfLading
		ON vw_SalesOrder.OrderNumber = vw_BillOfLading.OrderNumber
		AND vw_BillOfLading.ReleaseNumber = '1'
		AND vw_SalesOrder.LineItemNumber = vw_BillOfLading.LineItemNumber
	INNER JOIN Product
		ON vw_SalesOrder.ComputerizedPartNumber = Product.ComputerizedPartNumber
	INNER JOIN ProductLine ProductLine
		ON Product.ProductLineCode = ProductLine.ProductLineCode
	INNER JOIN ProductGroup ProductGroup
		ON Product.ProductGroupCode = ProductGroup.ProductGroupCode
WHERE	vw_SalesOrder.LineItemStatusCode != 'C'
AND	vw_SalesOrder.FillRateOrderQuantity != 0
AND	ProductGroup.ProductGroupCode = '4211'
AND	ProductLine.ProductLineCode = '035'
AND	Product.ProductCode = '035537'





