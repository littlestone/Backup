CREATE  VIEW dbo.vw_Invoice_2008_PipeSalesToRoyal
AS
SELECT DISTINCT BusinessUnit.BusinessUnitName + ' (' + BusinessUnit.BusinessUnitCode + ')' AS BusinessUnit
,	CustomerGroup.CustomerGroupName + ' (' + CustomerGroup.CustomerGroupCode + ')' AS CustomerBillToShipTo
,	Sales_MTD.FiscalPeriodCode
--,	Sales_MTD.CompanyCode
--,	Sales_MTD.DivisionCode
--,	Sales_MTD.CompanyCodeDivisionCode
--,	Sales_MTD.WarehouseCode
--,	Sales_MTD.CustomerCode
--,	Sales_MTD.CompanyCodeCustomerCode
--,	Sales_MTD.ComputerizedPartNumber
--,	Sales_MTD.WarehouseCodeComputerizedPartNumber
--,	Sales_MTD.CompanyCodeCustomerCodeComputerizedPartNumber
,	MarketSegment.MarketSegmentName + ' (' + MarketSegment.MarketSegmentCode + ')' AS MarketSegment
,	ProductGroup.ProductGroupCode + ' (' + ProductGroup.ProductGroupName + ')' AS ProductGroup
,	ProductLine.ProductLineCode + ' (' + ProductLine.ProductLineName + ')' AS ProductLine
,	Product.ProductCode + ' (' + Product.ProductName + ')' AS Product
,	ISNULL(vw_Invoice.InvoiceNumber, '') AS InvoiceNumber
,	ISNULL(vw_Invoice.OrderNumber, '') AS OrderNumber
--,	ISNULL(vw_Invoice.ReleaseNumber, '') AS ReleaseNumber
--,	ISNULL(vw_Invoice.InvoiceType, '') AS InvoiceType
,	ISNULL(vw_Invoice.InvoiceDate, '1900-01-01') AS InvoiceDate
,	ISNULL(vw_Invoice.BillOfLadingNumber, '') AS BillOfLadingNumber
,	ISNULL(vw_Invoice.LineItemNumber, '') AS LineItemNumber
--,	ISNULL(vw_Invoice.AdjustmentType, '') AS AdjustmentType
--,	ISNULL(vw_Invoice.SalesPostingCode, '') AS SalesPostingCode
--,	ISNULL(vw_Invoice.GeneralLedgerGroupCode, '') AS GeneralLedgerGroupCode
,	ISNULL(vw_Invoice.CustomerPurchaseOrderNumber, '') AS CustomerPurchaseOrderNumber
,	ISNULL(vw_Invoice.SalesOfficeCode, '') AS SalesOfficeCode
,	ISNULL(vw_Invoice.ShipToName, '') AS ShipToName
,	ISNULL(vw_Invoice.ShipToAddressLine1, '') AS ShipToAddressLine1
,	ISNULL(vw_Invoice.ShipToAddressLine2, '') AS ShipToAddressLine2
--,	ISNULL(vw_Invoice.ShipToAddressLine3, '') AS ShipToAddressLine3
--,	ISNULL(vw_Invoice.ShipToAddressLine4, '') AS ShipToAddressLine4
,	ISNULL(vw_Invoice.ShipToCountryCode, '') AS ShipToCountryCode
,	ISNULL(vw_Invoice.ShipToCityStateProvinceZipPostalCode, '') AS ShipToCityStateProvinceZipPostalCode
,	ISNULL(vw_Invoice.ShipToContactName, '') AS ShipToContactName
,	ISNULL(vw_Invoice.FreightOnBoardCode, '') AS FreightOnBoardCode
,	ISNULL(vw_Invoice.ShippingWeight, 0) AS ShipKgs
,	ROUND(ISNULL(vw_Invoice.ShippingWeight, 0) * 2.205, 2) AS ShipLbs
,	ISNULL(vw_Invoice.CompanyShippingQuantity, 0) AS ShipCompanyUOM
,	ISNULL(vw_Invoice.CustomerShippingQuantity, 0) AS ShipCustomerUOM
,	ROUND(ISNULL(vw_Invoice.ExtendedPriceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS PriceCAD
,	ROUND(ISNULL(vw_Invoice.ExtendedPriceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS PriceUSD
--,	ROUND(ISNULL(vw_Invoice.DiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS AdditionalDiscountCAD
--,	ROUND(ISNULL(vw_Invoice.DiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS AdditionalDiscountUSD
--,	ROUND(ISNULL(vw_Invoice.HandlingChargeAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS HandlingChargeCAD
--,	ROUND(ISNULL(vw_Invoice.HandlingChargeAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS HandlingChargeUSD
--,	ROUND(ISNULL(vw_Invoice.ExtendedCostAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS CostCAD
--,	ROUND(ISNULL(vw_Invoice.ExtendedCostAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS CostUSD
--,	ROUND(ISNULL(vw_Invoice.CashDiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS CashDiscountCAD
--,	ROUND(ISNULL(vw_Invoice.CashDiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS CashDiscountUSD
--,	ROUND(ISNULL(vw_Invoice.PrepaidFreightAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS PPDFreightCAD
--,	ROUND(ISNULL(vw_Invoice.PrepaidFreightAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS PPDFreightUSD
--,	ROUND(ISNULL(vw_Invoice.CustomerChargeFreightAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS PPCFreightCAD
--,	ROUND(ISNULL(vw_Invoice.CustomerChargeFreightAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS PPCFreightUSD
--,	ROUND(ISNULL(vw_Invoice.VolumeRebateAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS VolumeRebateCAD
--,	ROUND(ISNULL(vw_Invoice.VolumeRebateAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS VolumeRebateUSD
--,	ROUND(ISNULL(vw_Invoice.FreightAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS FreightAllowCAD
--,	ROUND(ISNULL(vw_Invoice.FreightAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS FreightAllowUSD
--,	ROUND(ISNULL(vw_Invoice.WarehouseAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS WhseAllowUSD
--,	ROUND(ISNULL(vw_Invoice.CommissionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS CommissionCAD
--,	ROUND(ISNULL(vw_Invoice.CommissionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS CommissionUSD
--,	ROUND(ISNULL(vw_Invoice.CompetitiveMonthlyAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS CMACMDCAD
--,	ROUND(ISNULL(vw_Invoice.CompetitiveMonthlyAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS CMACMDUSD
--,	ROUND(ISNULL(vw_Invoice.ProvincialSalesTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) +
--		ROUND(ISNULL(vw_Invoice.StateTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) +
--		ROUND(ISNULL(vw_Invoice.CountyTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) +
--		ROUND(ISNULL(vw_Invoice.CityTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS StateProvTaxCAD
--,	ROUND(ISNULL(vw_Invoice.ProvincialSalesTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) +
--		ROUND(ISNULL(vw_Invoice.StateTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) +
--		ROUND(ISNULL(vw_Invoice.CountyTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) +
--		ROUND(ISNULL(vw_Invoice.CityTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS StateProvTaxUSD
,	ROUND(ISNULL(vw_Invoice.ValueAddedTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS FederalTaxCAD
,	ROUND(ISNULL(vw_Invoice.ValueAddedTaxAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS FederalTaxUSD
--,	ROUND(ISNULL(vw_Invoice.VendorConcessionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS VendorConcessionCAD
--,	ROUND(ISNULL(vw_Invoice.VendorConcessionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS VendorConcessionUSD
,	Company.CurrencyCode AS CurrencyCode
,	ISNULL(CurrencyRateCAD.CurrencyRate, 1) AS CurrencyRateCAD
,	ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1) AS CurrencyRateUSD
FROM	DataMart..Sales_MTD_2008 Sales_MTD
	LEFT JOIN DataWarehouse..vw_Invoice_2008 vw_Invoice
		ON Sales_MTD.CompanyCode = vw_Invoice.CompanyCode
		AND Sales_MTD.DivisionCode = vw_Invoice.DivisionCode
		AND Sales_MTD.WarehouseCode = vw_Invoice.WarehouseCode
		AND Sales_MTD.CustomerCode = vw_Invoice.CustomerCode
		AND Sales_MTD.ComputerizedPartNumber = vw_Invoice.ComputerizedPartNumber
		AND Sales_MTD.FiscalPeriodCode = vw_Invoice.FiscalPeriodCode
	INNER JOIN DataWarehouse..Product Product
		ON vw_Invoice.ComputerizedPartNumber = Product.ComputerizedPartNumber
		AND Product.ProductCode = '071166'
	INNER JOIN DataWarehouse..ProductLine ProductLine
		ON Product.ProductLineCode = ProductLine.ProductLineCode
		AND ProductLine.ProductLineCode = '071'
--		OR ProductLine.ProductLineCode = '023'
	INNER JOIN DataWarehouse..ProductGroup ProductGroup
		ON ProductLine.ProductGroupCode = ProductGroup.ProductGroupCode
		AND ProductGroup.ProductGroupCode = '1193'
--		OR ProductGroup.ProductGroupCode = '1182'
	INNER JOIN DataWarehouse..SuperGroup SuperGroup
		ON ProductGroup.SuperGroupCode = SuperGroup.SuperGroupCode
	INNER JOIN DataWarehouse..ProductType ProductType
		ON SuperGroup.ProductTypeCode = ProductType.ProductTypeCode
	INNER JOIN DataWarehouse..MarketSegment MarketSegment
		ON ProductType.MarketSegmentCode = MarketSegment.MarketSegmentCode
		AND MarketSegment.MarketSegmentCode = '5'
--		OR MarketSegment.MarketSegmentCode = '1'
	INNER JOIN DataWarehouse..Company Company
		ON Sales_MTD.CompanyCode = Company.CompanyCode
	INNER JOIN DataWarehouse..ShipToCustomer ShipToCustomer
		ON vw_Invoice.CompanyCodeCustomerCode = ShipToCustomer.CompanyCodeShipToCustomerCode
	INNER JOIN DataWarehouse..BillToCustomer BillToCustomer
		ON ShipToCustomer.CompanyCodeBillToCustomerCode = BillToCustomer.CompanyCodeBillToCustomerCode
	INNER JOIN DataWarehouse..AccountReceivableCustomer AccountReceivableCustomer
		ON BillToCustomer.CompanyCodeAccountReceivableCustomerCode = AccountReceivableCustomer.CompanyCodeAccountReceivableCustomerCode
	INNER JOIN DataWarehouse..CustomerGroup CustomerGroup
		ON AccountReceivableCustomer.CustomerGroupCode = CustomerGroup.CustomerGroupCode
		AND CustomerGroup.CustomerGroupCode = '67600'
	INNER JOIN DataWarehouse..Region Region
		ON ShipToCustomer.RegionCode = Region.RegionCode
	INNER JOIN DataWarehouse..BusinessUnit BusinessUnit
		ON ShipToCustomer.BusinessUnitCode = BusinessUnit.BusinessUnitCode
		AND BusinessUnit.BusinessUnitCode = '013'
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateCAD
		ON Company.CurrencyCode = CurrencyRateCAD.FromCurrencyCode		AND 'CAD' = CurrencyRateCAD.ToCurrencyCode
		AND vw_Invoice.FiscalPeriodCode = CurrencyRateCAD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateUSD
		ON 'CAD' = CurrencyRateUSD.FromCurrencyCode
		AND 'USD' = CurrencyRateUSD.ToCurrencyCode
		AND vw_Invoice.FiscalPeriodCode = CurrencyRateUSD.FiscalPeriodCode






