SELECT MSOLAP_User UserName
,	CASE CHARINDEX('_', MSOLAP_Cube)
		WHEN 0 THEN MSOLAP_Cube
		ELSE LEFT(MSOLAP_Cube, CAST(CHARINDEX('_', MSOLAP_Cube) AS int) - 1) 
	END CubeName
,	LEFT(StartTime, 11) [Date]
--, 	SUM(SamplingRate) SamplingRate
,	CEILING(SUM(CASE Duration WHEN 0 THEN 0.5 ELSE Duration END) / 360) Duration
FROM QueryLog_History
--WHERE MSOLAP_User = 'IPEX\ronstr'
GROUP BY MSOLAP_User
,	CASE CHARINDEX('_', MSOLAP_Cube)
		WHEN 0 THEN MSOLAP_Cube
		ELSE LEFT(MSOLAP_Cube, CAST(CHARINDEX('_', MSOLAP_Cube) AS int) - 1) 
	END
,	LEFT(StartTime, 11)
ORDER BY Duration DESC


SELECT *
FROM QueryLog_History
WHERE Duration > 0
