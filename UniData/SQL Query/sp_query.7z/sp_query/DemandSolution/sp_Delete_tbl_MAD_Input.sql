CREATE PROCEDURE dbo.sp_Delete_tbl_MAD_Input 
AS

TRUNCATE TABLE	DemandSolutions..tbl_MAD_Input

GO
