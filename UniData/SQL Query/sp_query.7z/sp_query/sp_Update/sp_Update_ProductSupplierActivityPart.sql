ALTER PROCEDURE dbo.sp_Update_ProductSupplierActivityPart AS
UPDATE	DataWarehouse..ProductSupplierActivityPart
SET	SupplierItemCode = ISNULL(ITMSUPPACT_PART.SUPPLIER_PART, '')
FROM	Source..ITMSUPPACT_PART ITMSUPPACT_PART
	INNER JOIN DataWarehouse..ProductSupplierActivityPart ProductSupplierActivityPart
		ON ITMSUPPACT_PART.ID = ProductSupplierActivityPart.SupplierPartCodeCompanyCodeSupplierCode
		AND ITMSUPPACT_PART.SUPPLIER_PART = ProductSupplierActivityPart.SupplierItemCode
WHERE	ProductSupplierActivityPart.SupplierItemCode != ISNULL(ITMSUPPACT_PART.SUPPLIER_PART, '')


GO
