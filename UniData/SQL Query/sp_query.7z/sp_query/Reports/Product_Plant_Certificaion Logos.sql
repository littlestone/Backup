ALTER	VIEW dbo.vw_Product_Plant_CertificationLogos
AS
SELECT DISTINCT	ISNULL(ProductCode, '') ProductCode
,	ISNULL(ProductName, '') ProductName
,	ISNULL(ProductLabelViewField.Certification1File, '') Certification1File
,	ISNULL(ProductLabelViewField.Certification1Number, '') Certification1Number
,	ISNULL(ProductLabelViewField.Certification1Description, '') Certification1Description
,	ISNULL(ProductLabelViewField.Certification2File, '') Certification2File
,	ISNULL(ProductLabelViewField.Certification2Number, '') Certification2Number
,	ISNULL(ProductLabelViewField.Certification2Description, '') Certification2Description
,	ISNULL(ProductLabelViewField.Certification3File, '') Certification3File
,	ISNULL(ProductLabelViewField.Certification3Number, '') Certification3Number
,	ISNULL(ProductLabelViewField.Certification3Description, '') Certification3Description
,	ISNULL(ProductLabelViewField.Certification4File, '') Certification4File
,	ISNULL(ProductLabelViewField.Certification4Number, '') Certification4Number
,	ISNULL(ProductLabelViewField.Certification4Description, '') Certification4Description
,	ISNULL(ProductLabelViewField.Certification5File, '') Certification5File
,	ISNULL(ProductLabelViewField.Certification5Number, '') Certification5Number
,	ISNULL(ProductLabelViewField.Certification5Description, '') Certification5Description
,	ISNULL(ProductLabelViewField.Certification6File, '') Certification6File
,	ISNULL(ProductLabelViewField.Certification6Number, '') Certification6Number
,	ISNULL(ProductLabelViewField.Certification6Description, '') Certification6Description
FROM DataWarehouse..Product Product
	LEFT JOIN DataWarehouse..PlantLabelViewField PlantLabelViewField
		ON Product.ComputerizedPartNumber = PlantLabelViewField.ComputerizedPartNumber
	LEFT JOIN DataWarehouse..ProductLabelViewField  ProductLabelViewField
		ON Product.ComputerizedPartNumber = ProductLabelViewField.ComputerizedPartNumber
	CROSS JOIN DataWarehouse..Plant Plant
WHERE ProductLabelViewField.Certification1File IN ('ITS.PCX', 'WARHERBC.PCX', 'WH_LOGO.PCX')
OR ProductLabelViewField.Certification2File IN ('ITS.PCX', 'WARHERBC.PCX', 'WH_LOGO.PCX')
OR ProductLabelViewField.Certification3File IN ('ITS.PCX', 'WARHERBC.PCX', 'WH_LOGO.PCX')
OR ProductLabelViewField.Certification4File IN ('ITS.PCX', 'WARHERBC.PCX', 'WH_LOGO.PCX')
OR ProductLabelViewField.Certification5File IN ('ITS.PCX', 'WARHERBC.PCX', 'WH_LOGO.PCX')
OR ProductLabelViewField.Certification6File IN ('ITS.PCX', 'WARHERBC.PCX', 'WH_LOGO.PCX')