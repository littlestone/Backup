ALTER      PROCEDURE dbo.sp_Insert_PurchaseOrderDetailDelivery_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetailDelivery_' + @strYear)
BEGIN
	SELECT	@strSQL =	'INSERT	DataWarehouse..PurchaseOrderDetailDelivery_' + @strYear + ' ' +
				'	(PurchaseOrderNumber' + ' ' +
				',	ReferenceNumber' + ' ' +
				',	ScheduleDeliveryDate' + ' ' +
				',	CompanyScheduleQuantity' + ' ' +
				',	CompanyBalanceQuantity' + ' ' +
				',	CompanyUnitCost' + ' ' +
				',	ReferenceInfo' + ' ' +
				',	SupplierScheduleQuantity' + ' ' +
				',	SupplierBalanceQuantity' + ' ' +
				',	DockDate' + ' ' +
				',	SupplierUnitPrice)' + ' ' +
				'SELECT	CASE WHEN LEN(PODET_DELIVERY.ID) <= 5 THEN PODET_DELIVERY.ID ELSE RIGHT(PODET_DELIVERY.ID, LEN(PODET_DELIVERY.ID) - 5) END' + ' ' +
				',	CASE WHEN LEN(PODET_DELIVERY.ID) <= 5 THEN '''' ELSE LEFT(PODET_DELIVERY.ID, 5) END' + ' ' +
				',	CASE WHEN PODET_DELIVERY.SCHED_DEL_DT IS NULL THEN ''1900-01-01''' + ' ' +
				'	     WHEN PODET_DELIVERY.SCHED_DEL_DT < ''1900-01-01'' THEN ''1900-01-01''' + ' ' +
				'	     WHEN PODET_DELIVERY.SCHED_DEL_DT > ''2075-01-01'' THEN ''1900-01-01''' + ' ' +
				'	     ELSE PODET_DELIVERY.SCHED_DEL_DT' + ' ' +
				'	END' + ' ' +
				',	ISNULL(PODET_DELIVERY.SCHED_QTY, 0)' + ' ' +
				',	ISNULL(PODET_DELIVERY.BAL_QTY, 0)' + ' ' +
				',	ISNULL(PODET_DELIVERY.UNIT_COST, 0)' + ' ' +
				',	ISNULL(PODET_DELIVERY.REF_INFO, '''')' + ' ' +
				',	ISNULL(PODET_DELIVERY.PCH_QTY, 0)' + ' ' +
				',	ISNULL(PODET_DELIVERY.PCH_BAL_QTY, 0)' + ' ' +
				',	CASE WHEN PODET_DELIVERY.DOCK_DATE IS NULL THEN ''1900-01-01''' + ' ' +
				'	     WHEN PODET_DELIVERY.DOCK_DATE < ''1900-01-01'' THEN ''1900-01-01''' + ' ' +
				'	     WHEN PODET_DELIVERY.DOCK_DATE > ''2075-01-01'' THEN ''1900-01-01''' + ' ' +
				'	     ELSE PODET_DELIVERY.DOCK_DATE' + ' ' +
				'	END' + ' ' +
				',	ISNULL(PODET_DELIVERY.FOREIGN_UN_PR, 0)' + ' ' +
				'FROM	Source..PODET_DELIVERY PODET_DELIVERY' + ' ' +
				'	LEFT JOIN Source..POHDR POHDR' + ' ' +
				'		ON CASE WHEN LEN(PODET_DELIVERY.ID) <= 5 THEN PODET_DELIVERY.ID ELSE RIGHT(PODET_DELIVERY.ID, LEN(PODET_DELIVERY.ID) - 5) END = POHDR.PO_NBR' + ' ' +
				'	LEFT JOIN DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' +
				'		ON POHDR.PO_NBR = PurchaseOrderHeader.PurchaseOrderNumber' + ' ' +
				'		AND ISNULL(POHDR.PO_DT, ''1900-01-01'') = PurchaseOrderHeader.PurchaseOrderDate' + ' ' +
				'	LEFT JOIN DataWarehouse..PurchaseOrderDetailDelivery_' + @strYear + ' PurchaseOrderDetailDelivery' + ' ' +
				'		ON CASE WHEN LEN(PODET_DELIVERY.ID) <= 5 THEN PODET_DELIVERY.ID ELSE RIGHT(PODET_DELIVERY.ID, LEN(PODET_DELIVERY.ID) - 5) END = PurchaseOrderDetailDelivery.PurchaseOrderNumber' + ' ' +
				'		AND CASE WHEN LEN(PODET_DELIVERY.ID) <= 5 THEN '''' ELSE LEFT(PODET_DELIVERY.ID, 5) END = PurchaseOrderDetailDelivery.ReferenceNumber' + ' ' +
				'		AND CASE WHEN PODET_DELIVERY.SCHED_DEL_DT IS NULL THEN ''1900-01-01'' WHEN PODET_DELIVERY.SCHED_DEL_DT < ''1900-01-01'' THEN ''1900-01-01'' WHEN PODET_DELIVERY.SCHED_DEL_DT > ''2075-01-01'' THEN ''1900-01-01'' ELSE PODET_DELIVERY.SCHED_DEL_DT END = PurchaseOrderDetailDelivery.ScheduleDeliveryDate' + ' ' +
				'WHERE	POHDR.FISCAL_PERIOD LIKE ''' + @strYear + '%''' + ' ' +
				'AND	PurchaseOrderDetailDelivery.PurchaseOrderNumber IS NULL' + ' ' +
				'AND	PurchaseOrderDetailDelivery.ReferenceNumber IS NULL' + ' ' +
				'AND	PurchaseOrderDetailDelivery.ScheduleDeliveryDate IS NULL'

	EXEC	(@strSQL)
END


GO
