


ALTER  PROCEDURE dbo.sp_Update_InventoryWarehouse_Month
(		@strMonth	varchar(7))
WITH RECOMPILE
AS

DECLARE	@strSQL		varchar(8000)
,	@strYear	varchar(4)

SELECT	@strYear = LEFT(@strMonth, CHARINDEX('-', @strMonth) - 1)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryWarehouse_' + @strYear)
BEGIN
	SELECT	@strSQL =	'UPDATE	DataWarehouse..InventoryWarehouse_' + @strYear + ' ' +
				'SET	DefaultABCClassCode = ISNULL(INVWHS.ABC_CALC, '''')' + ' ' +
				',	OnHandQuantity = ISNULL(INVWHS.QTY_ON_HAND, 0)' + ' ' +
				',	InMaterialReviewBoardQuantity = ISNULL(INVWHS_MRB.QTY_ON_HAND, 0)' + ' ' +
				',	InReceiptInInspectionQuantity = ISNULL(INVWHS_RII.QTY_ON_HAND, 0)' + ' ' +
				',	InTransitQuantity = ISNULL(INVWHS.IN_TRANSIT_QTY, 0)' + ' ' +
				',	BookedQuantity = ISNULL(INVWHS.BOOKED_QTY, 0)' + ' ' +
				',	ManufacturingAllocationQuantity = ISNULL(INVWHS.MFG_ALLOC, 0)' + ' ' +
				',	LastActivityDate = ISNULL(INVWHS.LAST_ACT_DT, ''1900-01-01'')' + ' ' +
				',	ReorderQuantity = ISNULL(INVWHS.REORDER_QTY, 0)' + ' ' +
				',	OverrideABCClassCode = ISNULL(INVWHS.ABC_OVERIDE, '''')' + ' ' +
				',	ABCClassCode = ISNULL(INVWHS.ABC_OVERIDE, ISNULL(INVWHS.ABC_CALC, ''''))' + ' ' +
				',	PurchaseConsignmentCode = ISNULL(INVWHS.PUR_CON_FLAG, '''')' + ' ' +
				',	AllocationQuantity = ISNULL(INVWHS.ALLOCATED_QTY, 0)' + ' ' +
				'FROM	DataWarehouse..InventoryWarehouse_' + @strYear + ' InventoryWarehouse' + ' ' +
				'	INNER JOIN Source..INVWHS INVWHS' + ' ' +
				'		ON InventoryWarehouse.WarehouseCode = INVWHS.WAREHOUSE' + ' ' +
				'		AND InventoryWarehouse.ComputerizedPartNumber = INVWHS.CPN' + ' ' +
				'	LEFT JOIN Source..INVWHS INVWHS_MRB' + ' ' +
				'		ON INVWHS_MRB.WAREHOUSE LIKE ''MRB%''' + ' ' +
				'		AND INVWHS.WAREHOUSE = RIGHT(INVWHS_MRB.WAREHOUSE, LEN(INVWHS_MRB.WAREHOUSE) - CHARINDEX(''.'', INVWHS_MRB.WAREHOUSE))' + ' ' +
				'		AND INVWHS.CPN = INVWHS_MRB.CPN' + ' ' +
				'	LEFT JOIN Source..INVWHS INVWHS_RII' + ' ' +
				'		ON INVWHS_RII.WAREHOUSE LIKE ''RII%''' + ' ' +
				'		AND INVWHS.WAREHOUSE = RIGHT(INVWHS_RII.WAREHOUSE, LEN(INVWHS_RII.WAREHOUSE) - CHARINDEX(''.'', INVWHS_RII.WAREHOUSE))' + ' ' +
				'		AND INVWHS.CPN = INVWHS_RII.CPN' + ' ' +
				'WHERE	InventoryWarehouse.FiscalPeriodCode = ''' + @strMonth + '''' + ' ' +
				'AND	(InventoryWarehouse.DefaultABCClassCode != ISNULL(INVWHS.ABC_CALC, '''')' + ' ' +
				'OR	InventoryWarehouse.OnHandQuantity != ISNULL(INVWHS.QTY_ON_HAND, 0)' + ' ' +
				'OR	InventoryWarehouse.InMaterialReviewBoardQuantity != ISNULL(INVWHS_MRB.QTY_ON_HAND, 0)' + ' ' +
				'OR	InventoryWarehouse.InReceiptInInspectionQuantity != ISNULL(INVWHS_RII.QTY_ON_HAND, 0)' + ' ' +
				'OR	InventoryWarehouse.InTransitQuantity != ISNULL(INVWHS.IN_TRANSIT_QTY, 0)' + ' ' +
				'OR	InventoryWarehouse.BookedQuantity != ISNULL(INVWHS.BOOKED_QTY, 0)' + ' ' +
				'OR	InventoryWarehouse.ManufacturingAllocationQuantity != ISNULL(INVWHS.MFG_ALLOC, 0)' + ' ' +
				'OR	InventoryWarehouse.LastActivityDate != ISNULL(INVWHS.LAST_ACT_DT, ''1900-01-01'')' + ' ' +
				'OR	InventoryWarehouse.ReorderQuantity != ISNULL(INVWHS.REORDER_QTY, 0)' + ' ' +
				'OR	InventoryWarehouse.OverrideABCClassCode != ISNULL(INVWHS.ABC_OVERIDE, '''')' + ' ' +
				'OR	InventoryWarehouse.ABCClassCode != ISNULL(INVWHS.ABC_OVERIDE, ISNULL(INVWHS.ABC_CALC, ''''))' + ' ' +
				'OR	InventoryWarehouse.PurchaseConsignmentCode != ISNULL(INVWHS.PUR_CON_FLAG, '''')' + ' ' +
				'OR	InventoryWarehouse.AllocationQuantity != ISNULL(INVWHS.ALLOCATED_QTY, 0))'
	
	EXEC	(@strSQL)
END
GO
