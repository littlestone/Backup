DECLARE @counter int
DECLARE @low decimal(8,2)
DECLARE @high decimal(8,2)
DECLARE @code int
SET @counter = 5
SET @low = 100.01
SET @high = 125.00
SET @code = 1

WHILE @counter <= 4000
BEGIN
	IF 1 = @counter % 4
	    SET @code = @code + 1
	INSERT OrderValueThirdLevel
	VALUES(@counter, '$' + CAST(@low as varchar) + ' - $' + CAST(@high as varchar), CAST(@code as varchar), 1)
	
	SET @counter = @counter + 1
	SET @low = @low + 25
	SET @high = @high + 25
END




-- Generate sequential number

DECLARE @counter int
SET @counter = 0

DECLARE @OrderValueSecondLevelCode varchar(100)
DECLARE @OrderValueName varchar(100)
DECLARE @OrderValueCode varchar(100)
DECLARE @Active varchar(100)

DECLARE CustList 
CURSOR FOR
SELECT OrderValueSecondLevelCode, OrderValueName, OrderValueCode, Active
FROM OrderValueSecondLevel

OPEN CustList

FETCH NEXT FROM CustList INTO @OrderValueSecondLevelCode, @OrderValueName, @OrderValueCode, @Active
WHILE (@@FETCH_STATUS = 0)
BEGIN
	UPDATE OrderValueSecondLevel
	SET OrderValueSecondLevelCode = @counter
	WHERE	OrderValueName = @OrderValueName

	SET @counter = @counter + 1
 	FETCH NEXT FROM CustList INTO @OrderValueSecondLevelCode, @OrderValueName, @OrderValueCode, @Active
END

CLOSE CustList
DEALLOCATE CustList

