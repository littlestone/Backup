ALTER PROCEDURE dbo.sp_Insert_GeneralLedgerAccount
AS

INSERT	DataWarehouse..GeneralLedgerAccount
	(CompanyCode
,	DivisionCode
,	WarehouseCode
,	BaseAccountCode
,	DepartmentCode
,	GeneralLedgerAccountName
,	GeneralLedgerTypeCode
,	CompanyCodeDivisionCode
,	GeneralLedgerAccountCode
,	Active)
SELECT	GLACTHST.IDPART1
,	GLACTHST.IDPART2
,	GLACTHST.IDPART3
,	GLACTHST.IDBASE
,	ISNULL(GLACTHST.IDPART4, '')
,	ISNULL(GLACTHST.ACCT_DESC1, '')
,	ISNULL(GLACTHST.GLTYPE, '')
,	GLACTHST.IDPART1 + '*' + GLACTHST.IDPART2
,	GLACTHST.IDPART1 + ISNULL('.' + GLACTHST.IDPART2, '') + ISNULL('.' + GLACTHST.IDPART3, '') + ISNULL('.' + GLACTHST.IDBASE, '') + ISNULL('.' + GLACTHST.IDPART4, '')
,	0
FROM	Source..GLACTHST GLACTHST
	LEFT JOIN DataWarehouse..GeneralLedgerAccount GeneralLedgerAccount
		ON GLACTHST.IDPART1 = GeneralLedgerAccount.CompanyCode
		AND GLACTHST.IDPART2 = GeneralLedgerAccount.DivisionCode
		AND GLACTHST.IDPART3 = GeneralLedgerAccount.WarehouseCode
		AND GLACTHST.IDBASE = GeneralLedgerAccount.BaseAccountCode
		AND ISNULL(GLACTHST.IDPART4, '') = GeneralLedgerAccount.DepartmentCode
WHERE	GeneralLedgerAccount.CompanyCode IS NULL
AND	GeneralLedgerAccount.DivisionCode IS NULL
AND	GeneralLedgerAccount.WarehouseCode IS NULL
AND	GeneralLedgerAccount.BaseAccountCode IS NULL
AND	GeneralLedgerAccount.DepartmentCode IS NULL

INSERT	DataWarehouse..GeneralLedgerAccount
	(CompanyCode
,	DivisionCode
,	WarehouseCode
,	BaseAccountCode
,	DepartmentCode
,	GeneralLedgerAccountName
,	GeneralLedgerTypeCode
,	CompanyCodeDivisionCode
,	GeneralLedgerAccountCode
,	Active)
SELECT	GLACT.IDPART1
,	GLACT.IDPART2
,	GLACT.IDPART3
,	GLACT.IDBASE
,	ISNULL(GLACT.IDPART4, '')
,	ISNULL(GLACT.ACCT_DESC1, '')
,	ISNULL(GLACT.GLTYPE, '')
,	GLACT.IDPART1 + '*' + GLACT.IDPART2
,	GLACT.IDPART1 + ISNULL('.' + GLACT.IDPART2, '') + ISNULL('.' + GLACT.IDPART3, '') + ISNULL('.' + GLACT.IDBASE, '') + ISNULL('.' + GLACT.IDPART4, '')
,	0
FROM	Source..GLACT GLACT
	LEFT JOIN DataWarehouse..GeneralLedgerAccount GeneralLedgerAccount
		ON GLACT.IDPART1 = GeneralLedgerAccount.CompanyCode
		AND GLACT.IDPART2 = GeneralLedgerAccount.DivisionCode
		AND GLACT.IDPART3 = GeneralLedgerAccount.WarehouseCode
		AND GLACT.IDBASE = GeneralLedgerAccount.BaseAccountCode
		AND ISNULL(GLACT.IDPART4, '') = GeneralLedgerAccount.DepartmentCode
WHERE	GeneralLedgerAccount.CompanyCode IS NULL
AND	GeneralLedgerAccount.DivisionCode IS NULL
AND	GeneralLedgerAccount.WarehouseCode IS NULL
AND	GeneralLedgerAccount.BaseAccountCode IS NULL
AND	GeneralLedgerAccount.DepartmentCode IS NULL
GO
