ALTER      PROCEDURE dbo.sp_Insert_PurchaseOrderHeaderLineItem_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderHeaderLineItem_' + @strYear)
BEGIN
	SELECT	@strSQL =	'INSERT	DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' ' +
				'	(PurchaseOrderNumber' + ' ' +
				',	LineItemNumber' + ' ' +
				',	ReferenceNumber' + ' ' +
				',	LineItemStatusCode)' + ' ' +
				'SELECT	POHDR_LINEITEM.PO_NBR' + ' ' +
				',	POHDR_LINEITEM.ITEM_NBR' + ' ' +
				',	ISNULL(POHDR_LINEITEM.REF, '''')' + ' ' +
				',	ISNULL(POHDR_LINEITEM.ITEM_COMPL, '''')' + ' ' +
				'FROM	Source..POHDR_LINEITEM POHDR_LINEITEM' + ' ' +
				'	LEFT JOIN Source..POHDR POHDR' + ' ' +
				'		ON POHDR_LINEITEM.PO_NBR = POHDR.PO_NBR' + ' ' +
				'	LEFT JOIN DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' +
				'		ON POHDR.PO_NBR = PurchaseOrderHeader.PurchaseOrderNumber' + ' ' +
				'		AND ISNULL(POHDR.PO_DT, ''1900-01-01'') = PurchaseOrderHeader.PurchaseOrderDate' + ' ' +
				'	LEFT JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' PurchaseOrderHeaderLineItem' + ' ' +
				'		ON POHDR_LINEITEM.PO_NBR = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
				'		AND POHDR_LINEITEM.ITEM_NBR = PurchaseOrderHeaderLineItem.LineItemNumber' + ' ' +
				'WHERE	POHDR.FISCAL_PERIOD LIKE ''' + @strYear + '%''' + ' ' +
				'AND	PurchaseOrderHeaderLineItem.PurchaseOrderNumber IS NULL' + ' ' +
				'AND	PurchaseOrderHeaderLineItem.LineItemNumber IS NULL'

	EXEC	(@strSQL)
END
GO
