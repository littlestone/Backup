CREATE PROCEDURE gen_MAD_Output
AS
BEGIN
     SET NOCOUNT ON

     TRUNCATE TABLE tbl_MAD_Output

     -------------------------------------------------------
     --  Calculate Avg for each Row  
     -------------------------------------------------------
     INSERT INTO tbl_MAD_Output
     SELECT  id
          , ISNULL(item,0)
          , ISNULL(company, 0)
          , ISNULL(division, 0)
          , ISNULL(sold, 0)
          , corporation
          , department
          , ship_to
          ,    (                history_1  +  history_2 +  history_3 +  history_4 +  history_5 +  history_6 +  history_7 
                 + history_8  + history_9  + history_10 + history_11 + history_12 + history_13 + history_14 + history_15 
                 + history_16 + history_17 + history_18 + history_19 + history_20 + history_21 + history_22 + history_23 
                 + history_24 + history_25 + history_26 + history_27 + history_28 + history_29 + history_30 + history_31
                 + history_32 + history_33 + history_34 + history_35 + history_36 + history_37 + history_38 + history_39
                 + history_40 + history_41 ) / 41.0    -- history_avg
          , 0                                          -- StdDev
          , 0		                -- StdDev%
          , 0                                          -- Mean Avg Dev%
          , 0                                          -- total_run
          , 0                                          -- total_percent
          , ''                                           -- classificiation ABC
       FROM tbl_MAD_Input




     -------------------------------------------------------
     -- Remove A Rows that have Avg of 0 
     -------------------------------------------------------
     DELETE FROM tbl_MAD_Output
       WHERE item IS NULL
          OR history_avg = 0 



     -------------------------------------------------------
     -- Calculate StdDev for each row
     -------------------------------------------------------
     UPDATE tbl_MAD_Output
        SET history_stdDev = SQRT(  (SQUARE( history_1 - tbl_MAD_Output.history_avg) 
                                   + SQUARE( history_2 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_3 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_4 - tbl_MAD_Output.history_avg) 
                                   + SQUARE( history_5 - tbl_MAD_Output.history_avg) 
                                   + SQUARE( history_6 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_7 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_8 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_9 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_10 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_11 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_12 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_13 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_14 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_15 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_16 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_17 - tbl_MAD_Output.history_avg) 
                                   + SQUARE(history_18 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_19 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_20 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_21 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_22 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_23 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_24 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_25 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_26 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_27 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_28 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_29 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_30 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_31 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_32 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_33 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_34 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_35 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_36 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_37 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_38 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_39 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_40 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_41 - tbl_MAD_Output.history_avg) ) / (41.0 - 1.0) )
        FROM tbl_MAD_Input
       WHERE tbl_MAD_Input.id = tbl_MAD_Output.id


     -------------------------------------------------------
     -- Calculate StdDev% & MAD%
     -------------------------------------------------------
     UPDATE tbl_MAD_Output
        SET percent_stdDev  = history_stdDev  / history_avg 
           ,percent_MAD     = history_stdDev  / history_avg  / 1.25



     -------------------------------------------------------
     -- Calculate Running Total of Avg, sorted by StdDev%
     -------------------------------------------------------

     -- Have to order the table by StdDev%
     SELECT id, percent_stddev, history_avg, total_run
       INTO #tbl_mad_output_temp
       FROM tbl_mad_output
      ORDER BY percent_stddev


     -- Do the Running Total on history_avg based on sort of StdDev%
     DECLARE @RRT FLOAT
     SET @RRT = 0
     UPDATE #tbl_mad_output_temp
        SET @RRT = total_run = @RRT + history_avg


     -- Put Back the results
     UPDATE  tbl_mad_output
        SET total_run = #tbl_mad_output_temp.total_run
       FROM #tbl_mad_output_temp
      WHERE tbl_mad_output.id = #tbl_mad_output_temp.id

 
     -- Get Rid of Temp Tables
     DROP TABLE #tbl_mad_output_temp



     -------------------------------------------------------
     --  Get The Sum Avg Total
     -------------------------------------------------------
     DECLARE @fltAvgSumTotal AS FLOAT
     SELECT @fltAvgSumTotal  = SUM(history_avg) 
       FROM tbl_MAD_Output



     -------------------------------------------------------
     -- Calculate the %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output 
        SET total_percent = total_run / @fltAvgSumTotal * 100
  

     -------------------------------------------------------
     -- Calculate the Code Classification based on %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output  SET class = 'A' WHERE                         total_percent  <= 10
     UPDATE tbl_MAD_Output  SET class = 'B' WHERE 10 < total_percent  AND total_percent  <= 20
     UPDATE tbl_MAD_Output  SET class = 'C' WHERE 20 < total_percent  AND total_percent  <= 30
     UPDATE tbl_MAD_Output  SET class = 'D' WHERE 30 < total_percent  AND total_percent  <= 40
     UPDATE tbl_MAD_Output  SET class = 'E' WHERE 40 < total_percent  AND total_percent  <= 50
     UPDATE tbl_MAD_Output  SET class = 'F' WHERE 50 < total_percent  AND total_percent  <= 60
     UPDATE tbl_MAD_Output  SET class = 'G' WHERE 60 < total_percent  AND total_percent  <= 70
     UPDATE tbl_MAD_Output  SET class = 'H' WHERE 70 < total_percent  AND total_percent  <= 80
     UPDATE tbl_MAD_Output  SET class = 'I' WHERE 80 < total_percent  AND total_percent  <= 90
     UPDATE tbl_MAD_Output  SET class = 'J' WHERE 90 < total_percent  AND total_percent  <= 100
END
GO
