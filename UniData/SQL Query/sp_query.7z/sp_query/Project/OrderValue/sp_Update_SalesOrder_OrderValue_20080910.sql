
CREATE   PROCEDURE sp_Update_SalesOrder_OrderValue_20080910
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'SalesOrder_' + @strYear + '_New')
		EXEC	sp_Update_SalesOrder_OrderValue_Year_20080910 @strYear

	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear





GO