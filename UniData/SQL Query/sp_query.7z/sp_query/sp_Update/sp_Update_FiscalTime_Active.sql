

ALTER    PROCEDURE dbo.sp_Update_FiscalTime_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..FiscalTime
SET	Active = 0
WHERE	NULLIF(FiscalPeriodCode, '') IS NOT NULL

SELECT	FiscalTime.FiscalPeriodCode
INTO	#FiscalTime
FROM	DataWarehouse..FiscalTime FiscalTime
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryWarehouse_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FiscalTime' + ' ' +
					'	(FiscalPeriodCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	InventoryWarehouse.FiscalPeriodCode' + ' ' +
					'FROM	DataWarehouse..InventoryWarehouse_' + @strYear + ' InventoryWarehouse'
		EXEC	(@strSQL)
	END
	
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Budget_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FiscalTime' + ' ' +
					'	(FiscalPeriodCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	Budget.FiscalPeriodCode' + ' ' +
					'FROM	DataWarehouse..Budget_' + @strYear + ' Budget'
		EXEC	(@strSQL)
	END
	
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'BillOfLading_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FiscalTime' + ' ' +
					'	(FiscalPeriodCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	BillOfLading.FiscalPeriodCode' + ' ' +
					'FROM	DataWarehouse..BillOfLading_' + @strYear + ' BillOfLading'
		EXEC	(@strSQL)
	END
	
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Invoice_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FiscalTime' + ' ' +
					'	(FiscalPeriodCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	Invoice.FiscalPeriodCode' + ' ' +
					'FROM	DataWarehouse..Invoice_' + @strYear + ' Invoice'
		EXEC	(@strSQL)
	END
	
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Production_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FiscalTime' + ' ' +
					'	(FiscalPeriodCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	Production.FiscalPeriodCode' + ' ' +
					'FROM	DataWarehouse..Production_' + @strYear + ' Production'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryTrail_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FiscalTime' + ' ' +
					'	(FiscalPeriodCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	InventoryTrail.FiscalPeriodCode' + ' ' +
					'FROM	DataWarehouse..InventoryTrail_' + @strYear + ' InventoryTrail'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Forecast_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FiscalTime' + ' ' +
					'	(FiscalPeriodCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	Forecast.FiscalPeriodCode' + ' ' +
					'FROM	DataWarehouse..Forecast_' + @strYear + ' Forecast'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'SalesOrder_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FiscalTime' + ' ' +
					'	(FiscalPeriodCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	SalesOrder.FiscalPeriodCode' + ' ' +
					'FROM	DataWarehouse..SalesOrder_' + @strYear + ' SalesOrder' + ' ' +
					'WHERE	SalesOrder.LineItemStatusCode != ''C'''
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderHeader_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FiscalTime' + ' ' +
					'	(FiscalPeriodCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	PurchaseOrderHeader.FiscalPeriodCode' + ' ' +
					'FROM	DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' + 
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' PurchaseOrderHeaderLineItem' + ' ' +
					'		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X'''
		EXEC	(@strSQL)
	END


	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..FiscalTime
SET	Active = 1
FROM	DataWarehouse..FiscalTime FiscalTime
	INNER JOIN #FiscalTime
		ON FiscalTime.FiscalPeriodCode = #FiscalTime.FiscalPeriodCode

DROP	TABLE #FiscalTime





GO
