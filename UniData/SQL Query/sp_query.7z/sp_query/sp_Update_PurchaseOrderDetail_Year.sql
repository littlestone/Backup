ALTER     PROCEDURE dbo.sp_Update_PurchaseOrderDetail_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
BEGIN
	SELECT	@strSQL = 'UPDATE DataWarehouse..PurchaseOrderDetail_' + @strYear + ' ' +
			'SET	CompanyUnitOfMeasureCode = ISNULL(PODET.UM, '''')' + ' ' +
			',	PartDescription = REPLACE(REPLACE(ISNULL(PODET.DESCRIPTION, ''''), CHAR(129), ''''), CHAR(253), '' '')' + ' ' +
			',	SupplierPartNumber = ISNULL(PODET.SUPPLIER_PART_NBR, '''')' + ' ' +
			',	ProductCode = CASE PODET.CHARGE_CD WHEN ''P'' THEN ISNULL(PODET.PART_GL_WO, '''') ELSE '''' END' + ' ' +
			',	GeneralLedgerAccountCode = CASE PODET.CHARGE_CD WHEN ''G'' THEN ISNULL(PODET.PART_GL_WO, '''') ELSE '''' END' + ' ' +
			',	WorkOrderNumber = CASE PODET.CHARGE_CD WHEN ''W'' THEN ISNULL(PODET.PART_GL_WO, '''') ELSE '''' END' + ' ' +
			',	ContractQuantity = ISNULL(PODET.CONTR_QTY, 0)' + ' ' +
			',	ContractUnitPrice = ISNULL(PODET.CONTR_PRICE, 0)' + ' ' +
			',	SupplierUnitOfMeasureCode = ISNULL(PODET.PCH_UM, '''')' + ' ' +
			',	ConversionFactor = ISNULL(PODET.CONV_FACTOR, 0)' + ' ' +
			',	InspectionRequestFlag = ISNULL(PODET.INSP_REQD, '''')' + ' ' +
			',	PartRevisionLevel = ISNULL(PODET.REV_LVL, '''')' + ' ' +
			',	RequisitionNumber = ISNULL(PODET.REQ_NBR, '''')' + ' ' +
			',	RequestorName = ISNULL(PODET.REQUESTOR, '''')' + ' ' +
			',	TaxFlag = ISNULL(PODET.TAX, '''')' + ' ' +
			',	ChargeTypeCode = ISNULL(PODET.CHARGE_CD, '''')' + ' ' +
			'FROM	DataWarehouse..PurchaseOrderDetail_' + @strYear + ' PurchaseOrderDetail' + ' ' +
			'	INNER JOIN Source..PODET PODET' + ' ' +
			'		ON PurchaseOrderDetail.PurchaseOrderNumber = CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END' + ' ' +
			'		AND PurchaseOrderDetail.ReferenceNumber = CASE WHEN LEN(PODET.ID) <= 5 THEN '''' ELSE LEFT(PODET.ID, 5) END' + ' ' +
			'WHERE	PurchaseOrderDetail.CompanyUnitOfMeasureCode != ISNULL(PODET.UM, '''')' + ' ' +
			'OR	PurchaseOrderDetail.PartDescription != REPLACE(REPLACE(ISNULL(PODET.DESCRIPTION, ''''), CHAR(129), ''''), CHAR(253), '' '')' + ' ' +
			'OR	PurchaseOrderDetail.SupplierPartNumber != ISNULL(PODET.SUPPLIER_PART_NBR, '''')' + ' ' +
			'OR	PurchaseOrderDetail.ProductCode != CASE PODET.CHARGE_CD WHEN ''P'' THEN ISNULL(PODET.PART_GL_WO, '''') ELSE '''' END' + ' ' +
			'OR	PurchaseOrderDetail.GeneralLedgerAccountCode != CASE PODET.CHARGE_CD WHEN ''G'' THEN ISNULL(PODET.PART_GL_WO, '''') ELSE '''' END' + ' ' +
			'OR	PurchaseOrderDetail.WorkOrderNumber != CASE PODET.CHARGE_CD WHEN ''W'' THEN ISNULL(PODET.PART_GL_WO, '''') ELSE '''' END' + ' ' +
			'OR	PurchaseOrderDetail.ContractQuantity != ISNULL(PODET.CONTR_QTY, 0)' + ' ' +
			'OR	PurchaseOrderDetail.ContractUnitPrice != ISNULL(PODET.CONTR_PRICE, 0)' + ' ' +
			'OR	PurchaseOrderDetail.SupplierUnitOfMeasureCode != ISNULL(PODET.PCH_UM, '''')' + ' ' +
			'OR	PurchaseOrderDetail.ConversionFactor != ISNULL(PODET.CONV_FACTOR, 0)' + ' ' +
			'OR	PurchaseOrderDetail.InspectionRequestFlag != ISNULL(PODET.INSP_REQD, '''')' + ' ' +
			'OR	PurchaseOrderDetail.PartRevisionLevel != ISNULL(PODET.REV_LVL, '''')' + ' ' +
			'OR	PurchaseOrderDetail.RequisitionNumber != ISNULL(PODET.REQ_NBR, '''')' + ' ' +
			'OR	PurchaseOrderDetail.RequestorName != ISNULL(PODET.REQUESTOR, '''')' + ' ' +
			'OR	PurchaseOrderDetail.TaxFlag != ISNULL(PODET.TAX, '''')' + ' ' +
			'OR	PurchaseOrderDetail.ChargeTypeCode != ISNULL(PODET.CHARGE_CD, '''')'

	EXEC	(@strSQL)
END

GO
