
ALTER   PROCEDURE dbo.sp_Update_Asset_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..Asset
SET	Active = 0
WHERE	NULLIF(AssetCode, '') IS NOT NULL		-- AssetCode != ''

SELECT	Asset.AssetCode			-- Create temporary table
INTO	#Asset
FROM	DataWarehouse..Asset Asset
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Asset' + ' ' +
					'	(AssetCode)' + ' ' +	
					'SELECT	DISTINCT' + ' ' +
					'	Asset.AssetCode' + ' ' + 
					'FROM	DataWarehouse..PurchaseOrderDetail_' + @strYear + ' PurchaseOrderDetail' + ' ' + 
					'	INNER JOIN Datawarehouse..Asset Asset' + ' ' + 
					'		ON PurchaseOrderDetail.WorkOrderNumber = Asset.WorkOrderNumber' + ' ' +
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' PurchaseOrderHeaderLineItem' + ' ' +
					'		ON PurchaseOrderDetail.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'			AND PurchaseOrderDetail.ReferenceNumber = PurchaseOrderHeaderLineItem.ReferenceNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X'''
		EXEC	(@strSQL)
	END
	
	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..Asset
SET	Active = 1
FROM	DataWarehouse..Asset Asset
	INNER JOIN #Asset
		ON Asset.AssetCode = #Asset.AssetCode

DROP	TABLE #Asset
GO
