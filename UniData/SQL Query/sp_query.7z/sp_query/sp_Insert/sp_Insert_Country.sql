ALTER PROCEDURE dbo.sp_Insert_Country AS
INSERT	DataWarehouse..Country
	(CountryCode
,	CountryName
,	Active)
SELECT	SYSTBL_ECC.DF_PL
,	ISNULL(SYSTBL_ECC.DF_PL_DESC, '')
,	0
FROM	Source..SYSTBL_ECC SYSTBL_ECC
	LEFT JOIN DataWarehouse..Country Country
		ON SYSTBL_ECC.DF_PL = Country.CountryCode
WHERE	Country.CountryCode IS NULL

GO

