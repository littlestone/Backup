UPDATE DataWarehouse..PurchaseOrderDetail_2008
SET	CompanyUnitCost = 0
,	CompanyScheduleQuantity = 0
,	CompanyBalanceQuantity = 0
,	CompanyReceiveQuantity = 0


EXEC sp_Update_PurchaseOrderDetail_PurchaseOrderDelivery

EXEC sp_Update_PurchaseOrderDetail_PurchaseOrderReceipt

