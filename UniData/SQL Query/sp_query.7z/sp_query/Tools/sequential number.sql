DECLARE @counter int
SET @counter = 0

WHILE @counter < 116147
BEGIN
	SET @counter = @counter + 1
	UPDATE tbl_MAD_Input
	SET id = @counter
	--PRINT 'The counter is ' + CAST(@counter as char)
END



-- Generate sequential number

DECLARE @counter int
SET @counter = 0

DECLARE @id int

DECLARE @item varchar(100)
DECLARE @corporation varchar(100)
DECLARE @department varchar(100)
DECLARE @ship_to varchar(100)

DECLARE CustList 
CURSOR FOR
SELECT item, corporation, department, ship_to
FROM tbl_MAD_Input

OPEN CustList

FETCH NEXT FROM CustList INTO @item, @corporation, @department, @ship_to
WHILE (@@FETCH_STATUS = 0)
BEGIN
	UPDATE tbl_MAD_Input
	SET id = @counter
	WHERE	item = @item
	AND	corporation = @corporation
	AND 	department = @department
	AND	ship_to = @ship_to


	SET @counter = @counter + 1
 	FETCH NEXT FROM CustList INTO @item, @corporation, @department, @ship_to
END

CLOSE CustList
DEALLOCATE CustList
