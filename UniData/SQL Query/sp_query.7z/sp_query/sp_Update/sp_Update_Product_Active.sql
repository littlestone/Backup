ALTER    PROCEDURE dbo.sp_Update_Product_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..Product
SET	Active = 0
WHERE	NULLIF(ComputerizedPartNumber, '') IS NOT NULL

SELECT	ProductGroup.ProductGroupCode
,	Product.ComputerizedPartNumber
INTO	#Product
FROM	DataWarehouse..ProductGroup ProductGroup
,	DataWarehouse..Product Product
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryWarehouse_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Product' + ' ' +
					'	(ProductGroupCode' + ' ' +
					',	ComputerizedPartNumber)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	''''' + ' ' +
					',	InventoryWarehouse.ComputerizedPartNumber' + ' ' +
					'FROM	DataWarehouse..InventoryWarehouse_' + @strYear + ' InventoryWarehouse' + ' ' +
					'WHERE	InventoryWarehouse.BookedQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.OnHandQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.InMaterialReviewBoardQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.InReceiptInInspectionQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.InTransitQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.ManufacturingAllocationQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.AllocationQuantity != 0'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'BillOfLading_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Product' + ' ' +
					'	(ProductGroupCode' + ' ' +
					',	ComputerizedPartNumber)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	''''' + ' ' +
					',	BillOfLading.ComputerizedPartNumber' + ' ' +
					'FROM	DataWarehouse..BillOfLading_' + @strYear + ' BillOfLading'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Invoice_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Product' + ' ' +
					'	(ProductGroupCode' + ' ' +
					',	ComputerizedPartNumber)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	''''' + ' ' +
					',	Invoice.ComputerizedPartNumber' + ' ' +
					'FROM	DataWarehouse..Invoice_' + @strYear + ' Invoice'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Production_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Product' + ' ' +
					'	(ProductGroupCode' + ' ' +
					',	ComputerizedPartNumber)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	''''' + ' ' +
					',	Production.ComputerizedPartNumber' + ' ' +
					'FROM	DataWarehouse..Production_' + @strYear + ' Production'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Budget_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Product' + ' ' +
					'	(ProductGroupCode' + ' ' +
					',	ComputerizedPartNumber)' + ' ' +
					'SELECT	ProductGroup.ProductGroupCode' + ' ' +
					',	MIN(Product.ComputerizedPartNumber)' + ' ' +
					'FROM	DataWarehouse..Budget_' + @strYear + ' Budget' + ' ' +
					'	INNER JOIN DataWarehouse..ProductGroup ProductGroup' + ' ' +
					'		ON Budget.SuperGroupCode = ProductGroup.SuperGroupCode' + ' ' +
					'	INNER JOIN DataWarehouse..ProductLine ProductLine' + ' ' +
					'		ON ProductGroup.ProductGroupCode = ProductLine.ProductGroupCode' + ' ' +
					'	INNER JOIN DataWarehouse..Product Product' + ' ' +
					'		ON ProductLine.ProductLineCode = Product.ProductLineCode' + ' ' +
					'GROUP	BY ProductGroup.ProductGroupCode'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryTrail_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Product' + ' ' +
					'	(ProductGroupCode' + ' ' +
					',	ComputerizedPartNumber)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	''''' + ' ' +
					',	InventoryTrail.ComputerizedPartNumber' + ' ' +
					'FROM	DataWarehouse..InventoryTrail_' + @strYear + ' InventoryTrail'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Forecast_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Product' + ' ' +
					'	(ProductGroupCode' + ' ' +
					',	ComputerizedPartNumber)' + ' ' +
					'SELECT	ProductGroup.ProductGroupCode' + ' ' +
					',	MIN(Product.ComputerizedPartNumber)' + ' ' +
					'FROM	DataWarehouse..Forecast_' + @strYear + ' Forecast' + ' ' +
					'	INNER JOIN DataWarehouse..ProductGroup ProductGroup' + ' ' +
					'		ON Forecast.ProductGroupCode = ProductGroup.ProductGroupCode' + ' ' +
					'	INNER JOIN DataWarehouse..ProductLine ProductLine' + ' ' +
					'		ON ProductGroup.ProductGroupCode = ProductLine.ProductGroupCode' + ' ' +
					'	INNER JOIN DataWarehouse..Product Product' + ' ' +
					'		ON ProductLine.ProductLineCode = Product.ProductLineCode' + ' ' +
					'GROUP	BY ProductGroup.ProductGroupCode'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'SalesOrder_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Product' + ' ' +
					'	(ProductGroupCode' + ' ' +
					',	ComputerizedPartNumber)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	''''' + ' ' +
					',	SalesOrder.ComputerizedPartNumber' + ' ' +
					'FROM	DataWarehouse..SalesOrder_' + @strYear + ' SalesOrder' + ' ' +
					'WHERE	SalesOrder.LineItemStatusCode != ''C'''
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Product' + ' ' +
					'	(ProductGroupCode' + ' ' +
					',	ComputerizedPartNumber)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	''''' + ' ' +
					',	PurchaseOrderDetail.ComputerizedPartNumber' + ' ' +
					'FROM	DataWarehouse..PurchaseOrderDetail_' + @strYear + ' PurchaseOrderDetail' + ' ' +
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' PurchaseOrderHeaderLineItem' + ' ' +
					'		ON PurchaseOrderDetail.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'			AND PurchaseOrderDetail.ReferenceNumber = PurchaseOrderHeaderLineItem.ReferenceNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X'''
		EXEC	(@strSQL)
	END


	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..Product
SET	Active = 1
FROM	DataWarehouse..Product Product
	INNER JOIN #Product
		ON Product.ComputerizedPartNumber = #Product.ComputerizedPartNumber

DROP	TABLE #Product







GO
