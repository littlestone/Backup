ALTER PROCEDURE dbo.sp_Insert_City AS

INSERT	DataWarehouse..City
	(CityCode
,	CityName
,	Active)
SELECT	DISTINCT ISNULL(CUSTMST.CITY, '')
,	ISNULL(CUSTMST.CITY, '')
,	0
FROM	Source..CUSTMST CUSTMST
	LEFT JOIN DataWarehouse..City City
		ON ISNULL(CUSTMST.CITY, '') = City.CityCode
WHERE	City.CityCode IS NULL

INSERT	DataWarehouse..City
	(CityCode
,	CityName
,	Active)
SELECT	DISTINCT ISNULL(WHSMST.CITY, '')
,	ISNULL(WHSMST.CITY, '')
,	0
FROM	Source..WHSMST WHSMST
	LEFT JOIN DataWarehouse..City City
		ON ISNULL(WHSMST.CITY, '') = City.CityCode
WHERE	City.CityCode IS NULL

INSERT	DataWarehouse..City
	(CityCode
,	CityName
,	Active)
SELECT	DISTINCT ISNULL(SUPPMST.CITY, '')
,	ISNULL(SUPPMST.CITY, '')
,	0
FROM	Source..SUPPMST SUPPMST
	LEFT JOIN DataWarehouse..City City
		ON ISNULL(SUPPMST.CITY, '') = City.CityCode
WHERE	City.CityCode IS NULL

-- Insert more cities based on supplier's information
INSERT	DataWarehouse..City
	(CityCode
,	CityName
,	Active)
SELECT	DISTINCT ISNULL(SUPPMST.P_CITY, '')
,	ISNULL(SUPPMST.P_CITY, '')
,	0
FROM	Source..SUPPMST SUPPMST
	LEFT JOIN DataWarehouse..City City
		ON ISNULL(SUPPMST.P_CITY, '') = City.CityCode
WHERE	City.CityCode IS NULL
GO
