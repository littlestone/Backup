CREATE PROCEDURE dbo.sp_Delete_tbl_MAD_Input_IRW
AS

TRUNCATE TABLE	DemandSolutions..tbl_MAD_Input_IRW

GO
