ALTER PROCEDURE dbo.sp_Insert_StateProvince AS
INSERT	DataWarehouse..StateProvince
	(StateProvinceCode
,	StateProvinceName
,	Active)
SELECT	SYSTBL_TAX.DF_PL
,	ISNULL(SYSTBL_TAX.DF_PL_DESC, '')
,	0
FROM	Source..SYSTBL_TAX SYSTBL_TAX
	LEFT JOIN DataWarehouse..StateProvince StateProvince
		ON SYSTBL_TAX.DF_PL = StateProvince.StateProvinceCode
WHERE	StateProvince.StateProvinceCode IS NULL

GO