

ALTER PROCEDURE dbo.sp_Update_Supplier_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..Supplier
SET	Active = 0
WHERE	NULLIF(SupplierCode, '') IS NOT NULL

SELECT	Supplier.CompanyCode
,	Supplier.SupplierCode
INTO	#Supplier
FROM	DataWarehouse..Supplier Supplier
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryTrail_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Supplier' + ' ' +
					'	(CompanyCode' + ' ' +
					',	SupplierCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	InventoryTrail.CompanyCode' + ' ' +
					',	InventoryTrail.SupplierCode' + ' ' +
					'FROM	DataWarehouse..InventoryTrail_' + @strYear + ' InventoryTrail'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderHeader_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Supplier' + ' ' +
					'	(CompanyCode' + ' ' +
					',	SupplierCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	PurchaseOrderHeader.CompanyCode' + ' ' +
					',	PurchaseOrderHeader.SupplierCode' + ' ' +
					'FROM	DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' +
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' ' + 'PurchaseOrderHeaderLineItem' + ' ' + 
					'		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X'''
		EXEC	(@strSQL)
	END

	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..Supplier
SET	Active = 1
FROM	DataWarehouse..Supplier Supplier
	INNER JOIN #Supplier
		ON Supplier.CompanyCode = #Supplier.CompanyCode
		AND Supplier.SupplierCode = #Supplier.SupplierCode

DROP	TABLE #Supplier


GO
