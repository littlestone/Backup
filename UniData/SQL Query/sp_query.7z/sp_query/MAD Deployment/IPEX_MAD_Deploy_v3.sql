/*********************************
 *  Create Table tbl_MAD_Input
 *********************************/ 
DROP TABLE tbl_MAD_Input
GO

CREATE TABLE tbl_MAD_Input
(    item         INT NOT NULL
    ,company      INT     NULL
    ,division     INT     NULL
    ,sold         INT     NULL
    ,corporation  INT NOT NULL
    ,department   INT NOT NULL
    ,ship_to      INT NOT NULL
    ,history_1    INT NOT NULL
    ,history_2    INT NOT NULL
    ,history_3    INT NOT NULL
    ,history_4    INT NOT NULL
    ,history_5    INT NOT NULL
    ,history_6    INT NOT NULL
    ,history_7    INT NOT NULL
    ,history_8    INT NOT NULL
    ,history_9    INT NOT NULL
    ,history_10   INT NOT NULL
    ,history_11   INT NOT NULL
    ,history_12   INT NOT NULL
    ,history_13   INT NOT NULL
    ,history_14   INT NOT NULL
    ,history_15   INT NOT NULL
    ,history_16   INT NOT NULL
    ,history_17   INT NOT NULL
    ,history_18   INT NOT NULL
    ,history_19   INT NOT NULL
    ,history_20   INT NOT NULL
    ,history_21   INT NOT NULL
    ,history_22   INT NOT NULL
    ,history_23   INT NOT NULL
    ,history_24   INT NOT NULL
    ,history_25   INT NOT NULL
    ,history_26   INT NOT NULL
    ,history_27   INT NOT NULL
    ,history_28   INT NOT NULL
    ,history_29   INT NOT NULL
    ,history_30   INT NOT NULL
    ,history_31   INT NOT NULL
    ,history_32   INT NOT NULL
    ,history_33   INT NOT NULL
    ,history_34   INT NOT NULL
    ,history_35   INT NOT NULL
    ,history_36   INT NOT NULL
    ,history_37   INT NOT NULL
    ,history_38   INT NOT NULL
    ,history_39   INT NOT NULL
    ,history_40   INT NOT NULL
    ,history_41   INT NOT NULL
)
GO


DROP TABLE tbl_MAD_Input_IRW
GO

CREATE TABLE tbl_MAD_Input_IRW
(    row_id       INT          IDENTITY
    ,item         VARCHAR(255) NOT NULL
    ,company      VARCHAR(50)      NULL
    ,division     VARCHAR(50)      NULL
    ,sold         VARCHAR(50)      NULL
    ,corporation  VARCHAR(50)  NOT NULL
    ,department   VARCHAR(50)  NOT NULL
    ,ship_to      VARCHAR(50)  NOT NULL
    ,history_1    INT NOT NULL
    ,history_2    INT NOT NULL
    ,history_3    INT NOT NULL
    ,history_4    INT NOT NULL
    ,history_5    INT NOT NULL
    ,history_6    INT NOT NULL
    ,history_7    INT NOT NULL
    ,history_8    INT NOT NULL
    ,history_9    INT NOT NULL
    ,history_10   INT NOT NULL
    ,history_11   INT NOT NULL
    ,history_12   INT NOT NULL
    ,history_13   INT NOT NULL
    ,history_14   INT NOT NULL
    ,history_15   INT NOT NULL
    ,history_16   INT NOT NULL
    ,history_17   INT NOT NULL
    ,history_18   INT NOT NULL
    ,history_19   INT NOT NULL
    ,history_20   INT NOT NULL
    ,history_21   INT NOT NULL
    ,history_22   INT NOT NULL
    ,history_23   INT NOT NULL
    ,history_24   INT NOT NULL
    ,history_25   INT NOT NULL
    ,history_26   INT NOT NULL
    ,history_27   INT NOT NULL
    ,history_28   INT NOT NULL
    ,history_29   INT NOT NULL
    ,history_30   INT NOT NULL
    ,history_31   INT NOT NULL
    ,history_32   INT NOT NULL
    ,history_33   INT NOT NULL
    ,history_34   INT NOT NULL
    ,history_35   INT NOT NULL
    ,history_36   INT NOT NULL
    ,history_37   INT NOT NULL
    ,history_38   INT NOT NULL
    ,history_39   INT NOT NULL
    ,history_40   INT NOT NULL
    ,history_41   INT NOT NULL
)
GO



DROP TABLE tbl_MAD_Input_IW
GO

CREATE TABLE tbl_MAD_Input_IW
(    row_id       INT          IDENTITY
    ,item         VARCHAR(255) NOT NULL
    ,company      VARCHAR(50)      NULL
    ,division     VARCHAR(50)      NULL
    ,sold         VARCHAR(50)      NULL
    ,corporation  VARCHAR(50)  NOT NULL
    ,department   VARCHAR(50)  NOT NULL
    ,ship_to      VARCHAR(50)  NOT NULL
    ,history_1    INT NOT NULL
    ,history_2    INT NOT NULL
    ,history_3    INT NOT NULL
    ,history_4    INT NOT NULL
    ,history_5    INT NOT NULL
    ,history_6    INT NOT NULL
    ,history_7    INT NOT NULL
    ,history_8    INT NOT NULL
    ,history_9    INT NOT NULL
    ,history_10   INT NOT NULL
    ,history_11   INT NOT NULL
    ,history_12   INT NOT NULL
    ,history_13   INT NOT NULL
    ,history_14   INT NOT NULL
    ,history_15   INT NOT NULL
    ,history_16   INT NOT NULL
    ,history_17   INT NOT NULL
    ,history_18   INT NOT NULL
    ,history_19   INT NOT NULL
    ,history_20   INT NOT NULL
    ,history_21   INT NOT NULL
    ,history_22   INT NOT NULL
    ,history_23   INT NOT NULL
    ,history_24   INT NOT NULL
    ,history_25   INT NOT NULL
    ,history_26   INT NOT NULL
    ,history_27   INT NOT NULL
    ,history_28   INT NOT NULL
    ,history_29   INT NOT NULL
    ,history_30   INT NOT NULL
    ,history_31   INT NOT NULL
    ,history_32   INT NOT NULL
    ,history_33   INT NOT NULL
    ,history_34   INT NOT NULL
    ,history_35   INT NOT NULL
    ,history_36   INT NOT NULL
    ,history_37   INT NOT NULL
    ,history_38   INT NOT NULL
    ,history_39   INT NOT NULL
    ,history_40   INT NOT NULL
    ,history_41   INT NOT NULL
)
GO



DROP TABLE tbl_MAD_Input_I
GO

CREATE TABLE tbl_MAD_Input_I
(    row_id       INT          IDENTITY
    ,item         VARCHAR(255) NOT NULL
    ,company      VARCHAR(50)      NULL
    ,division     VARCHAR(50)      NULL
    ,sold         VARCHAR(50)      NULL
    ,corporation  VARCHAR(50)  NOT NULL
    ,department   VARCHAR(50)  NOT NULL
    ,ship_to      VARCHAR(50)  NOT NULL
    ,history_1    INT NOT NULL
    ,history_2    INT NOT NULL
    ,history_3    INT NOT NULL
    ,history_4    INT NOT NULL
    ,history_5    INT NOT NULL
    ,history_6    INT NOT NULL
    ,history_7    INT NOT NULL
    ,history_8    INT NOT NULL
    ,history_9    INT NOT NULL
    ,history_10   INT NOT NULL
    ,history_11   INT NOT NULL
    ,history_12   INT NOT NULL
    ,history_13   INT NOT NULL
    ,history_14   INT NOT NULL
    ,history_15   INT NOT NULL
    ,history_16   INT NOT NULL
    ,history_17   INT NOT NULL
    ,history_18   INT NOT NULL
    ,history_19   INT NOT NULL
    ,history_20   INT NOT NULL
    ,history_21   INT NOT NULL
    ,history_22   INT NOT NULL
    ,history_23   INT NOT NULL
    ,history_24   INT NOT NULL
    ,history_25   INT NOT NULL
    ,history_26   INT NOT NULL
    ,history_27   INT NOT NULL
    ,history_28   INT NOT NULL
    ,history_29   INT NOT NULL
    ,history_30   INT NOT NULL
    ,history_31   INT NOT NULL
    ,history_32   INT NOT NULL
    ,history_33   INT NOT NULL
    ,history_34   INT NOT NULL
    ,history_35   INT NOT NULL
    ,history_36   INT NOT NULL
    ,history_37   INT NOT NULL
    ,history_38   INT NOT NULL
    ,history_39   INT NOT NULL
    ,history_40   INT NOT NULL
    ,history_41   INT NOT NULL
)
GO

/*********************************
 *  Create Table tbl_MAD_Output
 *********************************/ 
DROP TABLE tbl_MAD_Output_IRW
GO

CREATE TABLE tbl_MAD_Output_IRW
(
     row_id         INT          NOT NULL
    ,item           VARCHAR(255) NOT NULL
    ,company        VARCHAR(50)  NOT NULL
    ,division       VARCHAR(50)  NOT NULL
    ,sold           VARCHAR(50)  NOT NULL
    ,corporation    VARCHAR(50)  NOT NULL
    ,department     VARCHAR(50)  NOT NULL
    ,ship_to        VARCHAR(50)  NOT NULL
    ,history_avg    FLOAT        NOT NULL
    ,history_stdDev FLOAT        NOT NULL
    ,percent_stdDev FLOAT        NOT NULL
    ,percent_MAD    FLOAT        NOT NULL
    ,total_run      FLOAT        NOT NULL
    ,total_percent  FLOAT        NOT NULL
    ,Class          VARCHAR(5)   NOT NULL
)
GO


DROP TABLE tbl_MAD_Output_IW
GO

CREATE TABLE tbl_MAD_Output_IW
(
     row_id         INT          NOT NULL
    ,item           VARCHAR(255) NOT NULL
    ,company        VARCHAR(50)  NOT NULL
    ,division       VARCHAR(50)  NOT NULL
    ,sold           VARCHAR(50)  NOT NULL
    ,corporation    VARCHAR(50)  NOT NULL
    ,department     VARCHAR(50)  NOT NULL
    ,ship_to        VARCHAR(50)  NOT NULL
    ,history_avg    FLOAT        NOT NULL
    ,history_stdDev FLOAT        NOT NULL
    ,percent_stdDev FLOAT        NOT NULL
    ,percent_MAD    FLOAT        NOT NULL
    ,total_run      FLOAT        NOT NULL
    ,total_percent  FLOAT        NOT NULL
    ,Class          VARCHAR(5)   NOT NULL
)
GO



DROP TABLE tbl_MAD_Output_I
GO

CREATE TABLE tbl_MAD_Output_I
(
     row_id         INT          NOT NULL
    ,item           VARCHAR(255) NOT NULL
    ,company        VARCHAR(50)  NOT NULL
    ,division       VARCHAR(50)  NOT NULL
    ,sold           VARCHAR(50)  NOT NULL
    ,corporation    VARCHAR(50)  NOT NULL
    ,department     VARCHAR(50)  NOT NULL
    ,ship_to        VARCHAR(50)  NOT NULL
    ,history_avg    FLOAT        NOT NULL
    ,history_stdDev FLOAT        NOT NULL
    ,percent_stdDev FLOAT        NOT NULL
    ,percent_MAD    FLOAT        NOT NULL
    ,total_run      FLOAT        NOT NULL
    ,total_percent  FLOAT        NOT NULL
    ,Class          VARCHAR(5)   NOT NULL
)
GO


/*********************************
 *  gen_MAD_Output_IRW
 *********************************/ 
DROP PROCEDURE gen_MAD_Output_IRW
GO 

CREATE PROCEDURE gen_MAD_Output_IRW
AS
BEGIN
     SET NOCOUNT ON


     TRUNCATE TABLE tbl_MAD_Input_IRW

     TRUNCATE TABLE tbl_MAD_Output_IRW


     -------------------------------------------------------
     --  Group Sum The Input Table
     -------------------------------------------------------
     INSERT INTO tbl_MAD_Input_IRW
     SELEcT item
         ,''
         ,''
         ,''
         ,''
         ,department
         ,ship_to
         ,SUM(history_1)
         ,SUM(history_2)
         ,SUM(history_3)
         ,SUM(history_4)
         ,SUM(history_5)
         ,SUM(history_6)
         ,SUM(history_7)
         ,SUM(history_8)
         ,SUM(history_9)
         ,SUM(history_10)
         ,SUM(history_11)
         ,SUM(history_12)
         ,SUM(history_13)
         ,SUM(history_14)
         ,SUM(history_15)
         ,SUM(history_16)
         ,SUM(history_17)
         ,SUM(history_18)
         ,SUM(history_19)
         ,SUM(history_20)
         ,SUM(history_21)
         ,SUM(history_22)
         ,SUM(history_23)
         ,SUM(history_24)
         ,SUM(history_25)
         ,SUM(history_26)
         ,SUM(history_27)
         ,SUM(history_28)
         ,SUM(history_29)
         ,SUM(history_30)
         ,SUM(history_31)
         ,SUM(history_32)
         ,SUM(history_33)
         ,SUM(history_34)
         ,SUM(history_35)
         ,SUM(history_36)
         ,SUM(history_37)
         ,SUM(history_38)
         ,SUM(history_39)
         ,SUM(history_40)
         ,SUM(history_41)
     FROM tbl_MAD_Input
     GROUP BY item, department, ship_to

     -------------------------------------------------------
     --  Calculate Avg for each Row  
     -------------------------------------------------------
     INSERT INTO tbl_MAD_Output_IRW
     SELECT  row_id
          , ISNULL(CAST(item AS VARCHAR(255)), '')
          , ISNULL(CAST(company AS VARCHAR(50)), '')
          , ISNULL(CAST(division AS VARCHAR(50)), '')
          , ISNULL(CAST(sold AS VARCHAR(50)), '')
          , ISNULL(CAST(corporation AS VARCHAR(50)), '')
          , ISNULL(CAST(department AS VARCHAR(50)), '')
          , ISNULL(CAST(ship_to AS VARCHAR(50)), '')
          ,    (                  history_1 +  history_2 +  history_3 +  history_4 +  history_5 
                 +  history_6 +  history_7 +  history_8 +  history_9 + history_10 + history_11 
                 + history_12 + history_13 + history_14 + history_15 + history_16 + history_17
                 + history_18 + history_19 + history_20 + history_21 + history_22 + history_23
                 + history_24 + history_25 + history_26 + history_27 + history_28 + history_29
                 + history_30 + history_31 + history_32 + history_33 + history_34 + history_35
                 + history_36 + history_37 + history_38 + history_39 + history_40 + history_41 ) / 41.0
                                                       -- history_avg
          , 0                                          -- StdDev
          , 0		                               -- StdDev%
          , 0                                          -- Mean Avg Dev%
          , 0                                          -- total_run
          , 0                                          -- total_percent
          , ''                                         -- classificiation ABC
       FROM tbl_MAD_Input_IRW


 
     -------------------------------------------------------
     -- Remove A Rows that have Avg of 0 
     -------------------------------------------------------
     DELETE FROM tbl_MAD_Output_IRW
       WHERE item IS NULL
          OR history_avg = 0 



     -------------------------------------------------------
     -- Calculate StdDev for each row
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_IRW
        SET history_stdDev = SQRT(  (SQUARE( history_1 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE( history_2 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE( history_3 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE( history_4 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE( history_5 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE( history_6 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE( history_7 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE( history_8 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE( history_9 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_10 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_11 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_12 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_13 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_14 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_15 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_16 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_17 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_18 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_19 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_20 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_21 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_22 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_23 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_24 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_25 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_26 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_27 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_28 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_29 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_30 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_31 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_32 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_33 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_34 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_35 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_36 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_37 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_38 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_39 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_40 - tbl_MAD_Output_IRW.history_avg)
                                   + SQUARE(history_41 - tbl_MAD_Output_IRW.history_avg) ) / (41.0 - 1.0) )
        FROM tbl_MAD_Input_IRW
       WHERE tbl_MAD_Input_IRW.row_id = tbl_MAD_Output_IRW.row_id


     -------------------------------------------------------
     -- Calculate StdDev% & MAD%
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_IRW
        SET percent_stdDev  = history_stdDev  / history_avg 
           ,percent_MAD     = history_stdDev  / history_avg  / 1.25



     -------------------------------------------------------
     -- Calculate Running Total of Avg, sorted by StdDev%
     -------------------------------------------------------

     -- Have to order the table by StdDev%
     SELECT row_id, percent_stddev, history_avg, total_run
       INTO #tbl_mad_output_IRW_temp
       FROM tbl_mad_output_IRW
      ORDER BY percent_stddev


     -- Do the Running Total on history_avg based on sort of StdDev%
     DECLARE @RRT FLOAT
     SET @RRT = 0
     UPDATE #tbl_mad_output_IRW_temp
        SET @RRT = total_run = @RRT + history_avg


     -- Put Back the results
     UPDATE  tbl_mad_output_IRW
        SET total_run = #tbl_mad_output_IRW_temp.total_run
       FROM #tbl_mad_output_IRW_temp
      WHERE tbl_mad_output_IRW.row_id = #tbl_mad_output_IRW_temp.row_id

 
     -- Get Rid of Temp Tables
     DROP TABLE #tbl_mad_output_IRW_temp



     -------------------------------------------------------
     --  Get The Sum Avg Total
     -------------------------------------------------------
     DECLARE @fltAvgSumTotal AS FLOAT
     SELECT @fltAvgSumTotal  = SUM(history_avg) 
       FROM tbl_MAD_Output_IRW



     -------------------------------------------------------
     -- Calculate the %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_IRW
        SET total_percent = total_run / @fltAvgSumTotal * 100
  

     -------------------------------------------------------
     -- Calculate the Code Classification based on %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_IRW  SET class = 'A' WHERE                         total_percent  <= 10
     UPDATE tbl_MAD_Output_IRW  SET class = 'B' WHERE 10 < total_percent  AND total_percent  <= 20
     UPDATE tbl_MAD_Output_IRW  SET class = 'C' WHERE 20 < total_percent  AND total_percent  <= 30
     UPDATE tbl_MAD_Output_IRW  SET class = 'D' WHERE 30 < total_percent  AND total_percent  <= 40
     UPDATE tbl_MAD_Output_IRW  SET class = 'E' WHERE 40 < total_percent  AND total_percent  <= 50
     UPDATE tbl_MAD_Output_IRW  SET class = 'F' WHERE 50 < total_percent  AND total_percent  <= 60
     UPDATE tbl_MAD_Output_IRW  SET class = 'G' WHERE 60 < total_percent  AND total_percent  <= 70
     UPDATE tbl_MAD_Output_IRW  SET class = 'H' WHERE 70 < total_percent  AND total_percent  <= 80
     UPDATE tbl_MAD_Output_IRW  SET class = 'I' WHERE 80 < total_percent  AND total_percent  <= 90
     UPDATE tbl_MAD_Output_IRW  SET class = 'J' WHERE 90 < total_percent  AND total_percent  <= 100



     -------------------------------------------------------
     -- Pad The columns with "=" symbols
     -------------------------------------------------------
     DECLARE @intColumnLength AS INT

     SELECT @intColumnLength = 3
     UPDATE tbl_MAD_Output_IRW
        SET company = replicate('=', @intColumnLength - LEN(company)) + company
      WHERE LEN(company) <= @intColumnLength

     SELECT @intColumnLength = 8
     UPDATE tbl_MAD_Output_IRW
        SET division = replicate('=', @intColumnLength - LEN(division)) + division
      WHERE LEN(division) <= @intColumnLength

     SELECT @intColumnLength = 8
     UPDATE tbl_MAD_Output_IRW
        SET sold = replicate('=', @intColumnLength  - LEN(sold)) + sold
      WHERE LEN(sold) <= @intColumnLength

     SELECT @intColumnLength = 3
     UPDATE tbl_MAD_Output_IRW
        SET department = replicate('=', @intColumnLength - LEN(department)) + department
      WHERE LEN(department) <= @intColumnLength

     SELECT @intColumnLength = 12
     UPDATE tbl_MAD_Output_IRW
        SET ship_to = replicate('=', @intColumnLength - LEN(ship_to)) + ship_to
      WHERE LEN(ship_to) <= @intColumnLength
END  
GO



/*********************************
 *  gen_MAD_Output_IW
 *********************************/ 
DROP PROCEDURE gen_MAD_Output_IW
GO 

CREATE PROCEDURE gen_MAD_Output_IW
AS
BEGIN
     SET NOCOUNT ON


     TRUNCATE TABLE tbl_MAD_Input_IW

     TRUNCATE TABLE tbl_MAD_Output_IW


     -------------------------------------------------------
     --  Group Sum The Input Table
     -------------------------------------------------------
     INSERT INTO tbl_MAD_Input_IW
     SELEcT item
         ,''
         ,''
         ,''
         ,''
         ,''
         ,ship_to
         ,SUM(history_1)
         ,SUM(history_2)
         ,SUM(history_3)
         ,SUM(history_4)
         ,SUM(history_5)
         ,SUM(history_6)
         ,SUM(history_7)
         ,SUM(history_8)
         ,SUM(history_9)
         ,SUM(history_10)
         ,SUM(history_11)
         ,SUM(history_12)
         ,SUM(history_13)
         ,SUM(history_14)
         ,SUM(history_15)
         ,SUM(history_16)
         ,SUM(history_17)
         ,SUM(history_18)
         ,SUM(history_19)
         ,SUM(history_20)
         ,SUM(history_21)
         ,SUM(history_22)
         ,SUM(history_23)
         ,SUM(history_24)
         ,SUM(history_25)
         ,SUM(history_26)
         ,SUM(history_27)
         ,SUM(history_28)
         ,SUM(history_29)
         ,SUM(history_30)
         ,SUM(history_31)
         ,SUM(history_32)
         ,SUM(history_33)
         ,SUM(history_34)
         ,SUM(history_35)
         ,SUM(history_36)
         ,SUM(history_37)
         ,SUM(history_38)
         ,SUM(history_39)
         ,SUM(history_40)
         ,SUM(history_41)
     FROM tbl_MAD_Input
     GROUP BY item, ship_to

     -------------------------------------------------------
     --  Calculate Avg for each Row  
     -------------------------------------------------------
     INSERT INTO tbl_MAD_Output_IW
     SELECT  row_id
          , ISNULL(CAST(item AS VARCHAR(255)), '')
          , ISNULL(CAST(company AS VARCHAR(50)), '')
          , ISNULL(CAST(division AS VARCHAR(50)), '')
          , ISNULL(CAST(sold AS VARCHAR(50)), '')
          , ISNULL(CAST(corporation AS VARCHAR(50)), '')
          , ISNULL(CAST(department AS VARCHAR(50)), '')
          , ISNULL(CAST(ship_to AS VARCHAR(50)), '')
          ,    (                  history_1 +  history_2 +  history_3 +  history_4 +  history_5 
                 +  history_6 +  history_7 +  history_8 +  history_9 + history_10 + history_11 
                 + history_12 + history_13 + history_14 + history_15 + history_16 + history_17
                 + history_18 + history_19 + history_20 + history_21 + history_22 + history_23
                 + history_24 + history_25 + history_26 + history_27 + history_28 + history_29
                 + history_30 + history_31 + history_32 + history_33 + history_34 + history_35
                 + history_36 + history_37 + history_38 + history_39 + history_40 + history_41 ) / 41.0
                                                       -- history_avg
          , 0                                          -- StdDev
          , 0		                               -- StdDev%
          , 0                                          -- Mean Avg Dev%
          , 0                                          -- total_run
          , 0                                          -- total_percent
          , ''                                         -- classificiation ABC
       FROM tbl_MAD_Input_IW


 
     -------------------------------------------------------
     -- Remove A Rows that have Avg of 0 
     -------------------------------------------------------
     DELETE FROM tbl_MAD_Output_IW
       WHERE item IS NULL
          OR history_avg = 0 



     -------------------------------------------------------
     -- Calculate StdDev for each row
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_IW
        SET history_stdDev = SQRT(  (SQUARE( history_1 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE( history_2 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE( history_3 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE( history_4 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE( history_5 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE( history_6 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE( history_7 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE( history_8 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE( history_9 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_10 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_11 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_12 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_13 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_14 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_15 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_16 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_17 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_18 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_19 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_20 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_21 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_22 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_23 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_24 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_25 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_26 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_27 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_28 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_29 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_30 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_31 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_32 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_33 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_34 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_35 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_36 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_37 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_38 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_39 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_40 - tbl_MAD_Output_IW.history_avg)
                                   + SQUARE(history_41 - tbl_MAD_Output_IW.history_avg) ) / (41.0 - 1.0) )
        FROM tbl_MAD_Input_IW
       WHERE tbl_MAD_Input_IW.row_id = tbl_MAD_Output_IW.row_id


     -------------------------------------------------------
     -- Calculate StdDev% & MAD%
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_IW
        SET percent_stdDev  = history_stdDev  / history_avg 
           ,percent_MAD     = history_stdDev  / history_avg  / 1.25



     -------------------------------------------------------
     -- Calculate Running Total of Avg, sorted by StdDev%
     -------------------------------------------------------

     -- Have to order the table by StdDev%
     SELECT row_id, percent_stddev, history_avg, total_run
       INTO #tbl_mad_output_IW_temp
       FROM tbl_mad_output_IW
      ORDER BY percent_stddev


     -- Do the Running Total on history_avg based on sort of StdDev%
     DECLARE @RRT FLOAT
     SET @RRT = 0
     UPDATE #tbl_mad_output_IW_temp
        SET @RRT = total_run = @RRT + history_avg


     -- Put Back the results
     UPDATE  tbl_mad_output_IW
        SET total_run = #tbl_mad_output_IW_temp.total_run
       FROM #tbl_mad_output_IW_temp
      WHERE tbl_mad_output_IW.row_id = #tbl_mad_output_IW_temp.row_id

 
     -- Get Rid of Temp Tables
     DROP TABLE #tbl_mad_output_IW_temp



     -------------------------------------------------------
     --  Get The Sum Avg Total
     -------------------------------------------------------
     DECLARE @fltAvgSumTotal AS FLOAT
     SELECT @fltAvgSumTotal  = SUM(history_avg) 
       FROM tbl_MAD_Output_IW



     -------------------------------------------------------
     -- Calculate the %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_IW
        SET total_percent = total_run / @fltAvgSumTotal * 100
  

     -------------------------------------------------------
     -- Calculate the Code Classification based on %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_IW  SET class = 'A' WHERE                         total_percent  <= 10
     UPDATE tbl_MAD_Output_IW  SET class = 'B' WHERE 10 < total_percent  AND total_percent  <= 20
     UPDATE tbl_MAD_Output_IW  SET class = 'C' WHERE 20 < total_percent  AND total_percent  <= 30
     UPDATE tbl_MAD_Output_IW  SET class = 'D' WHERE 30 < total_percent  AND total_percent  <= 40
     UPDATE tbl_MAD_Output_IW  SET class = 'E' WHERE 40 < total_percent  AND total_percent  <= 50
     UPDATE tbl_MAD_Output_IW  SET class = 'F' WHERE 50 < total_percent  AND total_percent  <= 60
     UPDATE tbl_MAD_Output_IW  SET class = 'G' WHERE 60 < total_percent  AND total_percent  <= 70
     UPDATE tbl_MAD_Output_IW  SET class = 'H' WHERE 70 < total_percent  AND total_percent  <= 80
     UPDATE tbl_MAD_Output_IW  SET class = 'I' WHERE 80 < total_percent  AND total_percent  <= 90
     UPDATE tbl_MAD_Output_IW  SET class = 'J' WHERE 90 < total_percent  AND total_percent  <= 100



     -------------------------------------------------------
     -- Pad The columns with "=" symbols
     -------------------------------------------------------
     DECLARE @intColumnLength AS INT

     SELECT @intColumnLength = 3
     UPDATE tbl_MAD_Output_IW
        SET company = replicate('=', @intColumnLength - LEN(company)) + company
      WHERE LEN(company) <= @intColumnLength

     SELECT @intColumnLength = 8
     UPDATE tbl_MAD_Output_IW
        SET division = replicate('=', @intColumnLength - LEN(division)) + division
      WHERE LEN(division) <= @intColumnLength

     SELECT @intColumnLength = 8
     UPDATE tbl_MAD_Output_IW
        SET sold = replicate('=', @intColumnLength  - LEN(sold)) + sold
      WHERE LEN(sold) <= @intColumnLength

     SELECT @intColumnLength = 3
     UPDATE tbl_MAD_Output_IW
        SET department = replicate('=', @intColumnLength - LEN(department)) + department
      WHERE LEN(department) <= @intColumnLength

     SELECT @intColumnLength = 12
     UPDATE tbl_MAD_Output_IW
        SET ship_to = replicate('=', @intColumnLength - LEN(ship_to)) + ship_to
      WHERE LEN(ship_to) <= @intColumnLength
END  
GO



/*********************************
 *  gen_MAD_Output_I
 *********************************/ 
DROP PROCEDURE gen_MAD_Output_I
GO 

CREATE PROCEDURE gen_MAD_Output_I
AS
BEGIN
     SET NOCOUNT ON


     TRUNCATE TABLE tbl_MAD_Input_I

     TRUNCATE TABLE tbl_MAD_Output_I


     -------------------------------------------------------
     --  Group Sum The Input Table
     -------------------------------------------------------
     INSERT INTO tbl_MAD_Input_I
     SELEcT item
         ,''
         ,''
         ,''
         ,''
         ,''
         ,''
         ,SUM(history_1)
         ,SUM(history_2)
         ,SUM(history_3)
         ,SUM(history_4)
         ,SUM(history_5)
         ,SUM(history_6)
         ,SUM(history_7)
         ,SUM(history_8)
         ,SUM(history_9)
         ,SUM(history_10)
         ,SUM(history_11)
         ,SUM(history_12)
         ,SUM(history_13)
         ,SUM(history_14)
         ,SUM(history_15)
         ,SUM(history_16)
         ,SUM(history_17)
         ,SUM(history_18)
         ,SUM(history_19)
         ,SUM(history_20)
         ,SUM(history_21)
         ,SUM(history_22)
         ,SUM(history_23)
         ,SUM(history_24)
         ,SUM(history_25)
         ,SUM(history_26)
         ,SUM(history_27)
         ,SUM(history_28)
         ,SUM(history_29)
         ,SUM(history_30)
         ,SUM(history_31)
         ,SUM(history_32)
         ,SUM(history_33)
         ,SUM(history_34)
         ,SUM(history_35)
         ,SUM(history_36)
         ,SUM(history_37)
         ,SUM(history_38)
         ,SUM(history_39)
         ,SUM(history_40)
         ,SUM(history_41)
     FROM tbl_MAD_Input
     GROUP BY item

     -------------------------------------------------------
     --  Calculate Avg for each Row  
     -------------------------------------------------------
     INSERT INTO tbl_MAD_Output_I
     SELECT  row_id
          , ISNULL(CAST(item AS VARCHAR(255)), '')
          , ISNULL(CAST(company AS VARCHAR(50)), '')
          , ISNULL(CAST(division AS VARCHAR(50)), '')
          , ISNULL(CAST(sold AS VARCHAR(50)), '')
          , ISNULL(CAST(corporation AS VARCHAR(50)), '')
          , ISNULL(CAST(department AS VARCHAR(50)), '')
          , ISNULL(CAST(ship_to AS VARCHAR(50)), '')
          ,    (                  history_1 +  history_2 +  history_3 +  history_4 +  history_5 
                 +  history_6 +  history_7 +  history_8 +  history_9 + history_10 + history_11 
                 + history_12 + history_13 + history_14 + history_15 + history_16 + history_17
                 + history_18 + history_19 + history_20 + history_21 + history_22 + history_23
                 + history_24 + history_25 + history_26 + history_27 + history_28 + history_29
                 + history_30 + history_31 + history_32 + history_33 + history_34 + history_35
                 + history_36 + history_37 + history_38 + history_39 + history_40 + history_41 ) / 41.0
                                                       -- history_avg
          , 0                                          -- StdDev
          , 0		                               -- StdDev%
          , 0                                          -- Mean Avg Dev%
          , 0                                          -- total_run
          , 0                                          -- total_percent
          , ''                                         -- classificiation ABC
       FROM tbl_MAD_Input_I


 
     -------------------------------------------------------
     -- Remove A Rows that have Avg of 0 
     -------------------------------------------------------
     DELETE FROM tbl_MAD_Output_I
       WHERE item IS NULL
          OR history_avg = 0 



     -------------------------------------------------------
     -- Calculate StdDev for each row
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_I
        SET history_stdDev = SQRT(  (SQUARE( history_1 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE( history_2 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE( history_3 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE( history_4 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE( history_5 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE( history_6 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE( history_7 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE( history_8 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE( history_9 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_10 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_11 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_12 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_13 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_14 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_15 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_16 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_17 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_18 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_19 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_20 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_21 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_22 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_23 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_24 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_25 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_26 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_27 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_28 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_29 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_30 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_31 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_32 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_33 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_34 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_35 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_36 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_37 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_38 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_39 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_40 - tbl_MAD_Output_I.history_avg)
                                   + SQUARE(history_41 - tbl_MAD_Output_I.history_avg) ) / (41.0 - 1.0) )
        FROM tbl_MAD_Input_I
       WHERE tbl_MAD_Input_I.row_id = tbl_MAD_Output_I.row_id


     -------------------------------------------------------
     -- Calculate StdDev% & MAD%
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_I
        SET percent_stdDev  = history_stdDev  / history_avg 
           ,percent_MAD     = history_stdDev  / history_avg  / 1.25



     -------------------------------------------------------
     -- Calculate Running Total of Avg, sorted by StdDev%
     -------------------------------------------------------

     -- Have to order the table by StdDev%
     SELECT row_id, percent_stddev, history_avg, total_run
       INTO #tbl_mad_output_I_temp
       FROM tbl_mad_output_I
      ORDER BY percent_stddev


     -- Do the Running Total on history_avg based on sort of StdDev%
     DECLARE @RRT FLOAT
     SET @RRT = 0
     UPDATE #tbl_mad_output_I_temp
        SET @RRT = total_run = @RRT + history_avg


     -- Put Back the results
     UPDATE  tbl_mad_output_I
        SET total_run = #tbl_mad_output_I_temp.total_run
       FROM #tbl_mad_output_I_temp
      WHERE tbl_mad_output_I.row_id = #tbl_mad_output_I_temp.row_id

 
     -- Get Rid of Temp Tables
     DROP TABLE #tbl_mad_output_I_temp



     -------------------------------------------------------
     --  Get The Sum Avg Total
     -------------------------------------------------------
     DECLARE @fltAvgSumTotal AS FLOAT
     SELECT @fltAvgSumTotal  = SUM(history_avg) 
       FROM tbl_MAD_Output_I



     -------------------------------------------------------
     -- Calculate the %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_I
        SET total_percent = total_run / @fltAvgSumTotal * 100
  

     -------------------------------------------------------
     -- Calculate the Code Classification based on %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output_I  SET class = 'A' WHERE                         total_percent  <= 10
     UPDATE tbl_MAD_Output_I  SET class = 'B' WHERE 10 < total_percent  AND total_percent  <= 20
     UPDATE tbl_MAD_Output_I  SET class = 'C' WHERE 20 < total_percent  AND total_percent  <= 30
     UPDATE tbl_MAD_Output_I  SET class = 'D' WHERE 30 < total_percent  AND total_percent  <= 40
     UPDATE tbl_MAD_Output_I  SET class = 'E' WHERE 40 < total_percent  AND total_percent  <= 50
     UPDATE tbl_MAD_Output_I  SET class = 'F' WHERE 50 < total_percent  AND total_percent  <= 60
     UPDATE tbl_MAD_Output_I  SET class = 'G' WHERE 60 < total_percent  AND total_percent  <= 70
     UPDATE tbl_MAD_Output_I  SET class = 'H' WHERE 70 < total_percent  AND total_percent  <= 80
     UPDATE tbl_MAD_Output_I  SET class = 'I' WHERE 80 < total_percent  AND total_percent  <= 90
     UPDATE tbl_MAD_Output_I  SET class = 'J' WHERE 90 < total_percent  AND total_percent  <= 100



     -------------------------------------------------------
     -- Pad The columns with "=" symbols
     -------------------------------------------------------
     DECLARE @intColumnLength AS INT

     SELECT @intColumnLength = 3
     UPDATE tbl_MAD_Output_I
        SET company = replicate('=', @intColumnLength - LEN(company)) + company
      WHERE LEN(company) <= @intColumnLength

     SELECT @intColumnLength = 8
     UPDATE tbl_MAD_Output_I
        SET division = replicate('=', @intColumnLength - LEN(division)) + division
      WHERE LEN(division) <= @intColumnLength

     SELECT @intColumnLength = 8
     UPDATE tbl_MAD_Output_I
        SET sold = replicate('=', @intColumnLength  - LEN(sold)) + sold
      WHERE LEN(sold) <= @intColumnLength

     SELECT @intColumnLength = 3
     UPDATE tbl_MAD_Output_I
        SET department = replicate('=', @intColumnLength - LEN(department)) + department
      WHERE LEN(department) <= @intColumnLength

     SELECT @intColumnLength = 12
     UPDATE tbl_MAD_Output_I
        SET ship_to = replicate('=', @intColumnLength - LEN(ship_to)) + ship_to
      WHERE LEN(ship_to) <= @intColumnLength
END  
GO
