
ALTER PROCEDURE dbo.sp_Update_Country_Active AS

UPDATE	DataWarehouse..Country
SET	Active = 0
WHERE	NULLIF(CountryCode, '') IS NOT NULL

SELECT	Country.CountryCode
INTO	#Country
FROM	DataWarehouse..Country Country
WHERE	0 = 1

INSERT	#Country
	(CountryCode)
SELECT DISTINCT	CountryStateProvinceCity.CountryCode
FROM	DataWarehouse..CountryStateProvinceCity CountryStateProvinceCity
WHERE	CountryStateProvinceCity.Active = 1

INSERT	#Country
	(CountryCode)
SELECT DISTINCT	Product.OriginCountryCode
FROM	DataWarehouse..Product Product
WHERE	Product.Active = 1

UPDATE	DataWarehouse..Country
SET	Active = 1
FROM	DataWarehouse..Country Country
	INNER JOIN #Country
		ON Country.CountryCode = #Country.CountryCode

DROP	TABLE #Country
GO
