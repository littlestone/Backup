ALTER      PROCEDURE dbo.sp_Insert_PurchaseOrderDetailReceipt_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetailReceipt_' + @strYear)
BEGIN
	SELECT	@strSQL =	'INSERT	DataWarehouse..PurchaseOrderDetailReceipt_' + @strYear + ' ' +
				'	(PurchaseOrderNumber' + ' ' +
				',	ReferenceNumber' + ' ' +
				',	ReceiveDate' + ' ' +
				',	CompanyReceiveQuantity' + ' ' +
				',	SupplierReceiveQuantity)' + ' ' +
				'SELECT	CASE WHEN LEN(PODET_RECEIPT.ID) <= 5 THEN PODET_RECEIPT.ID ELSE RIGHT(PODET_RECEIPT.ID, LEN(PODET_RECEIPT.ID) - 5) END' + ' ' +
				',	CASE WHEN LEN(PODET_RECEIPT.ID) <= 5 THEN '''' ELSE LEFT(PODET_RECEIPT.ID, 5) END' + ' ' +
				',	CASE WHEN PODET_RECEIPT.RECD_DT IS NULL THEN ''1900-01-01''' + ' ' +
				'	     WHEN PODET_RECEIPT.RECD_DT < ''1900-01-01'' THEN ''1900-01-01''' + ' ' +
				'	     WHEN PODET_RECEIPT.RECD_DT > ''2075-01-01'' THEN ''1900-01-01''' + ' ' +
				'	     ELSE PODET_RECEIPT.RECD_DT' + ' ' +
				'	END' + ' ' +
				',	ISNULL(PODET_RECEIPT.RECD_QTY, 0)' + ' ' +
				',	ISNULL(PODET_RECEIPT.PCH_RCVD_QTY, 0)' + ' ' +
				'FROM	Source..PODET_RECEIPT PODET_RECEIPT' + ' ' +
				'	LEFT JOIN Source..POHDR POHDR' + ' ' +
				'		ON CASE WHEN LEN(PODET_RECEIPT.ID) <= 5 THEN PODET_RECEIPT.ID ELSE RIGHT(PODET_RECEIPT.ID, LEN(PODET_RECEIPT.ID) - 5) END = POHDR.PO_NBR' + ' ' +
				'	LEFT JOIN DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' +
				'		ON POHDR.PO_NBR = PurchaseOrderHeader.PurchaseOrderNumber' + ' ' +
				'		AND ISNULL(POHDR.PO_DT, ''1900-01-01'') = PurchaseOrderHeader.PurchaseOrderDate' + ' ' +
				'	LEFT JOIN DataWarehouse..PurchaseOrderDetailReceipt_' + @strYear + ' PurchaseOrderDetailReceipt' + ' ' +
				'		ON CASE WHEN LEN(PODET_RECEIPT.ID) <= 5 THEN PODET_RECEIPT.ID ELSE RIGHT(PODET_RECEIPT.ID, LEN(PODET_RECEIPT.ID) - 5) END = PurchaseOrderDetailReceipt.PurchaseOrderNumber' + ' ' +
				'		AND CASE WHEN LEN(PODET_RECEIPT.ID) <= 5 THEN '''' ELSE LEFT(PODET_RECEIPT.ID, 5) END = PurchaseOrderDetailReceipt.ReferenceNumber' + ' ' +
				'		AND CASE WHEN PODET_RECEIPT.RECD_DT IS NULL THEN ''1900-01-01'' WHEN PODET_RECEIPT.RECD_DT < ''1900-01-01'' THEN ''1900-01-01'' WHEN PODET_RECEIPT.RECD_DT > ''2075-01-01'' THEN ''1900-01-01'' ELSE PODET_RECEIPT.RECD_DT END = PurchaseOrderDetailReceipt.ReceiveDate' + ' ' +
				'WHERE	POHDR.FISCAL_PERIOD LIKE ''' + @strYear + '%''' + ' ' +
				'AND	PurchaseOrderDetailReceipt.PurchaseOrderNumber IS NULL' + ' ' +
				'AND	PurchaseOrderDetailReceipt.ReferenceNumber IS NULL' + ' ' +
				'AND	PurchaseOrderDetailReceipt.ReceiveDate IS NULL'

	EXEC	(@strSQL)
END


GO
