/*
*Intallation Procedures
*   In Window command prompt
*      osql -SYOUR-D573489B0B\SQLEXPRESS   -E < IPEX_MAD_Deploy_v1.sql
*/


*/
/*
*
*Procedure : gen_MAD_Output
*
*Input     : tbl_MAD_Input table
*               id            INT NOT NULL
*              ,item         VARCHAR(255) NOT NULL
*              ,company      INT     NULL
*              ,division     INT     NULL
*              ,sold         INT     NULL
*              ,corporation  INT NOT NULL
*              ,department   INT NOT NULL
*              ,ship_to      INT NOT NULL
*              ,history_1    INT NOT NULL
*              ,history_2    INT NOT NULL
*              ,history_3    INT NOT NULL
*              ,history_4    INT NOT NULL
*              ,history_5    INT NOT NULL
*              ,history_6    INT NOT NULL
*              ,history_7    INT NOT NULL
*              ,history_8    INT NOT NULL
*              ,history_9    INT NOT NULL
*              ,history_10   INT NOT NULL
*              ,history_11   INT NOT NULL
*              ,history_12   INT NOT NULL
*              ,history_13   INT NOT NULL
*              ,history_14   INT NOT NULL
*              ,history_15   INT NOT NULL
*              ,history_16   INT NOT NULL
*              ,history_17   INT NOT NULL
*              ,history_18   INT NOT NULL
*              ,history_19   INT NOT NULL
*              ,history_20   INT NOT NULL
*              ,history_21   INT NOT NULL
*              ,history_22   INT NOT NULL
*              ,history_23   INT NOT NULL
*              ,history_24   INT NOT NULL
*              ,history_25   INT NOT NULL
*              ,history_26   INT NOT NULL
*              ,history_27   INT NOT NULL
*              ,history_28   INT NOT NULL
*              ,history_29   INT NOT NULL
*              ,history_30   INT NOT NULL
*              ,history_31   INT NOT NULL
*              ,history_32   INT NOT NULL
*              ,history_33   INT NOT NULL
*              ,history_34   INT NOT NULL
*              ,history_35   INT NOT NULL
*              ,history_36   INT NOT NULL
*              ,history_37   INT NOT NULL
*              ,history_38   INT NOT NULL
*              ,history_39   INT NOT NULL
*              ,history_40   INT NOT NULL
*              ,history_41   INT NOT NULL
*
*Output    : tbl_MAD_Output table
*               id             INT          NOT NULL
*              ,item           VARCHAR(255) NOT NULL
*              ,company        INT          NOT NULL
*              ,division       INT          NOT NULL
*              ,sold           INT          NOT NULL
*              ,corporation    INT          NOT NULL
*              ,department     INT          NOT NULL
*              ,ship_to        INT          NOT NULL
*              ,history_avg    FLOAT        NOT NULL
*              ,history_stdDev FLOAT        NOT NULL
*              ,percent_stdDev FLOAT        NOT NULL
*              ,percent_MAD    FLOAT        NOT NULL
*              ,total_run      FLOAT        NOT NULL
*              ,total_percent  FLOAT        NOT NULL
*              ,Class          VARCHAR(5)   NOT NULL
*
*
*Purpose   : Calculate Avg & StdDev, StdDev%, MAD%, %TTL for each Row
*            Afterward, it classified each of the %TTL by assigning A,B,C code
*
*Usage     : Load MAD Input file into the tbl_MAD_Input table.
*            Afterward, execute gen_MAD_Output store procedure
*
*           1) In the Windows command prompt
*                bcp tbl_MAD_Input in tbl_MAD_Input.txt -c  -SYOUR-D573489B0B\SQLEXPRESS   -T
*                NOTE: Expect the tbl_MAD_Input.txt file to be TAB delimited file of the tbl_MAD_Input format
*
*           2) In a SQL session, 
*                ExECUTE gen_MAD_Output
*
*/




/*********************************
 *  Create Table tbl_MAD_Input
 *********************************/ 
DROP TABLE tbl_MAD_Input
GO


CREATE TABLE tbl_MAD_Input
(
    id            INT NOT NULL
    ,item         VARCHAR(255) NOT NULL
    ,company      INT     NULL
    ,division     INT     NULL
    ,sold         INT     NULL
    ,corporation  INT NOT NULL
    ,department   INT NOT NULL
    ,ship_to      INT NOT NULL
    ,history_1    INT NOT NULL
    ,history_2    INT NOT NULL
    ,history_3    INT NOT NULL
    ,history_4    INT NOT NULL
    ,history_5    INT NOT NULL
    ,history_6    INT NOT NULL
    ,history_7    INT NOT NULL
    ,history_8    INT NOT NULL
    ,history_9    INT NOT NULL
    ,history_10   INT NOT NULL
    ,history_11   INT NOT NULL
    ,history_12   INT NOT NULL
    ,history_13   INT NOT NULL
    ,history_14   INT NOT NULL
    ,history_15   INT NOT NULL
    ,history_16   INT NOT NULL
    ,history_17   INT NOT NULL
    ,history_18   INT NOT NULL
    ,history_19   INT NOT NULL
    ,history_20   INT NOT NULL
    ,history_21   INT NOT NULL
    ,history_22   INT NOT NULL
    ,history_23   INT NOT NULL
    ,history_24   INT NOT NULL
    ,history_25   INT NOT NULL
    ,history_26   INT NOT NULL
    ,history_27   INT NOT NULL
    ,history_28   INT NOT NULL
    ,history_29   INT NOT NULL
    ,history_30   INT NOT NULL
    ,history_31   INT NOT NULL
    ,history_32   INT NOT NULL
    ,history_33   INT NOT NULL
    ,history_34   INT NOT NULL
    ,history_35   INT NOT NULL
    ,history_36   INT NOT NULL
    ,history_37   INT NOT NULL
    ,history_38   INT NOT NULL
    ,history_39   INT NOT NULL
    ,history_40   INT NOT NULL
    ,history_41   INT NOT NULL
)
GO


/*********************************
 *  Create Table tbl_MAD_Output
 *********************************/ 
DROP TABLE tbl_MAD_Output
GO

CREATE TABLE tbl_MAD_Output
(
     id             INT          NOT NULL
    ,item           VARCHAR(255) NOT NULL
    ,company        INT          NOT NULL
    ,division       INT          NOT NULL
    ,sold           INT          NOT NULL
    ,corporation    INT          NOT NULL
    ,department     INT          NOT NULL
    ,ship_to        INT          NOT NULL
    ,history_avg    FLOAT        NOT NULL
    ,history_stdDev FLOAT        NOT NULL
    ,percent_stdDev FLOAT        NOT NULL
    ,percent_MAD    FLOAT        NOT NULL
    ,total_run      FLOAT        NOT NULL
    ,total_percent  FLOAT        NOT NULL
    ,Class          VARCHAR(5)   NOT NULL
)
GO


/*********************************
 *  gen_MAD_Output
 *********************************/ 
DROP PROCEDURE gen_MAD_Output
GO 

CREATE PROCEDURE gen_MAD_Output
AS
BEGIN
     SET NOCOUNT ON

     TRUNCATE TABLE tbl_MAD_Output

     -------------------------------------------------------
     --  Calculate Avg for each Row  
     -------------------------------------------------------
     INSERT INTO tbl_MAD_Output
     SELECT  id
          , ISNULL(item,0)
          , ISNULL(company, 0)
          , ISNULL(division, 0)
          , ISNULL(sold, 0)
          , corporation
          , department
          , ship_to
          ,    (                history_1  +  history_2 +  history_3 +  history_4 +  history_5 +  history_6 +  history_7 
                 + history_8  + history_9  + history_10 + history_11 + history_12 + history_13 + history_14 + history_15 
                 + history_16 + history_17 + history_18 + history_19 + history_20 + history_21 + history_22 + history_23 
                 + history_24 + history_25 + history_26 + history_27 + history_28 + history_29 + history_30 + history_31
                 + history_32 + history_33 + history_34 + history_35 + history_36 + history_37 + history_38 + history_39
                 + history_40 + history_41 ) / 41.0    -- history_avg
          , 0                                          -- StdDev
          , 0		                               -- StdDev%
          , 0                                          -- Mean Avg Dev%
          , 0                                          -- total_run
          , 0                                          -- total_percent
          , ""                                         -- classificiation ABC
       FROM tbl_MAD_Input




     -------------------------------------------------------
     -- Remove A Rows that have Avg of 0 
     -------------------------------------------------------
     DELETE FROM tbl_MAD_Output
       WHERE item IS NULL
          OR history_avg = 0 



     -------------------------------------------------------
     -- Calculate StdDev for each row
     -------------------------------------------------------
     UPDATE tbl_MAD_Output
        SET history_stdDev = SQRT(  (SQUARE( history_1 - tbl_MAD_Output.history_avg) 
                                   + SQUARE( history_2 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_3 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_4 - tbl_MAD_Output.history_avg) 
                                   + SQUARE( history_5 - tbl_MAD_Output.history_avg) 
                                   + SQUARE( history_6 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_7 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_8 - tbl_MAD_Output.history_avg)
                                   + SQUARE( history_9 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_10 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_11 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_12 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_13 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_14 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_15 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_16 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_17 - tbl_MAD_Output.history_avg) 
                                   + SQUARE(history_18 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_19 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_20 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_21 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_22 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_23 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_24 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_25 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_26 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_27 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_28 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_29 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_30 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_31 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_32 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_33 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_34 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_35 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_36 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_37 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_38 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_39 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_40 - tbl_MAD_Output.history_avg)
                                   + SQUARE(history_41 - tbl_MAD_Output.history_avg) ) / (41.0 - 1.0) )
        FROM tbl_MAD_Input
       WHERE tbl_MAD_Input.id = tbl_MAD_Output.id


     -------------------------------------------------------
     -- Calculate StdDev% & MAD%
     -------------------------------------------------------
     UPDATE tbl_MAD_Output
        SET percent_stdDev  = history_stdDev  / history_avg 
           ,percent_MAD     = history_stdDev  / history_avg  / 1.25



     -------------------------------------------------------
     -- Calculate Running Total of Avg, sorted by StdDev%
     -------------------------------------------------------

     -- Have to order the table by StdDev%
     SELECT id, percent_stddev, history_avg, total_run
       INTO #tbl_mad_output_temp
       FROM tbl_mad_output
      ORDER BY percent_stddev


     -- Do the Running Total on history_avg based on sort of StdDev%
     DECLARE @RRT FLOAT
     SET @RRT = 0
     UPDATE #tbl_mad_output_temp
        SET @RRT = total_run = @RRT + history_avg


     -- Put Back the results
     UPDATE  tbl_mad_output
        SET total_run = #tbl_mad_output_temp.total_run
       FROM #tbl_mad_output_temp
      WHERE tbl_mad_output.id = #tbl_mad_output_temp.id

 
     -- Get Rid of Temp Tables
     DROP TABLE #tbl_mad_output_temp



     -------------------------------------------------------
     --  Get The Sum Avg Total
     -------------------------------------------------------
     DECLARE @fltAvgSumTotal AS FLOAT
     SELECT @fltAvgSumTotal  = SUM(history_avg) 
       FROM tbl_MAD_Output



     -------------------------------------------------------
     -- Calculate the %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output 
        SET total_percent = total_run / @fltAvgSumTotal * 100
  

     -------------------------------------------------------
     -- Calculate the Code Classification based on %TTL
     -------------------------------------------------------
     UPDATE tbl_MAD_Output  SET class = 'A' WHERE                         total_percent  <= 10
     UPDATE tbl_MAD_Output  SET class = 'B' WHERE 10 < total_percent  AND total_percent  <= 20
     UPDATE tbl_MAD_Output  SET class = 'C' WHERE 20 < total_percent  AND total_percent  <= 30
     UPDATE tbl_MAD_Output  SET class = 'D' WHERE 30 < total_percent  AND total_percent  <= 40
     UPDATE tbl_MAD_Output  SET class = 'E' WHERE 40 < total_percent  AND total_percent  <= 50
     UPDATE tbl_MAD_Output  SET class = 'F' WHERE 50 < total_percent  AND total_percent  <= 60
     UPDATE tbl_MAD_Output  SET class = 'G' WHERE 60 < total_percent  AND total_percent  <= 70
     UPDATE tbl_MAD_Output  SET class = 'H' WHERE 70 < total_percent  AND total_percent  <= 80
     UPDATE tbl_MAD_Output  SET class = 'I' WHERE 80 < total_percent  AND total_percent  <= 90
     UPDATE tbl_MAD_Output  SET class = 'J' WHERE 90 < total_percent  AND total_percent  <= 100
END  
GO
