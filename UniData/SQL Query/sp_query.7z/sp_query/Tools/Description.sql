SELECT CubeMember.MemberName, CubeName, CubeMemberDescription.Description, CubeMemberDescription.OriginSourceInfoflo
FROM CubeMember
	INNER JOIN CubeMemberDescription
		ON CubeMember.MemberName = CubeMemberDescription.MemberName
WHERE CubeMemberDescription.Description <> ''
ORDER BY CubeName

SELECT CubeMember.MemberName, CubeName, CubeMemberDescription.Description, CubeMemberDescription.OriginSourceInfoflo
FROM CubeMember
	INNER JOIN CubeMemberDescription
		ON CubeMember.MemberName = CubeMemberDescription.MemberName
WHERE CubeMemberDescription.Description = ''
ORDER BY CubeName