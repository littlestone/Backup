CREATE  PROCEDURE sp_Update_InventoryMaterialResourcePlanning
WITH RECOMPILE
AS

DECLARE	@strMonth	varchar(7)
,	@dtmDate	smalldatetime

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryMaterialResourcePlanning')
BEGIN
	UPDATE	DataWarehouse..InventoryMaterialResourcePlanning
	SET	AnnualDemandQuantity = ISNULL(INVMRP.ABC_DEMAND, 0)
	FROM	DataWarehouse..InventoryMaterialResourcePlanning InventoryMaterialResourcePlanning
		INNER JOIN Source..INVMRP INVMRP
			ON InventoryMaterialResourcePlanning.WarehouseCode = RIGHT(INVMRP.ID, LEN(INVMRP.ID) - CHARINDEX('*', INVMRP.ID))
			AND InventoryMaterialResourcePlanning.ComputerizedPartNumber = LEFT(INVMRP.ID, CHARINDEX('*', INVMRP.ID) - 1)
	WHERE	AnnualDemandQuantity != ISNULL(INVMRP.ABC_DEMAND, 0)
END

SELECT	@dtmDate = CONVERT(varchar(10), DATEADD(day, -1, GETDATE()), 120)

SELECT	@strMonth = FiscalTime.FiscalMonth
FROM	DataWarehouse..FiscalTime FiscalTime
WHERE	@dtmDate BETWEEN FiscalTime.StartDate AND FiscalTime.EndDate

EXEC	sp_Update_InventoryMaterialResourcePlanning_Month @strMonth

GO
