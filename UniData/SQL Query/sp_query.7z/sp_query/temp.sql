ALTER     PROCEDURE dbo.sp_Update_PurchaseOrderDetail_CompanyUnitCost_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
	AND EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetailDelivery_' + @strYear)
BEGIN
	SELECT	@strSQL = 'UPDATE DataWarehouse..PurchaseOrderDetail_' + @strYear + ' ' +
			'SET	CompanyUnitCost = PurchaseOrderDetailDelivery.CompanyUnitCost' + ' ' +
			',	CompanyScheduleQuantity = PurchaseOrderDetailDelivery.CompanyScheduleQuantity' + ' ' +
			',	CompanyBalanceQuantity = PurchaseOrderDetailDelivery.CompanyBalanceQuantity' + ' ' +
			'FROM	DataWarehouse..PurchaseOrderDetail_' + @strYear + ' PurchaseOrderDetail' + ' ' +
			'	INNER JOIN' + ' ' + 
			'		SELECT' + ' ' +
			'			PurchaseOrderDetailDelivery.PurchaseOrderNumber' + ' ' +
			'			PurchaseOrderDetailDelivery.ReferenceNumber' + ' ' +
			'			ISNULL(SUM(PurchaseOrderDetailDelivery.CompanyScheduleQuantity), 0)' + ' ' +
			'			ISNULL(SUM(PurchaseOrderDetailDelivery.CompanyBalanceQuantity), 0)' + ' ' +			 
			'		FROM 	DataWarehouse..PurchaseOrderDetailDelivery_' + @strYear + ' PurchaseOrderDetailDelivery' + ' ' +
			'			ON PurchaseOrderDetail.PurchaseOrderNumber = PurchaseOrderDetailDelivery.PurchaseOrderNumber' + ' ' +
			'			AND PurchaseOrderDetail.ReferenceNumber = PurchaseOrderDetailDelivery.ReferenceNumber' + ' ' +
			'WHERE	PurchaseOrderDetail.CompanyUnitCost != PurchaseOrderDetailDelivery.CompanyUnitCost' + ' ' +
			'OR		 PurchaseOrderDetail.CompanyScheduleQuantity != PurchaseOrderDetailDelivery.CompanyScheduleQuantity' + ' ' +
			'OR		 PurchaseOrderDetail.CompanyBalanceQuantity != PurchaseOrderDetailDelivery.CompanyBalanceQuantity'

	EXEC	(@strSQL)
END
GO