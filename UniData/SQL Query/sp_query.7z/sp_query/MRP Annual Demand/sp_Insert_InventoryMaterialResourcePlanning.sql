CREATE   PROCEDURE sp_Insert_InventoryMaterialResourcePlanning
WITH RECOMPILE
AS

DECLARE	@strMonth	varchar(7)
,	@dtmDate	smalldatetime

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryMaterialResourcePlanning')
BEGIN
INSERT	DataWarehouse..InventoryMaterialResourcePlanning
		(WarehouseCode
	,	ComputerizedPartNumber
	,	AnnualDemandQuantity)
	SELECT	RIGHT(INVMRP.ID, LEN(INVMRP.ID) - CHARINDEX('*', INVMRP.ID))
	,	LEFT(INVMRP.ID, CHARINDEX('*', INVMRP.ID) - 1)
	,	ISNULL(INVMRP.ABC_DEMAND, 0)
	FROM	Source..INVMRP INVMRP
		LEFT JOIN DataWarehouse..InventoryMaterialResourcePlanning InventoryMaterialResourcePlanning
			ON RIGHT(INVMRP.ID, LEN(INVMRP.ID) - CHARINDEX('*', INVMRP.ID)) = InventoryMaterialResourcePlanning.WarehouseCode
			AND LEFT(INVMRP.ID, CHARINDEX('*', INVMRP.ID) - 1) = InventoryMaterialResourcePlanning.ComputerizedPartNumber
	WHERE	InventoryMaterialResourcePlanning.WarehouseCode IS NULL
	AND	InventoryMaterialResourcePlanning.ComputerizedPartNumber IS NULL
END

SELECT	@dtmDate = CONVERT(varchar(10), DATEADD(day, -1, GETDATE()), 120)

SELECT	@strMonth = FiscalTime.FiscalMonth
FROM	DataWarehouse..FiscalTime FiscalTime
WHERE	@dtmDate BETWEEN FiscalTime.StartDate AND FiscalTime.EndDate

EXEC	sp_Insert_InventoryMaterialResourcePlanning_Month @strMonth

GO
