UPDATE IHY
SET ProductLine = CAST(ProductLineID AS NVARCHAR)
FROM ProductLine
WHERE ProductLine COLLATE SQL_Latin1_General_CP850_CI_AI = ProductLineName



UPDATE IHR
SET StateProvince = StateCode
FROM StatesProvincesDetails
WHERE StateProvince COLLATE SQL_Latin1_General_CP850_CI_AI = StateName

UPDATE IHY
SET Notes = ''


SELECT *
FROM Retailer
	INNER JOIN IHR
		ON CAST(IHR.ProductLine AS INT) = Retailer.ProductLineID  
		AND IHR.StateProvince COLLATE SQL_Latin1_General_CP850_CI_AI = Retailer.StateCode  
		AND IHR.Retailer COLLATE SQL_Latin1_General_CP850_CI_AI = Retailer.RetailerName 



SET IDENTITY_INSERT Retailer OFF
INSERT Retailer 
(LanguageID,
ProductLineID,
StateCode,
RetailerName,
RetailerWebSite,
RetailerNotes)
SELECT 2, ProductLine, StateProvince, Retailer, WebSite, Notes
FROM IHY
	LEFT JOIN Retailer
		ON CAST(IHY.ProductLine AS INT) = Retailer.ProductLineID  
		AND IHY.StateProvince COLLATE SQL_Latin1_General_CP850_CI_AI = Retailer.StateCode  
		AND IHY.Retailer COLLATE SQL_Latin1_General_CP850_CI_AI = Retailer.RetailerName
AND LanguageID = 2
WHERE StateProvince IS NOT NULL
AND RetailerID IS NULL
ORDER BY Retailer



SELECT *
FROM Retailer
WHERE RetailerLogo IS NULL

UPDATE Retailer
SET RetailerLogo = 'img_retailer_' + CAST(RetailerID AS NVARCHAR) + '.jpg'  
WHERE RetailerLogo IS NULL

UPDATE Retailer
SET RetailerWebSite = WebSite 
FROM IHY
	LEFT JOIN Retailer 
		ON CAST(IHY.ProductLine AS INT) = Retailer.ProductLineID  
		AND IHY.StateProvince COLLATE SQL_Latin1_General_CP850_CI_AI = Retailer.StateCode  
		AND IHY.Retailer COLLATE SQL_Latin1_General_CP850_CI_AI = Retailer.RetailerName
AND LanguageID = 2
WHERE StateProvince IS NOT NULL
AND WebSite COLLATE SQL_Latin1_General_CP850_CI_AI <> RetailerWebSite


SELECT *
FROM Retailer
WHERE RetailerName = 'RONA'
AND LanguageID = 2 





UPDATE Retailer
SET RetailerNotes = Notes
FROM IHY
	LEFT JOIN Retailer
		ON CAST(IHY.ProductLine AS INT) = Retailer.ProductLineID  
		AND IHY.StateProvince COLLATE SQL_Latin1_General_CP850_CI_AI = Retailer.StateCode  
		AND IHY.Retailer COLLATE SQL_Latin1_General_CP850_CI_AI = Retailer.RetailerName
AND LanguageID = 2
WHERE StateProvince IS NOT NULL
AND Notes COLLATE SQL_Latin1_General_CP850_CI_AI <> RetailerNotes


