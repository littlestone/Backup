
ALTER   PROCEDURE dbo.sp_Update_GeneralLedgerAccount_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..GeneralLedgerAccount
SET	Active = 0
WHERE	NULLIF(GeneralLedgerAccountCode, '') IS NOT NULL		-- GeneralLedgerAccountCode != ''

SELECT	GeneralLedgerAccount.GeneralLedgerAccountCode			-- Create temporary table
INTO	#GeneralLedgerAccount
FROM	DataWarehouse..GeneralLedgerAccount GeneralLedgerAccount
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#GeneralLedgerAccount' + ' ' +
					'	(GeneralLedgerAccountCode)' + ' ' +	
					'SELECT	DISTINCT' + ' ' +
					'	PurchaseOrderDetail.GeneralLedgerAccountCode' + ' ' + 
					'FROM	DataWarehouse..PurchaseOrderDetail_' + @strYear + ' ' + 'PurchaseOrderDetail' + ' ' + 
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' ' + 'PurchaseOrderHeaderLineItem' + ' ' + 
					'		ON PurchaseOrderDetail.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'			AND PurchaseOrderDetail.ReferenceNumber = PurchaseOrderHeaderLineItem.ReferenceNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X'''
		EXEC	(@strSQL)
	END
	
	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..GeneralLedgerAccount
SET	Active = 1
FROM	DataWarehouse..GeneralLedgerAccount GeneralLedgerAccount
	INNER JOIN #GeneralLedgerAccount
		ON GeneralLedgerAccount.GeneralLedgerAccountCode = #GeneralLedgerAccount.GeneralLedgerAccountCode

DROP	TABLE #GeneralLedgerAccount
GO
