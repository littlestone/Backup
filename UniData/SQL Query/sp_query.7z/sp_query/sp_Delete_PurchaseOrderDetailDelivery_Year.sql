ALTER     PROCEDURE dbo.sp_Delete_PurchaseOrderDetailDelivery_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetailDelivery_' + @strYear)
BEGIN
	SELECT	@strSQL = 'DELETE DataWarehouse..PurchaseOrderDetailDelivery_' + @strYear + ' ' +
			'FROM	DataWarehouse..PurchaseOrderDetailDelivery_' + @strYear + ' PurchaseOrderDetailDelivery' + ' ' +
			'WHERE	EXISTS (SELECT	CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END' + ' ' +
			'		FROM	Source..PODET PODET' + ' ' +
			'			INNER JOIN Source..POHDR POHDR' + ' ' +
			'				ON CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END = POHDR.PO_NBR' + ' ' +
			'		WHERE	POHDR.FISCAL_PERIOD LIKE ''' + @strYear + '%''' + ' ' +
			'		AND	PurchaseOrderDetailDelivery.PurchaseOrderNumber = CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END' + ' ' +
			'		AND	PurchaseOrderDetailDelivery.ReferenceNumber = CASE WHEN LEN(PODET.ID) <= 5 THEN '''' ELSE LEFT(PODET.ID, 5) END)'

	EXEC	(@strSQL)
END
GO
