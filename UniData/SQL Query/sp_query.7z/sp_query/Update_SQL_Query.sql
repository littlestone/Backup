UPDATE DataWarehouse..PurchaseOrderDetail_2007
SET	CompanyScheduleQuantity = 0
,	CompanyBalanceQuantity = 0
,	CompanyReceiveQuantity = 0
WHERE CompanyScheduleQuantity IS NULL
OR	CompanyBalanceQuantity IS NULL
OR	CompanyReceiveQuantity IS NULL


