SELECT PurchaseOrderDetailDelivery.PurchaseOrderNumber
,	PurchaseOrderDetailDelivery.ReferenceNumber
,	PurchaseOrderDetailDelivery.CompanyUnitCost
,	PurchaseOrderDetailDelivery.CompanyScheduleQuantity
,	PurchaseOrderDetailDelivery.CompanyBalanceQuantity
INTO	#PurchaseOrderDetailDelivery
FROM DataWarehouse..PurchaseOrderDetailDelivery_2008 PurchaseOrderDetailDelivery
WHERE 0 = 1


SELECT  PurchaseOrderDetailReceipt.PurchaseOrderNumber
,	PurchaseOrderDetailReceipt.ReferenceNumber
,	PurchaseOrderDetailReceipt.CompanyReceiveQuantity
,	PurchaseOrderDetail.PurchaseOrderNumber
,	PurchaseOrderDetail.ReferenceNumber
,	PurchaseOrderDetail.CompanyReceiveQuantity
FROM	DataWarehouse..PurchaseOrderDetailReceipt_2008 PurchaseOrderDetailReceipt 
INNER JOIN DataWarehouse..PurchaseOrderDetail_2008 PurchaseOrderDetail
	ON PurchaseOrderDetailReceipt.PurchaseOrderNumber = PurchaseOrderDetail.PurchaseOrderNumber
	AND PurchaseOrderDetailReceipt.ReferenceNumber = PurchaseOrderDetail.ReferenceNumber





UPDATE DataWarehouse..PurchaseOrderDetail_2008
SET	CompanyUnitCost = 0
,	CompanyScheduleQuantity = 0
,	CompanyBalanceQuantity = 0
,	CompanyReceiveQuantity = 0


EXEC sp_Update_PurchaseOrderDetail_PurchaseOrderDelivery

EXEC sp_Update_PurchaseOrderDetail_PurchaseOrderReceipt


DROP TABLE #PurchaseOrderDetailDelivery


