-- Cube Budget
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13)
WHERE CubeName = 'Budget'



-- Cube BudgetSales
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (12MTD)' + ' - ' + CHAR(13) +
		'Last 12 months-to-date rolling total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Current/Previous %)' + ' - ' + CHAR(13) +
		'Current month-to-date vs. Previous year''s month-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Current/Previous %)' + ' - ' + CHAR(13) +
		'Current year-to-date vs. Previous year''s year-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13) +
		CHAR(13) +
		'Note: YTD/12MTD values are only meaningful when analyzing specific fiscal months. They must not be used for analysis performed on complete fiscal years.' + CHAR(13)
WHERE CubeName = 'BudgetSales'


-- CubeForecast
UPDATE CubeCommonTermDescription
SET Description = 'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13)
WHERE CubeName = 'Forecast'


-- CubeForecastBudgetSales
UPDATE CubeCommonTermDescription
SET Description = 'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13)
WHERE CubeName = 'ForecastBudgetSales'


-- CubeFreght
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Current' + ' - ' + 'Using current fiscal period�s costs or rates' + CHAR(13) +
		'Historic' + ' - ' + 'Using costs or rates at the time of fiscal period chosen' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Total for the measure and fiscal period selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD - Variance %))' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD - Variance))' + ' - ' + CHAR(13) +
		'Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD)' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance)' + ' - ' + CHAR(13) +
		'Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13)
WHERE CubeName = 'Freight'



-- CubeInventory
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Current' + ' - ' + 'Using current fiscal period�s costs or rates' + CHAR(13) +
		'Historic' + ' - ' + 'Using costs or rates at the time of fiscal period chosen' + CHAR(13) +
		CHAR(13) +
		'Cost (or Tatal Cost)' + ' - ' + CHAR(13) +
		'Fixed Cost + Material Cost + Outside Cost + Variable Cost' + CHAR(13) +
		CHAR(13) +
		'Fixed Cost' + ' - ' + CHAR(13) +
		'Expenses that do not vary with volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Material Cost' + ' - ' + CHAR(13) +
		'Cost of raw materials used to produce the product' + CHAR(13) +
		CHAR(13) +
		'Outside Cost' + ' - ' + CHAR(13) +
		'Expenses to produce a product through outsourcing' + CHAR(13) +
		CHAR(13) +
		'Variable Cost' + ' - ' + CHAR(13) +
		'Expenses that vary in proprotion to volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Total for fiscal period chosen' + CHAR(13) +
		CHAR(13) +
		'Note: The Inventory cube is built from a �snapshot� of the current inventory in time.  For this reason, analysis must be performed on fiscal months to provide meaningful results.' + CHAR(13)
WHERE CubeName = 'Inventory'



-- CubeInventoryAudit
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Current' + ' - ' + 'Using current fiscal period�s costs or rates' + CHAR(13) +
		'Historic' + ' - ' + 'Using costs or rates at the time of fiscal period chosen' + CHAR(13) +
		CHAR(13) +
		'Cost (or Tatal Cost)' + ' - ' + CHAR(13) +
		'Fixed Cost + Material Cost + Outside Cost + Variable Cost' + CHAR(13) +
		CHAR(13) +
		'Fixed Cost' + ' - ' + CHAR(13) +
		'Expenses that do not vary with volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Material Cost' + ' - ' + CHAR(13) +
		'Cost of raw materials used to produce the product' + CHAR(13) +
		CHAR(13) +
		'Outside Cost' + ' - ' + CHAR(13) +
		'Expenses to produce a product through outsourcing' + CHAR(13) +
		CHAR(13) +
		'Variable Cost' + ' - ' + CHAR(13) +
		'Expenses that vary in proprotion to volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13)
WHERE CubeName = 'InventoryAudit'



-- CubeInventoryBudgetSales
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Current' + ' - ' + 'Using current fiscal period�s costs or rates' + CHAR(13) +
		'Historic' + ' - ' + 'Using costs or rates at the time of fiscal period chosen' + CHAR(13) +
		CHAR(13) +
		'Cost (or Tatal Cost)' + ' - ' + CHAR(13) +
		'Fixed Cost + Material Cost + Outside Cost + Variable Cost' + CHAR(13) +
		CHAR(13) +
		'Fixed Cost' + ' - ' + CHAR(13) +
		'Expenses that do not vary with volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Material Cost' + ' - ' + CHAR(13) +
		'Cost of raw materials used to produce the product' + CHAR(13) +
		CHAR(13) +
		'Outside Cost' + ' - ' + CHAR(13) +
		'Expenses to produce a product through outsourcing' + CHAR(13) +
		CHAR(13) +
		'Variable Cost' + ' - ' + CHAR(13) +
		'Expenses that vary in proprotion to volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (12MTD)' + ' - ' + CHAR(13) +
		'Last 12 months-to-date rolling total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Current/Previous %)' + ' - ' + CHAR(13) +
		'Current month-to-date vs. Previous year''s month-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Current/Previous %)' + ' - ' + CHAR(13) +
		'Current year-to-date vs. Previous year''s year-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13) +
		CHAR(13) +
		'Note: YTD/12MTD values are only meaningful when analyzing specific fiscal months. They must not be used for analysis performed on complete fiscal years.' + CHAR(13) +
		CHAR(13) +
		'Note: The Inventory cube is built from a �snapshot� of the current inventory in time.  For this reason, analysis must be performed on fiscal months to provide meaningful results.' + CHAR(13)
WHERE CubeName = 'InventoryBudgetSales'


-- CubeInventoryProductionSales
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Current' + ' - ' + 'Using current fiscal period�s costs or rates' + CHAR(13) +
		'Historic' + ' - ' + 'Using costs or rates at the time of fiscal period chosen' + CHAR(13) +
		CHAR(13) +
		'Cost (or Tatal Cost)' + ' - ' + CHAR(13) +
		'Fixed Cost + Material Cost + Outside Cost + Variable Cost' + CHAR(13) +
		CHAR(13) +
		'Fixed Cost' + ' - ' + CHAR(13) +
		'Expenses that do not vary with volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Material Cost' + ' - ' + CHAR(13) +
		'Cost of raw materials used to produce the product' + CHAR(13) +
		CHAR(13) +
		'Outside Cost' + ' - ' + CHAR(13) +
		'Expenses to produce a product through outsourcing' + CHAR(13) +
		CHAR(13) +
		'Variable Cost' + ' - ' + CHAR(13) +
		'Expenses that vary in proprotion to volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (12MTD)' + ' - ' + CHAR(13) +
		'Last 12 months-to-date rolling total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Current/Previous %)' + ' - ' + CHAR(13) +
		'Current month-to-date vs. Previous year''s month-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Current/Previous %)' + ' - ' + CHAR(13) +
		'Current year-to-date vs. Previous year''s year-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13) +
		CHAR(13) +
		'Note: YTD/12MTD values are only meaningful when analyzing specific fiscal months. They must not be used for analysis performed on complete fiscal years.' + CHAR(13) +
		CHAR(13) +
		'Note: The Inventory cube is built from a �snapshot� of the current inventory in time.  For this reason, analysis must be performed on fiscal months to provide meaningful results.' + CHAR(13) +
		'Current' + ' - ' + 'Using current fiscal period�s costs or rates' + CHAR(13) +
		'Historic' + ' - ' + 'Using costs or rates at the time of fiscal period chosen' + CHAR(13) +
		CHAR(13) +
		'Note:' + CHAR(13) +
		'Added Kgs' + ' - ' + 'Information taken from product information' + CHAR(13) +
		'Kgs' + ' - ' + 'Information taken from product information' + CHAR(13) +
		'Historic Kgs' + ' - ' + 'Information taken directly from production schedule' + CHAR(13)
WHERE CubeName = 'InventoryProductionSales'


-- CubeInventorySales
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Current' + ' - ' + 'Using current fiscal period�s costs or rates' + CHAR(13) +
		'Historic' + ' - ' + 'Using costs or rates at the time of fiscal period chosen' + CHAR(13) +
		CHAR(13) +
		'Cost (or Tatal Cost)' + ' - ' + CHAR(13) +
		'Fixed Cost + Material Cost + Outside Cost + Variable Cost' + CHAR(13) +
		CHAR(13) +
		'Fixed Cost' + ' - ' + CHAR(13) +
		'Expenses that do not vary with volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Material Cost' + ' - ' + CHAR(13) +
		'Cost of raw materials used to produce the product' + CHAR(13) +
		CHAR(13) +
		'Outside Cost' + ' - ' + CHAR(13) +
		'Expenses to produce a product through outsourcing' + CHAR(13) +
		CHAR(13) +
		'Variable Cost' + ' - ' + CHAR(13) +
		'Expenses that vary in proprotion to volume level of activity' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (12MTD)' + ' - ' + CHAR(13) +
		'Last 12 months-to-date rolling total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Current/Previous %)' + ' - ' + CHAR(13) +
		'Current month-to-date vs. Previous year''s month-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Current/Previous %)' + ' - ' + CHAR(13) +
		'Current year-to-date vs. Previous year''s year-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13) +
		CHAR(13) +
		'Note: YTD/12MTD values are only meaningful when analyzing specific fiscal months. They must not be used for analysis performed on complete fiscal years.' + CHAR(13) +
		CHAR(13) +
		'Note: The Inventory cube is built from a �snapshot� of the current inventory in time.  For this reason, analysis must be performed on fiscal months to provide meaningful results.' + CHAR(13)
WHERE CubeName = 'InventorySales'


-- CubeOrder
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Total for the measure and fiscal period selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD - Variance %))' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD)' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13)
WHERE CubeName = 'Order'



-- CubeOrderFill
UPDATE CubeCommonTermDescription
SET Description = 'Measure Name' + ' - ' + CHAR(13) +
		'Total for the measure and fiscal period selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD)' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (MTD - Variance %))' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13)
WHERE CubeName = 'OrderFill'


-- CubeProduction
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		CHAR(13) +
		'Current' + ' - ' + 'Using current fiscal period�s costs or rates' + CHAR(13) +
		'Historic' + ' - ' + 'Using costs or rates at the time of fiscal period chosen' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Note:' + CHAR(13) +
		'Added Kgs' + ' - ' + 'Information taken from product information' + CHAR(13) +
		'Kgs' + ' - ' + 'Information taken from product information' + CHAR(13) +
		'Historic Kgs' + ' - ' + 'Information taken directly from production schedule' + CHAR(13)
WHERE CubeName = 'Production'


-- CubePurchase
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13)
WHERE CubeName = 'Purchase'



-- CubeSales
UPDATE CubeCommonTermDescription
SET Description = 'CAD' + ' - ' + 'Canadian Dollars $ (Based on currency rate of fiscal time)' + CHAR(13) + 
		'USD' + ' - ' + 'US American Dollars $ (Same as CAD)' + CHAR(13) +	
		CHAR(13) +
		'Kgs' + ' - ' + 'Kilograms (1 Kg = 2.205 Lbs)' + CHAR(13) +
		'Lbs' + ' - ' + 'Pounds (1 Lb = 0.454 Kgs)' + CHAR(13) +
		CHAR(13) +
		'Measure Name' + ' - ' + CHAR(13) +
		'Month-to-date total for the measure selected up to and including the last date for the month' + CHAR(13) +
		CHAR(13) +
		'Measure Name (12MTD)' + ' - ' + CHAR(13) +
		'Last 12 months-to-date rolling total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Current/Previous %)' + ' - ' + CHAR(13) +
		'Current month-to-date vs. Previous year''s month-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full month-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current month-to-date vs. previous year month-to-date ((Current - Previous) / Previous)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Current/Previous %)' + ' - ' + CHAR(13) +
		'Current year-to-date vs. Previous year''s year-to-date ratio' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Previous)' + ' - ' + CHAR(13) +
		'Previous year''s full year-to-date total for the measure selected' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD - Variance %)' + ' - ' + CHAR(13) +
		'% Variance between current year-todate vs. previous year year-to-date ((Current YTD - Previous YTD) / Previous YTD)' + CHAR(13) +
		CHAR(13) +
		'Measure Name (YTD)' + ' - ' + CHAR(13) +
		'Year-to-date total for the measure selected up to and including the last date for the year' + CHAR(13) +
		CHAR(13) +
		'Note: YTD/12MTD values are only meaningful when analyzing specific fiscal months. They must not be used for analysis performed on complete fiscal years.' + CHAR(13)
WHERE CubeName = 'Sales'


--INSERT CubeInventoryAudit
--SELECT ID-4488 ID, MemberName, FieldLevel, ParentID, IsMeasure
--INTO CubeSales
--FROM CubeMember 
--WHERE CubeName = 'Sales'
--AND IsMeasure = 0
--AND RIGHT(MemberName, 1) <> ')'



