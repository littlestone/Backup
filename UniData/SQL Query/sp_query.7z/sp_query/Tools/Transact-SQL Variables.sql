-- Declare the variable to be used.
DECLARE @MyCounter int;

-- Initialize the variable.
SET @MyCounter = 4481


-- Test the variable to see if the loop is finished.
WHILE (@MyCounter < 4530)
BEGIN
   -- Insert a row into the table.
   INSERT INTO CubeMember (ID, CubeName, IsMeasure, FieldLevel, FieldOrder, ParentID)
   VALUES (CAST(@MyCounter as nvarchar), 'Sales', 0, 1, 0, 0)
   -- Increment the variable to count this iteration
   -- of the loop.
   SET @MyCounter = @MyCounter + 1
END


INSERT CubeMemberDescription
SELECT DISTINCT CubeMember.MemberName, '', ''
--SELECT *
FROM CubeMember
	LEFT JOIN CubeMemberDescription
		ON CubeMember.MemberName = CubeMemberDescription.MemberName
WHERE CubeMemberDescription.MemberName IS NULL

SELECT MAX(ID)
FROM CubeMember

SELECT *
INTO CubeMember_20080421
FROM CubeMember

SELECT *
INTO CubeMemberDescription_200804222
FROM CubeMemberDescription

SELECT *
INTO CubeMemberDescription_Backup
FROM CubeMemberDescription



INSERT CubeMember
SELECT *
FROM #bingo

UPDATE #bingo
SET ID = CAST((CAST(ID AS INTEGER) + 7) AS NVARCHAR)

SELECT *
INTO #bingo
FROM CubeMember
WHERE ID BETWEEN '165' AND '4990'

DROP Table #bingo

SELECT *
FROM #bingo

UPDATE #bingo
SET CubeName = 'Sales'

UPDATE #bingo
SET MemberName = RIGHT(MemberName, LEN(MemberName) - 5)

UPDATE CubeMemberDescription
SET OriginSourceInfoflo = ''

SELECT *
FROM #bingo
WHERE RIGHT(MemberName, LEN('(Current/Previous %)')) = '(Current/Previous %)'
AND Description = ''



UPDATE CubeMemberDescription
SET Description = 'Year-to-date total for the measure selected up to and including the last date for the year'
FROM CubeMemberDescription
WHERE RIGHT(MemberName, LEN('(YTD)')) = '(YTD)'
AND Description = ''

SELECT 'Previous year''s full month-to-date total for the measure selected'

SELECT *
FROM #bingo




-- Declare the variable to be used.
DECLARE @MyCounter int;

-- Initialize the variable.
SET @MyCounter = 0


-- Test the variable to see if the loop is finished.
WHILE (@MyCounter < 82)
BEGIN
   -- Insert a row into the table.
   INSERT CubeMemberDescriptionDetails(DescriptionCode)
   VALUES (@MyCounter)

   -- Increment the variable to count this iteration
   -- of the loop.
   SET @MyCounter = @MyCounter + 1
END

INSERT CubeMemberDescriptionDetails
SELECT Description
FROM #bingo

SELECT DISTINCT Description
INTO #bingo
FROM CubeMemberDescription
WHERE Description <> ''



SELECT *
FROM CubeMember
WHERE MemberName = 'Production Actual / Standard % Current Total Cost CAD'

SELECT CubeMemberDescription.MemberName
FROM CubeMemberDescription
	INNER JOIN CubeMember
		ON CubeMemberDescription.MemberName = CubeMember.MemberName
WHERE Description = ''
AND CubeName <> 'Finance'
AND RIGHT(CubeMemberDescription.MemberName, 9) <> 'Variance)'

