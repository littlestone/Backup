

ALTER   PROCEDURE dbo.sp_Update_Warehouse_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..Warehouse
SET	Active = 0
WHERE	NULLIF(WarehouseCode, '') IS NOT NULL

SELECT	Warehouse.WarehouseCode
INTO	#Warehouse
FROM	DataWarehouse..Warehouse Warehouse
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryWarehouse_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Warehouse' + ' ' +
					'	(WarehouseCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	InventoryWarehouse.WarehouseCode' + ' ' +
					'FROM	DataWarehouse..InventoryWarehouse_' + @strYear + ' InventoryWarehouse' + ' ' +
					'WHERE	InventoryWarehouse.BookedQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.OnHandQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.InMaterialReviewBoardQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.InReceiptInInspectionQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.InTransitQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.ManufacturingAllocationQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.AllocationQuantity != 0'
		EXEC	(@strSQL)
	END
	
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'BillOfLading_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Warehouse' + ' ' +
					'	(WarehouseCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	BillOfLading.ShippingWarehouseCode' + ' ' +
					'FROM	DataWarehouse..BillOfLading_' + @strYear + ' BillOfLading' + ' ' +
					'UNION' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	BillOfLading.ReceivingWarehouseCode' + ' ' +
					'FROM	DataWarehouse..BillOfLading_' + @strYear + ' BillOfLading'
		EXEC	(@strSQL)
	END
	
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Invoice_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Warehouse' + ' ' +
					'	(WarehouseCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	Invoice.WarehouseCode' + ' ' +
					'FROM	DataWarehouse..Invoice_' + @strYear + ' Invoice'
		EXEC	(@strSQL)
	END
	
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryTrail_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Warehouse' + ' ' +
					'	(WarehouseCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	InventoryTrail.WarehouseCode' + ' ' +
					'FROM	DataWarehouse..InventoryTrail_' + @strYear + ' InventoryTrail' + ' ' +
					'UNION' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	InventoryTrail.TransferWarehouseCode' + ' ' +
					'FROM	DataWarehouse..InventoryTrail_' + @strYear + ' InventoryTrail'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'SalesOrder_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Warehouse' + ' ' +
					'	(WarehouseCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	SalesOrder.WarehouseCode' + ' ' +
					'FROM	DataWarehouse..SalesOrder_' + @strYear + ' SalesOrder' + ' ' +
					'WHERE	SalesOrder.LineItemStatusCode != ''C'''
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderHeader_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Warehouse' + ' ' +
					'	(WarehouseCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	PurchaseOrderHeader.WarehouseCode' + ' ' +
					'FROM	DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' + 
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' PurchaseOrderHeaderLineItem' + ' ' +
					'		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X'''
		EXEC	(@strSQL)
	END


	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..Warehouse
SET	Active = 1
FROM	DataWarehouse..Warehouse Warehouse
	INNER JOIN #Warehouse
		ON Warehouse.WarehouseCode = #Warehouse.WarehouseCode

DROP	TABLE #Warehouse
GO
