CREATE   VIEW vw_DataMart_V2_Purchase_Delivery
AS
SELECT 	PurchaseOrderHeader.PurchaseOrderNumber
,	PurchaseOrderHeader.SupplierCode
,	PurchaseOrderHeader.PurchaseOrderDate
,	PurchaseOrderHeader.BuyerCode
,	PurchaseOrderHeader.PurchaseOrderTypeCode
,	PurchaseOrderHeader.ChangeDate
,	PurchaseOrderHeader.ShipToCode
,	PurchaseOrderHeader.ShipToName
,	PurchaseOrderHeader.ShipToAddressLine1
,	PurchaseOrderHeader.ShipToAddressLine2
,	PurchaseOrderHeader.ShipToAddressLine3
,	PurchaseOrderHeader.ShipToAddressLine4
,	PurchaseOrderHeader.ShipToAddressLine5
,	PurchaseOrderHeader.ShipToAddressLine6
,	PurchaseOrderHeader.FreightCarrierCode
,	PurchaseOrderHeader.FreightOnBoardCode
,	PurchaseOrderHeader.ContactName
,	PurchaseOrderHeader.ConfirmCode
,	PurchaseOrderHeader.PurchasePayTermCode
,	PurchaseOrderHeader.CompanyCode
,	PurchaseOrderHeader.ConfirmDate
,	PurchaseOrderHeader.CurrencyCode AS SupplierCurrencyCode
,	PurchaseOrderHeader.ConversionRate
,	PurchaseOrderHeader.WarehouseCode
,	PurchaseOrderHeader.PurchaseOrderClassCode
,	PurchaseOrderHeader.FreightTermCode
,	PurchaseOrderHeader.CompanyReferenceNumber
,	PurchaseOrderHeader.QuoteNumber
,	PurchaseOrderHeader.DivisionCode
,	PurchaseOrderHeader.FiscalPeriodCode
,	PurchaseOrderHeader.OrderStatusCode
,	PurchaseOrderHeader.CompanyCodeSupplierCode
,	PurchaseOrderHeader.CompanyCodeDivisionCode
,	PurchaseOrderHeaderLineItem.LineItemNumber
,	PurchaseOrderHeaderLineItem.LineItemStatusCode
,	PurchaseOrderDetail.CompanyUnitOfMeasureCode
,	PurchaseOrderDetail.ComputerizedPartNumber
,	PurchaseOrderDetail.PartDescription
,	PurchaseOrderDetail.SupplierPartNumber
,	PurchaseOrderDetail.ProductCode
,	PurchaseOrderDetail.GeneralLedgerAccountCode
,	PurchaseOrderDetail.WorkOrderNumber
,	PurchaseOrderDetail.ContractQuantity
,	PurchaseOrderDetail.ContractUnitPrice
,	PurchaseOrderDetail.SupplierUnitOfMeasureCode
,	PurchaseOrderDetail.ConversionFactor
,	PurchaseOrderDetail.InspectionRequestFlag
,	PurchaseOrderDetail.PartRevisionLevel
,	PurchaseOrderDetail.RequisitionNumber
,	PurchaseOrderDetail.RequestorName
,	PurchaseOrderDetail.TaxFlag
,	PurchaseOrderDetail.ChargeTypeCode
,	PurchaseOrderDetailDelivery.ScheduleDeliveryDate
,	PurchaseOrderDetailDelivery.CompanyScheduleQuantity
,	PurchaseOrderDetailDelivery.CompanyBalanceQuantity
,	PurchaseOrderDetail.CompanyUnitCost
,	PurchaseOrderDetailDelivery.ReferenceInfo
,	PurchaseOrderDetailDelivery.SupplierScheduleQuantity
,	PurchaseOrderDetailDelivery.SupplierBalanceQuantity
,	PurchaseOrderDetailDelivery.DockDate
,	PurchaseOrderDetailDelivery.SupplierUnitPrice
,	ISNULL(SupplierCurrencyRateCAD.CurrencyRate, 1) AS SupplierCurrencyRateCAD
,	ISNULL(SupplierCurrencyRateCAD.CurrencyRate, 1) / ISNULL(SupplierCurrencyRateUSD.CurrencyRate, 1) AS SupplierCurrencyRateUSD
,	Company.CurrencyCode AS CompanyCurrencyCode
,	ISNULL(CompanyCurrencyRateCAD.CurrencyRate, 1) AS CompanyCurrencyRateCAD
,	ISNULL(CompanyCurrencyRateCAD.CurrencyRate, 1) / ISNULL(CompanyCurrencyRateUSD.CurrencyRate, 1) AS CompanyCurrencyRateUSD
,	1 AS DeliveryCount
,	ISNULL(Product.UnitWeight, 0) AS UnitWeight
FROM	DataWarehouse..PurchaseOrderHeader_2001 PurchaseOrderHeader
	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_2001 PurchaseOrderHeaderLineItem
		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber
	INNER JOIN DataWarehouse..PurchaseOrderDetail_2001 PurchaseOrderDetail
		ON PurchaseOrderHeaderLineItem.PurchaseOrderNumber = PurchaseOrderDetail.PurchaseOrderNumber
		AND PurchaseOrderHeaderLineItem.ReferenceNumber = PurchaseOrderDetail.ReferenceNumber
	INNER JOIN DataWarehouse..PurchaseOrderDetailDelivery_2001 PurchaseOrderDetailDelivery
		ON PurchaseOrderDetail.PurchaseOrderNumber = PurchaseOrderDetailDelivery.PurchaseOrderNumber
		AND PurchaseOrderDetail.ReferenceNumber = PurchaseOrderDetailDelivery.ReferenceNumber
	LEFT JOIN DataWarehouse..CurrencyRate SupplierCurrencyRateCAD
		ON PurchaseOrderHeader.CurrencyCode = SupplierCurrencyRateCAD.ToCurrencyCode		AND 'CAD' = SupplierCurrencyRateCAD.FromCurrencyCode
		AND PurchaseOrderHeader.FiscalPeriodCode = SupplierCurrencyRateCAD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate SupplierCurrencyRateUSD
		ON 'CAD' = SupplierCurrencyRateUSD.FromCurrencyCode
		AND 'USD' = SupplierCurrencyRateUSD.ToCurrencyCode
		AND PurchaseOrderHeader.FiscalPeriodCode = SupplierCurrencyRateUSD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..Company Company
		ON PurchaseOrderHeader.CompanyCode = Company.CompanyCode
	LEFT JOIN DataWarehouse..CurrencyRate CompanyCurrencyRateCAD
		ON Company.CurrencyCode = CompanyCurrencyRateCAD.FromCurrencyCode		AND 'CAD' = CompanyCurrencyRateCAD.ToCurrencyCode
		AND PurchaseOrderHeader.FiscalPeriodCode = CompanyCurrencyRateCAD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CompanyCurrencyRateUSD
		ON 'CAD' = CompanyCurrencyRateUSD.FromCurrencyCode
		AND 'USD' = CompanyCurrencyRateUSD.ToCurrencyCode
		AND PurchaseOrderHeader.FiscalPeriodCode = CompanyCurrencyRateUSD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..Product Product
		ON PurchaseOrderDetail.ComputerizedPartNumber = Product.ComputerizedPartNumber
WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != 'X'
AND		0 = 1









