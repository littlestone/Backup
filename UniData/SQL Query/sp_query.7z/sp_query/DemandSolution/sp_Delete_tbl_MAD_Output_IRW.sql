CREATE PROCEDURE dbo.sp_Delete_tbl_MAD_Output_IRW
AS

TRUNCATE TABLE	DemandSolutions..tbl_MAD_Output_IRW

GO
