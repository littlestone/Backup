ALTER PROCEDURE dbo.sp_Update_StateProvince AS
UPDATE	DataWarehouse..StateProvince
SET	StateProvinceName = ISNULL(SYSTBL_TAX.DF_PL_DESC, '')
FROM	Source..SYSTBL_TAX SYSTBL_TAX
	INNER JOIN DataWarehouse..StateProvince StateProvince
		ON SYSTBL_TAX.DF_PL = StateProvince.StateProvinceCode
WHERE	StateProvince.StateProvinceName != ISNULL(SYSTBL_TAX.DF_PL_DESC, '')

GO
