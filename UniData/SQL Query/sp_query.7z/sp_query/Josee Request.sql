SELECT InvoiceNumber
,	InvoiceDate
,	BillOfLadingNumber
,	FreightOnBoardCode
,	CompanyCodeCustomerCode
,	ShipToCountryCode
,	ShipToCityStateProvinceZipPostalCode
,	ShipToName
,	SUM(GrossAmount) GrossAmount
,	SUM(NetAmount) NetAmount	
,	SUM(ExtendedPriceAmount) ExtendedPriceAmount
,	SUM(PrepaidFreightAmount) PrepaidFreightAmount
,	SUM(CustomerChargeFreightAmount) CustomerChargeFreightAmount
FROM Invoice_2007
GROUP BY InvoiceNumber
,	InvoiceDate
,	BillOfLadingNumber
,	FreightOnBoardCode
,	CompanyCodeCustomerCode
,	ShipToCountryCode
,	ShipToCityStateProvinceZipPostalCode
,	ShipToName


SELECT *
FROM vw_Test_Invoice_2007