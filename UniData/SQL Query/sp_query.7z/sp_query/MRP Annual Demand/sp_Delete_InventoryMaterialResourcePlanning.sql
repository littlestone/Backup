CREATE PROCEDURE sp_Delete_InventoryMaterialResourcePlanning
WITH RECOMPILE
AS

DECLARE	@strMonth	varchar(7)
,	@dtmDate	smalldatetime

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryMaterialResourcePlanning')
BEGIN
	DELETE	DataWarehouse..InventoryMaterialResourcePlanning
	FROM	DataWarehouse..InventoryMaterialResourcePlanning InventoryMaterialResourcePlanning
		LEFT JOIN Source..INVMRP INVMRP
			ON InventoryMaterialResourcePlanning.WarehouseCode = RIGHT(INVMRP.ID, LEN(INVMRP.ID) - CHARINDEX('*', INVMRP.ID))
			AND InventoryMaterialResourcePlanning.ComputerizedPartNumber = LEFT(INVMRP.ID, CHARINDEX('*', INVMRP.ID) - 1)
	WHERE	INVMRP.ID IS NULL
END

SELECT	@dtmDate = CONVERT(varchar(10), DATEADD(day, -1, GETDATE()), 120)

SELECT	@strMonth = FiscalTime.FiscalMonth
FROM	DataWarehouse..FiscalTime FiscalTime
WHERE	@dtmDate BETWEEN FiscalTime.StartDate AND FiscalTime.EndDate

EXEC	sp_Delete_InventoryMaterialResourcePlanning_Month @strMonth

GO
