CREATE  PROCEDURE dbo.sp_Update_BuyerPlanner_Active
AS

UPDATE	DataWarehouse..BuyerPlanner
SET	Active = 0
WHERE	NULLIF(BuyerPlannerCode, '') IS NOT NULL

SELECT	BuyerPlanner.BuyerPlannerCode
INTO	#BuyerPlanner
FROM	DataWarehouse..BuyerPlanner BuyerPlanner
WHERE	0 = 1

INSERT	#BuyerPlanner
	(BuyerPlannerCode)
SELECT DISTINCT Buyer.BuyerCode
FROM	DataWarehouse..Buyer Buyer
WHERE	Buyer.Active = 1

INSERT	#BuyerPlanner
	(BuyerPlannerCode)
SELECT DISTINCT Planner.PlannerCode
FROM	DataWarehouse..Planner Planner
WHERE	Planner.Active = 1

UPDATE	DataWarehouse..BuyerPlanner
SET	Active = 1
FROM	DataWarehouse..BuyerPlanner BuyerPlanner
	INNER JOIN #BuyerPlanner
		ON BuyerPlanner.BuyerPlannerCode = #BuyerPlanner.BuyerPlannerCode

DROP	TABLE #BuyerPlanner

GO
