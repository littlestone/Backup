CREATE PROCEDURE dbo.sp_Delete_tbl_MAD_Input_I
AS

TRUNCATE TABLE	DemandSolutions..tbl_MAD_Input_I

GO
