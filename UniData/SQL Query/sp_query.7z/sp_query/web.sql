


TRUNCATE TABLE Retailer


SET IDENTITY_INSERT Retailer OFF

Insert Retailer(RetailerID, LanguageID, ProductLineID, StateCode, RetailerName, RetailerLogo, RetailerWebSite, RetailerNotes, Rowguid)
SELECT	*
FROM	dev_ipexhomerite_com..Retailer


