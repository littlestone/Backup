UPDATE	DataWarehouse_VAX..PurchaseReceipt_1994
SET		FiscalPeriodCode = '19' + FiscalPeriodCode 
FROM		DataWarehouse_VAX..PurchaseReceipt_1994 PurchaseReceipt_1994
WHERE	PurchaseReceipt_1994.FiscalPeriodCode <> ''