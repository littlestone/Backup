CREATE	VIEW vw_PurchaseReceipt_2000
AS
SELECT	SupplierCode
,	SupplierName
,	WarehouseCode
,	WarehouseName
,	PurchaseOrderNumber
,	BillOfLadingNumber
,	ReceivingNumber
,	DateReceived
,	ProductCode
,	ProductName
,	ReceiveQuantity
,	FiscalPeriodCode
,	FreightCarrierCode
,	FreightCarrierName
FROM	DataWarehouse_VAX..PurchaseReceipt_2000





