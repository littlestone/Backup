
ALTER  PROCEDURE dbo.sp_Update_InventoryMaterialResourcePlanning_Month
(		@strMonth	varchar(7))
WITH RECOMPILE
AS

DECLARE	@strSQL		varchar(8000)
,	@strYear	varchar(4)

SELECT	@strYear = LEFT(@strMonth, CHARINDEX('-', @strMonth) - 1)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryMaterialResourcePlanning_' + @strYear)
BEGIN
	SELECT	@strSQL =	'UPDATE	DataWarehouse..InventoryMaterialResourcePlanning_' + @strYear + ' ' +
				'SET	AnnualDemandQuantity = ISNULL(INVMRP.ABC_DEMAND, 0)' + ' ' +
				'FROM	DataWarehouse..InventoryMaterialResourcePlanning_' + @strYear + ' InventoryMaterialResourcePlanning' + ' ' +
				'	INNER JOIN Source..INVMRP INVMRP' + ' ' +
				'		ON InventoryMaterialResourcePlanning.WarehouseCode = RIGHT(INVMRP.ID, LEN(INVMRP.ID) - CHARINDEX(''*'', INVMRP.ID))' + ' ' +
				'		AND InventoryMaterialResourcePlanning.ComputerizedPartNumber = LEFT(INVMRP.ID, CHARINDEX(''*'', INVMRP.ID) - 1)' + ' ' +
				'WHERE	InventoryMaterialResourcePlanning.FiscalPeriodCode = ''' + @strMonth + '''' + ' ' +
				'AND	InventoryMaterialResourcePlanning.AnnualDemandQuantity != ISNULL(INVMRP.ABC_DEMAND, 0)'
	
	EXEC	(@strSQL)
END


GO
