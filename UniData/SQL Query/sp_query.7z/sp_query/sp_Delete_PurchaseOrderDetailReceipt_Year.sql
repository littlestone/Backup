ALTER     PROCEDURE dbo.sp_Delete_PurchaseOrderDetailReceipt_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetailReceipt_' + @strYear)
BEGIN
	SELECT	@strSQL = 'DELETE DataWarehouse..PurchaseOrderDetailReceipt_' + @strYear + ' ' +
			'FROM	DataWarehouse..PurchaseOrderDetailReceipt_' + @strYear + ' PurchaseOrderDetailReceipt' + ' ' +
			'WHERE	EXISTS (SELECT	CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END' + ' ' +
			'		FROM	Source..PODET PODET' + ' ' +
			'			INNER JOIN Source..POHDR POHDR' + ' ' +
			'				ON CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END = POHDR.PO_NBR' + ' ' +
			'		WHERE	POHDR.FISCAL_PERIOD LIKE ''' + @strYear + '%''' + ' ' +
			'		AND	PurchaseOrderDetailReceipt.PurchaseOrderNumber = CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END' + ' ' +
			'		AND	PurchaseOrderDetailReceipt.ReferenceNumber = CASE WHEN LEN(PODET.ID) <= 5 THEN '''' ELSE LEFT(PODET.ID, 5) END)'

	EXEC	(@strSQL)
END
GO
