UPDATE News
SET NewsTitle = LEFT(NewsTitle, CHARINDEX('<', NewsTitle) - 1)

UPDATE News
SET NewsDate = LEFT(NewsDate, CHARINDEX('<', NewsDate) - 1)

UPDATE News
SET NewsShortDesc = LEFT(NewsShortDesc, CHARINDEX('<', NewsShortDesc) - 1)


UPDATE NewsProduct
SET NewsTitle = LEFT(NewsTitle, CHARINDEX('<', NewsTitle) - 1)

UPDATE NewsProduct
SET NewsDate = LEFT(NewsDate, CHARINDEX('<', NewsDate) - 1)

UPDATE NewsProduct
SET NewsShortDesc = LEFT(NewsShortDesc, CHARINDEX('<', NewsShortDesc) - 1)

UPDATE NewsProduct
SET NewsLink = LEFT(NewsLink, CHARINDEX('<', NewsLink) - 1)



UPDATE PressReleases
SET PressTitle = LEFT(PressTitle, CHARINDEX('<', PressTitle) - 1)

UPDATE PressReleases
SET PressDate = LEFT(PressDate, CHARINDEX('<', PressDate) - 1)

UPDATE PressReleases
SET PressShortDesc = LEFT(PressShortDesc, CHARINDEX('<', PressShortDesc) - 1)

UPDATE PressReleases
SET PressFooter = LEFT(PressFooter, CHARINDEX('<', PressFooter) - 1)


UPDATE T_CMGR_MainSection
SET LMainSectionLinkURL = LEFT(LMainSectionLinkURL, CHARINDEX('<', LMainSectionLinkURL) - 1)



--SELECT *
--INTO PressReleases_20080603
--FROM PressReleases

--SELECT *
--INTO News_20080603
--FROM News

--SELECT *
--INTO NewsProduct_20080603
--FROM NewsProduct


--SELECT *
--INTO T_CMGR_SubSection_20080603
--FROM T_CMGR_SubSection