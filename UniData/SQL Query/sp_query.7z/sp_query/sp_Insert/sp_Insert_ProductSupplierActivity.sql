ALTER PROCEDURE dbo.sp_Insert_ProductSupplierActivity AS
INSERT	DataWarehouse..ProductSupplierActivity
	(ComputerizedPartNumber
,	CompanyCode
,	SupplierCode)
SELECT	ISNULL(ITMSUPPACT.CPN, '')
,	ISNULL(ITMSUPPACT.COMPANY, '')
,	ISNULL(ITMSUPPACT.VENDOR, '')
FROM	Source..ITMSUPPACT ITMSUPPACT
	LEFT JOIN DataWarehouse..ProductSupplierActivity ProductSupplierActivity
		ON ISNULL(ITMSUPPACT.CPN, '') = ProductSupplierActivity.ComputerizedPartNumber
		AND ISNULL(ITMSUPPACT.COMPANY, '') = ProductSupplierActivity.CompanyCode
		AND ISNULL(ITMSUPPACT.VENDOR, '') = ProductSupplierActivity.SupplierCode
WHERE	ProductSupplierActivity.ComputerizedPartNumber IS NULL
AND 	ProductSupplierActivity.CompanyCode IS NULL
AND	ProductSupplierActivity.SupplierCode IS NULL


GO
