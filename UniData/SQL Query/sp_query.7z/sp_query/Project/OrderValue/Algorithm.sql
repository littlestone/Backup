SELECT	vw_SalesOrder.OrderNumber
,	CASE	WHEN SUM(vw_SalesOrder.ExtendedPriceAmount) < 1.00 THEN '001'
		WHEN SUM(vw_SalesOrder.ExtendedPriceAmount) > 10000.00 THEN '402'
		ELSE 	CASE    WHEN SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 = 0 THEN
					CASE 	WHEN LEN(CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 1 AS int) AS varchar)) = 1 THEN '00' + CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)
						WHEN LEN(CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 1 AS int) AS varchar)) = 2 THEN '0' + CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)
						ELSE CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 1 AS int) AS varchar)
					END 		
				ELSE	CASE 	WHEN LEN(CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)) = 1 THEN '00' + CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)
						WHEN LEN(CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)) = 2 THEN '0' + CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)
						ELSE CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)
					END 	
		END	
	END AS OrderValueCode	
,	SUM(vw_SalesOrder.ExtendedPriceAmount)
FROM	DataWarehouse..vw_SalesOrder_2008_New vw_SalesOrder
WHERE	vw_SalesOrder.LineItemStatusCode != 'C'
AND	vw_SalesOrder.DeliveryNumber = '1'
GROUP BY vw_SalesOrder.OrderNumber
HAVING SUM(vw_SalesOrder.ExtendedPriceAmount) = 0


SELECT	SalesOrder_2008_New.OrderNumber
,	SUM(SalesOrder_2008_New.ExtendedPriceAmount)
,	SalesOrder_2008_New.OrderValueCode
FROM	DataWarehouse..SalesOrder_2008_New SalesOrder_2008_New
WHERE	SalesOrder_2008_New.LineItemStatusCode != 'C'
AND	SalesOrder_2008_New.DeliveryNumber = '1'
AND 	SalesOrder_2008_New.OrderValueCode = '001'
GROUP BY SalesOrder_2008_New.OrderNumber
,	SalesOrder_2008_New.OrderValueCode
HAVING SUM(SalesOrder_2008_New.ExtendedPriceAmount) / 25 <= 0

SELECT 24.00 / 25