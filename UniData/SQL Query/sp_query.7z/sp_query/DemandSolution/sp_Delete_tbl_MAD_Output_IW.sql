CREATE PROCEDURE dbo.sp_Delete_tbl_MAD_Output_IW
AS

TRUNCATE TABLE	DemandSolutions..tbl_MAD_Output_IW

GO
