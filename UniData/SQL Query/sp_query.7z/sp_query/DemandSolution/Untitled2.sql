INSERT INTO tbl_MAD_Input_IW
SELECT '' id
,	item
,	'' company
,	'' division
,	'' sold
,	'' corporation
,	'' department
,	ship_to
,	SUM(history_1) history_1
,	SUM(history_2) history_2
,	SUM(history_3) history_3
,	SUM(history_4) history_4
,	SUM(history_5) history_5
,	SUM(history_6) history_6
,	SUM(history_7) history_7
,	SUM(history_8) history_8
,	SUM(history_9) history_9
,	SUM(history_10) history_10
,	SUM(history_11) history_11
,	SUM(history_12) history_12
,	SUM(history_13) history_13
,	SUM(history_14) history_14
,	SUM(history_15) history_15
,	SUM(history_16) history_16
,	SUM(history_17) history_17
,	SUM(history_18) history_18
,	SUM(history_19) history_19
,	SUM(history_20) history_20
,	SUM(history_21) history_21
,	SUM(history_22) history_22
,	SUM(history_23) history_23
,	SUM(history_24) history_24
,	SUM(history_25) history_25
,	SUM(history_26) history_26
,	SUM(history_27) history_27
,	SUM(history_28) history_28
,	SUM(history_29) history_29
,	SUM(history_30) history_30
,	SUM(history_31) history_31
,	SUM(history_32) history_32
,	SUM(history_33) history_33
,	SUM(history_34) history_34
,	SUM(history_35) history_35
,	SUM(history_36) history_36
,	SUM(history_37) history_37
,	SUM(history_38) history_38
,	SUM(history_39) history_39
,	SUM(history_40) history_40
,	SUM(history_41) history_41
FROM tbl_MAD_Input_IRW
GROUP BY item, ship_to
ORDER BY item


UPDATE tbl_MAD_Input_IW
SET ship_to = '0' + ship_to
WHERE LEN(ship_to) = 2


UPDATE tbl_MAD_Output_IRW
SET division = ''



SELECT *
INTO tbl_MAD_Input
FROM tbl_MAD_Input_IW
WHERE 0=1



TRUNCATE TABLE tbl_MAD_Oupput

SELECT *
INTO tbl_MAD_Output_IW
FROM tbl_MAD_Output

EXEC gen_MAD_Output