ALTER     PROCEDURE dbo.sp_Update_PurchaseOrderDetail_PurchaseOrderReceipt_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

SELECT PurchaseOrderDetailReceipt.PurchaseOrderNumber
,	PurchaseOrderDetailReceipt.ReferenceNumber
,	PurchaseOrderDetailReceipt.CompanyReceiveQuantity
INTO	#PurchaseOrderDetailReceipt
FROM DataWarehouse..PurchaseOrderDetailReceipt_2008 PurchaseOrderDetailReceipt
WHERE 0 = 1

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
	AND EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetailReceipt_' + @strYear)
BEGIN
	SELECT	@strSQL = 'INSERT #PurchaseOrderDetailReceipt' + ' ' +
			'(	PurchaseOrderNumber' + ' ' +
			',	ReferenceNumber' + ' ' +
			',	CompanyReceiveQuantity)' + ' ' +
			'SELECT	PurchaseOrderDetailReceipt.PurchaseOrderNumber' + ' ' +
			',	PurchaseOrderDetailReceipt.ReferenceNumber' + ' ' +
			',	ISNULL(SUM(PurchaseOrderDetailReceipt.CompanyReceiveQuantity), 0)' + ' ' +
			'FROM	DataWarehouse..PurchaseOrderDetailReceipt_' + @strYear + ' PurchaseOrderDetailReceipt' + ' ' +
			'GROUP BY PurchaseOrderDetailReceipt.PurchaseOrderNumber' + ' ' +
			',	PurchaseOrderDetailReceipt.ReferenceNumber'	
	EXEC	(@strSQL)

	SELECT	@strSQL = 'UPDATE DataWarehouse..PurchaseOrderDetail_' + @strYear + ' ' +
			'SET	CompanyReceiveQuantity = #PurchaseOrderDetailReceipt.CompanyReceiveQuantity' + ' ' +
			'FROM	DataWarehouse..PurchaseOrderDetail_' + @strYear + ' PurchaseOrderDetail' + ' ' +
			'	LEFT JOIN #PurchaseOrderDetailReceipt' + ' ' +
			'		ON PurchaseOrderDetail.PurchaseOrderNumber = #PurchaseOrderDetailReceipt.PurchaseOrderNumber' + ' ' +
			'		AND PurchaseOrderDetail.ReferenceNumber = #PurchaseOrderDetailReceipt.ReferenceNumber' + ' ' +
			'WHERE	PurchaseOrderDetail.CompanyReceiveQuantity != #PurchaseOrderDetailReceipt.CompanyReceiveQuantity' 

	EXEC	(@strSQL)
END

GO
