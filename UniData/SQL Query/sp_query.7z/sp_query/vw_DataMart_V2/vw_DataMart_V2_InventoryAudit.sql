ALTER VIEW vw_DataMart_V2_InventoryAudit
AS
SELECT 	InventoryTrail.FiscalPeriodCode
,	InventoryTrail.WarehouseCode
,	InventoryTrail.InventoryTransactionTypeCode
,	InventoryTrail.InventorySubTransactionTypeCode
,	InventoryTrail.InventoryTransactionTypeCodeInventorySubTransactionTypeCode
,	InventoryTrail.CompanyCode
,	InventoryTrail.CustomerCode
,	InventoryTrail.CompanyCodeCustomerCode
,	InventoryTrail.SupplierCode
,	InventoryTrail.CompanyCodeSupplierCode
,	InventoryTrail.TransferWarehouseCode
,	InventoryTrail.LocationCode
,	InventoryTrail.ComputerizedPartNumber
,	InventoryTrail.SequenceNumber
,	InventoryTrail.ReferenceNumber
,	InventoryTrail.TransactionDateTime
,	InventoryTrail.EntryDate
,	InventoryTrail.UserCode
,	InventoryTrail.RegisterTypeCode
,	InventoryTrail.RegisterNumber
,	InventoryTrail.GeneralLedgerGroupCode
,	InventoryTrail.SalesPostingCode
,	InventoryTrail.UnitOfMeasureCode
,	InventoryTrail.OnHandQuantity
,	InventoryTrail.TransactionQuantity
,	InventoryTrail.InventoryAmount
,	InventoryTrail.ReceiptAmount
,	InventoryTrail.AdjustmentReasonCode
,	InventoryTrail.AdjustmentReasonComment
,	ISNULL(Product.UnitWeight,0) AS UnitWeight
,	ISNULL(ItemCost_Current.MaterialCost, 0) AS CurrentMaterialCost
,	ISNULL(ItemCost_Current.VariableCost, 0) AS CurrentVariableCost
,	ISNULL(ItemCost_Current.FixedCost, 0) AS CurrentFixedCost
,	ISNULL(ItemCost_Current.OutsideProcessingCost, 0) AS CurrentOutsideCost
,	ISNULL(ItemCost_Current.StandardCost, 0) AS CurrentCost
,	CurrentCurrencyRateCAD = ISNULL(CurrencyRateCAD_Current.CurrencyRate, 1)
,	CurrentCurrencyRateUSD = ISNULL(CurrencyRateCAD_Current.CurrencyRate, 1) / ISNULL(CurrencyRateUSD_Current.CurrencyRate, 1)
,	ISNULL(ItemCost_Historic.MaterialCost, 0) AS HistoricMaterialCost
,	ISNULL(ItemCost_Historic.VariableCost, 0) AS HistoricVariableCost
,	ISNULL(ItemCost_Historic.FixedCost, 0) AS HistoricFixedCost
,	ISNULL(ItemCost_Historic.OutsideProcessingCost, 0) AS HistoricOutsideCost
,	ISNULL(ItemCost_Historic.StandardCost, 0) AS HistoricCost
,	HistoricCurrencyRateCAD = ISNULL(CurrencyRateCAD_Historic.CurrencyRate, 1)
,	HistoricCurrencyRateUSD = ISNULL(CurrencyRateCAD_Historic.CurrencyRate, 1) / ISNULL(CurrencyRateUSD_Historic.CurrencyRate, 1)
,	1 AS TransactionCount
FROM 	DataWarehouse..InventoryTrail_2001 InventoryTrail
	INNER JOIN DataWarehouse..FiscalTime FiscalTime
		ON CONVERT(varchar(10), GETDATE(), 120) BETWEEN FiscalTime.StartDate AND FiscalTime.EndDate
	LEFT JOIN DataWarehouse..Product Product
		ON InventoryTrail.ComputerizedPartNumber = Product.ComputerizedPartNumber
	LEFT JOIN DataWarehouse..Warehouse Warehouse
		ON InventoryTrail.WarehouseCode = Warehouse.WarehouseCode
	LEFT JOIN DataWarehouse..ItemCost_2001 ItemCost_Historic
		ON InventoryTrail.ComputerizedPartNumber = ItemCost_Historic.ComputerizedPartNumber
		AND Warehouse.CostTypeCode = ItemCost_Historic.CostTypeCode
		AND InventoryTrail.FiscalPeriodCode = ItemCost_Historic.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CostType CostType_Historic
		ON ItemCost_Historic.CostTypeCode = CostType_Historic.CostTypeCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateCAD_Historic
		ON CostType_Historic.CurrencyCode = CurrencyRateCAD_Historic.FromCurrencyCode		AND 'CAD' = CurrencyRateCAD_Historic.ToCurrencyCode
		AND InventoryTrail.FiscalPeriodCode = CurrencyRateCAD_Historic.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateUSD_Historic
		ON 'CAD' = CurrencyRateUSD_Historic.FromCurrencyCode
		AND 'USD' = CurrencyRateUSD_Historic.ToCurrencyCode
		AND InventoryTrail.FiscalPeriodCode = CurrencyRateUSD_Historic.FiscalPeriodCode
	LEFT JOIN DataWarehouse..ItemCost ItemCost_Current
		ON InventoryTrail.ComputerizedPartNumber = ItemCost_Current.ComputerizedPartNumber
		AND Warehouse.CostTypeCode = ItemCost_Current.CostTypeCode
	LEFT JOIN DataWarehouse..CostType CostType_Current
		ON ItemCost_Current.CostTypeCode = CostType_Current.CostTypeCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateCAD_Current
		ON CostType_Current.CurrencyCode = CurrencyRateCAD_Current.FromCurrencyCode		AND 'CAD' = CurrencyRateCAD_Current.ToCurrencyCode
		AND FiscalTime.FiscalPeriodCode = CurrencyRateCAD_Current.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateUSD_Current
		ON 'CAD' = CurrencyRateUSD_Current.FromCurrencyCode
		AND 'USD' = CurrencyRateUSD_Current.ToCurrencyCode
		AND FiscalTime.FiscalPeriodCode = CurrencyRateUSD_Current.FiscalPeriodCode

