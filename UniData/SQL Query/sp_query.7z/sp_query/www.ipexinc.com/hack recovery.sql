UPDATE Events
SET EventTitle = ipex_old.EventTitle
SELECT *
FROM www_ipexinc_com_20080314..Events ipex_old
WHERE EventID = ipex_old.EventID



UPDATE News
SET NewsTitle = ipex_old.NewsTitle
SELECT *
FROM www_ipexinc_com_20080314..News ipex_old
WHERE NewsID = ipex_old.NewsID



UPDATE PressReleases
SET PressReleaseTitle = ipex_old.PressReleaseTitle
SELECT *
FROM www_ipexinc_com_20080314..PressReleases ipex_old
WHERE PressReleaseID = ipex_old.PressReleaseID



