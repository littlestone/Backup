

ALTER PROCEDURE dbo.sp_Update_InventoryTransactionType_Active
WITH RECOMPILE
AS

UPDATE	DataWarehouse..InventoryTransactionType
SET	Active = 0
WHERE	NULLIF(InventoryTransactionTypeCode, '') IS NOT NULL

SELECT	InventoryTransactionType.InventoryTransactionTypeCode
INTO	#InventoryTransactionType
FROM	DataWarehouse..InventoryTransactionType InventoryTransactionType
WHERE	0 = 1

INSERT	#InventoryTransactionType
	(InventoryTransactionTypeCode)
SELECT DISTINCT	InventorySubTransactionType.InventoryTransactionTypeCode
FROM	DataWarehouse..InventorySubTransactionType InventorySubTransactionType
WHERE	InventorySubTransactionType.Active = 1

UPDATE	DataWarehouse..InventoryTransactionType
SET	Active = 1
FROM	DataWarehouse..InventoryTransactionType InventoryTransactionType
	INNER JOIN #InventorySubTransactionType
		ON InventoryTransactionType.InventoryTransactionTypeCode = #InventoryTransactionType.InventoryTransactionTypeCode

DROP	TABLE #InventoryTransactionType


GO
