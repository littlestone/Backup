


ALTER     PROCEDURE dbo.sp_Update_SalesOrder_OrderValue_Year_20080910
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'SalesOrder_' + @strYear + '_New')
	AND EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'vw_SalesOrder_' + @strYear)
BEGIN
	SELECT	@strSQL = 'SELECT	vw_SalesOrder.OrderNumber' + ' ' +
			',	CASE	WHEN SUM(vw_SalesOrder.ExtendedPriceAmount) < 1.00 THEN ''001''' + ' ' +	
			'		WHEN SUM(vw_SalesOrder.ExtendedPriceAmount) > 10000.00 THEN ''402''' + ' ' +	
			'		ELSE 	CASE    WHEN SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 <= 0 THEN' + ' ' +	
			'					CASE 	WHEN LEN(CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 1 AS int) AS varchar)) = 1 THEN ''00'' + CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)' + ' ' +	
			'						WHEN LEN(CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 1 AS int) AS varchar)) = 2 THEN ''0'' + CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)' + ' ' +	
			'						ELSE CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 1 AS int) AS varchar)' + ' ' +	
			'					END' + ' ' +	 		
			'				ELSE	CASE 	WHEN LEN(CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)) = 1 THEN ''00'' + CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)' + ' ' +	
			'						WHEN LEN(CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)) = 2 THEN ''0'' + CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)' + ' ' +	
			'						ELSE CAST(CAST(SUM(vw_SalesOrder.ExtendedPriceAmount) / 25 + 2 AS int) AS varchar)' + ' ' +	
			'					END' + ' ' +	 	
			'	END' + ' ' +		
			'END AS OrderValueCode' + ' ' +	
			'INTO	#OrderValue' + ' ' +
			'FROM	DataWarehouse..vw_SalesOrder_' + @strYear + '_New' + ' ' + 'vw_SalesOrder' + ' ' +
			'WHERE	vw_SalesOrder.LineItemStatusCode != ''C''' + ' ' +
			'AND	vw_SalesOrder.DeliveryNumber = ''1''' + ' ' +
			'GROUP BY vw_SalesOrder.OrderNumber'
	
	SELECT	@strSQL = @strSQL + ' ' +
			'UPDATE	DataWarehouse..SalesOrder_' + @strYear + '_New' + ' ' +
			'SET	OrderValueCode = ISNULL(OrderValue.OrderValueCode, '''')' + ' ' +
			'FROM	DataWarehouse..SalesOrder_' + @strYear + '_New' + ' SalesOrder' + ' ' +
			'	LEFT JOIN #OrderValue OrderValue' + ' ' +
			'		ON SalesOrder.OrderNumber = OrderValue.OrderNumber' + ' ' +	
			'WHERE	SalesOrder.OrderValueCode != ISNULL(OrderValue.OrderValueCode, '''')'

	SELECT	@strSQL = @strSQL + ' ' +
			'DROP TABLE #OrderValue'

	EXEC	(@strSQL)
END





GO