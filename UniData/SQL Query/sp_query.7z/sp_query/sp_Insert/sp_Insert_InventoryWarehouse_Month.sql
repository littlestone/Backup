
ALTER      PROCEDURE dbo.sp_Insert_InventoryWarehouse_Month
(		@strMonth	varchar(7))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)
,	@strYear varchar(4)

SELECT	@strYear = LEFT(@strMonth, CHARINDEX('-', @strMonth) - 1)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryWarehouse_' + @strYear)
BEGIN
	SELECT	@strSQL =	'INSERT	DataWarehouse..InventoryWarehouse_' + @strYear + ' ' +
				'	(WarehouseCode' + ' ' +
				',	ComputerizedPartNumber' + ' ' +
				',	FiscalPeriodCode' + ' ' +
				',	PlannerCode' + ' ' +
				',	BuyerCode' + ' ' +
				',	DefaultABCClassCode' + ' ' +
				',	VendorNumber' + ' ' +
				',	OnHandQuantity' + ' ' +
				',	InMaterialReviewBoardQuantity' + ' ' +
				',	InReceiptInInspectionQuantity' + ' ' +
				',	InTransitQuantity' + ' ' +
				',	BookedQuantity' + ' ' +
				',	ManufacturingAllocationQuantity' + ' ' +
				',	LastActivityDate' + ' ' +
				',	DemandDuringLeadTimeQuantity' + ' ' +
				',	DefaultSafetyStockQuantity' + ' ' +
				',	ReorderQuantity' + ' ' +
				',	SupplyWarehouseCode' + ' ' +
				',	InventoryStockingCode' + ' ' +
				',	InventorySourceCode' + ' ' +
				',	InventoryStockingTypeCode' + ' ' +
				',	OverrideABCClassCode' + ' ' +
				',	OverrideSafetyStockQuantity' + ' ' +
				',	RequirementTypeCode' + ' ' +
				',	ABCClassCode' + ' ' +
				',	BuyerPlannerCode' + ' ' +
				',	PurchaseConsignmentCode' + ' ' +
				',	AllocationQuantity' + ' ' +
				',	DefaultLeadTimeDay' + ' ' +
				',	OverrideLeadTimeDay)' + ' ' +
				'SELECT	INVWHS.WAREHOUSE' + ' ' +
				',	INVWHS.CPN' + ' ' +
				',	''' + @strMonth + '''' + ' ' +
				',	''''' + ' ' +
				',	''''' + ' ' +
				',	ISNULL(INVWHS.ABC_CALC, '''')' + ' ' +
				',	''''' + ' ' +
				',	ISNULL(INVWHS.QTY_ON_HAND, 0)' + ' ' +
				',	ISNULL(INVWHS_MRB.QTY_ON_HAND, 0)' + ' ' +
				',	ISNULL(INVWHS_RII.QTY_ON_HAND, 0)' + ' ' +
				',	ISNULL(INVWHS.IN_TRANSIT_QTY, 0)' + ' ' +
				',	ISNULL(INVWHS.BOOKED_QTY, 0)' + ' ' +
				',	ISNULL(INVWHS.MFG_ALLOC, 0)' + ' ' +
				',	ISNULL(INVWHS.LAST_ACT_DT, ''1900-01-01'')' + ' ' +
				',	0' + ' ' +
				',	0' + ' ' +
				',	ISNULL(INVWHS.REORDER_QTY, 0)' + ' ' +
				',	''''' + ' ' +
				',	''''' + ' ' +
				',	''''' + ' ' +
				',	''''' + ' ' +
				',	ISNULL(INVWHS.ABC_OVERIDE, '''')' + ' ' +
				',	-1' + ' ' +
				',	''''' + ' ' +
				',	ISNULL(INVWHS.ABC_OVERIDE, ISNULL(INVWHS.ABC_CALC, ''''))' + ' ' +
				',	''''' + ' ' +
				',	ISNULL(INVWHS.PUR_CON_FLAG, '''')' + ' ' +
				',	ISNULL(INVWHS.ALLOCATED_QTY, 0)' + ' ' +
				',	0' + ' ' +
				',	0' + ' ' +
				'FROM	Source..INVWHS INVWHS' + ' ' +
				'	LEFT JOIN Source..INVWHS INVWHS_MRB' + ' ' +
				'		ON INVWHS_MRB.WAREHOUSE LIKE ''MRB%''' + ' ' +
				'		AND INVWHS.WAREHOUSE = RIGHT(INVWHS_MRB.WAREHOUSE, LEN(INVWHS_MRB.WAREHOUSE) - CHARINDEX(''.'', INVWHS_MRB.WAREHOUSE))' + ' ' +
				'		AND INVWHS.CPN = INVWHS_MRB.CPN' + ' ' +
				'	LEFT JOIN Source..INVWHS INVWHS_RII' + ' ' +
				'		ON INVWHS_RII.WAREHOUSE LIKE ''RII%''' + ' ' +
				'		AND INVWHS.WAREHOUSE = RIGHT(INVWHS_RII.WAREHOUSE, LEN(INVWHS_RII.WAREHOUSE) - CHARINDEX(''.'', INVWHS_RII.WAREHOUSE))' + ' ' +
				'		AND INVWHS.CPN = INVWHS_RII.CPN' + ' ' +
				'	LEFT JOIN DataWarehouse..InventoryWarehouse_' + @strYear + ' InventoryWarehouse' + ' ' +
				'		ON INVWHS.WAREHOUSE = InventoryWarehouse.WarehouseCode' + ' ' +
				'		AND INVWHS.CPN = InventoryWarehouse.ComputerizedPartNumber' + ' ' +
				'		AND ''' + @strMonth + ''' = InventoryWarehouse.FiscalPeriodCode' + ' ' +
				'WHERE	LEN(INVWHS.WAREHOUSE) = 3' + ' ' +
				'AND	InventoryWarehouse.WarehouseCode IS NULL' + ' ' +
				'AND	InventoryWarehouse.ComputerizedPartNumber IS NULL' + ' ' +
				'AND	InventoryWarehouse.FiscalPeriodCode IS NULL'
	
	EXEC	(@strSQL)
END
GO
