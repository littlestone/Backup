SELECT	LEFT(FISCAL_PERIOD, 4)
,	SUM(CONVERT(numeric(19, 5), PODET_DELIVERY.SCHED_QTY))
,	SUM(CONVERT(numeric(19, 5), PODET_DELIVERY.BAL_QTY))
,	SUM(CONVERT(numeric(19, 5), PODET_DELIVERY.UNIT_COST))
FROM	Source..PODET_DELIVERY PODET_DELIVERY
	LEFT JOIN Source..POHDR POHDR
		ON CASE WHEN LEN(PODET_DELIVERY.ID) <= 5 THEN PODET_DELIVERY.ID ELSE RIGHT(PODET_DELIVERY.ID, LEN(PODET_DELIVERY.ID) - 5) END = POHDR.PO_NBR
GROUP	BY LEFT(FISCAL_PERIOD, 4)
ORDER	BY LEFT(FISCAL_PERIOD, 4)

SELECT	LEFT(PurchaseOrderHeader.FiscalPeriodCode, 4)
,	SUM(PurchaseOrderDetailDelivery.CompanyScheduleQuantity)
,	SUM(PurchaseOrderDetailDelivery.CompanyBalanceQuantity)
,	SUM(PurchaseOrderDetailDelivery.CompanyUnitCost)
FROM	DataWarehouse..PurchaseOrderDetailDelivery_2001 PurchaseOrderDetailDelivery
	LEFT JOIN DataWarehouse..PurchaseOrderHeader_2001 PurchaseOrderHeader
		ON PurchaseOrderDetailDelivery.PurchaseOrderNumber = PurchaseOrderHeader.PurchaseOrderNumber
GROUP	BY LEFT(PurchaseOrderHeader.FiscalPeriodCode, 4)
ORDER	BY LEFT(PurchaseOrderHeader.FiscalPeriodCode, 4)

SELECT	LEFT(PurchaseOrderHeader.FiscalPeriodCode, 4)
,	SUM(PurchaseOrderDetailDelivery.CompanyScheduleQuantity)
,	SUM(PurchaseOrderDetailDelivery.CompanyBalanceQuantity)
,	SUM(PurchaseOrderDetailDelivery.CompanyUnitCost)
FROM	DataWarehouse..PurchaseOrderDetailDelivery_2002 PurchaseOrderDetailDelivery
	LEFT JOIN DataWarehouse..PurchaseOrderHeader_2002 PurchaseOrderHeader
		ON PurchaseOrderDetailDelivery.PurchaseOrderNumber = PurchaseOrderHeader.PurchaseOrderNumber
GROUP	BY LEFT(PurchaseOrderHeader.FiscalPeriodCode, 4)
ORDER	BY LEFT(PurchaseOrderHeader.FiscalPeriodCode, 4)
