

CREATE   VIEW vw_ProductSupplierActivity
AS
SELECT	DISTINCT Product.ProductCode
,	ISNULL(Product.ProductName, '') ProductName
,	ProductSupplierActivity.CompanyCode 
,	ProductSupplierActivity.SupplierCode
,	ISNULL(Supplier.SupplierFirstName, '') SupplierName
,	ISNULL(ProductSupplierActivityPart.SupplierProductCode, '') SupplierProductCode
FROM	DataWarehouse..ProductSupplierActivity ProductSupplierActivity
	LEFT JOIN DataWarehouse..Supplier Supplier
		ON Supplier.SupplierCode = ProductSupplierActivity.SupplierCode
	LEFT JOIN DataWarehouse..Product Product
		ON Product.ComputerizedPartNumber = ProductSupplierActivity.ComputerizedPartNumber
	LEFT JOIN DataWarehouse..ProductSupplierActivityPart ProductSupplierActivityPart
		ON ProductSupplierActivity.ComputerizedPartNumber = ProductSupplierActivityPart.ComputerizedPartNumber
		AND ProductSupplierActivity.CompanyCode = ProductSupplierActivityPart.CompanyCode
		AND ProductSupplierActivity.SupplierCode = ProductSupplierActivityPart.SupplierCode



