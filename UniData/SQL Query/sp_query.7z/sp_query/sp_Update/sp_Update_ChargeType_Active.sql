
ALTER   PROCEDURE dbo.sp_Update_ChargeType_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..ChargeType
SET	Active = 0
WHERE	NULLIF(ChargeTypeCode, '') IS NOT NULL		-- ChargeTypeCode != ''

SELECT	ChargeType.ChargeTypeCode			-- Create temporary table
INTO	#ChargeType
FROM	DataWarehouse..ChargeType ChargeType
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#ChargeType' + ' ' +
					'	(ChargeTypeCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	PurchaseOrderDetail.ChargeTypeCode' + ' ' +
					'FROM	DataWarehouse..PurchaseOrderDetail_' + @strYear + ' PurchaseOrderDetail' + ' ' +
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' PurchaseOrderHeaderLineItem' + ' ' +
					'		ON PurchaseOrderDetail.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'			AND PurchaseOrderDetail.ReferenceNumber = PurchaseOrderHeaderLineItem.ReferenceNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X'''
		EXEC	(@strSQL)
	END
	
	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..ChargeType
SET	Active = 1
FROM	DataWarehouse..ChargeType ChargeType
	INNER JOIN #ChargeType
		ON ChargeType.ChargeTypeCode = #ChargeType.ChargeTypeCode

DROP	TABLE #ChargeType
GO
