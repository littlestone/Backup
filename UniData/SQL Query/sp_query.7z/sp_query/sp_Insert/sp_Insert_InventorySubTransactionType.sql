ALTER PROCEDURE dbo.sp_Insert_InventorySubTransactionType AS
INSERT	DataWarehouse..InventorySubTransactionType
	(InventoryTransactionTypeCode
,	InventorySubTransactionTypeCode
,	InventoryTransactionTypeCodeInventorySubTransactionTypeCode
,	InventorySubTransactionTypeName
,	Active)
SELECT	SYSTBL_ITC.DF_PL
,	''
,	SYSTBL_ITC.DF_PL + '*'
,	''
,	0
FROM	Source..SYSTBL_ITC SYSTBL_ITC
	LEFT JOIN DataWarehouse..InventorySubTransactionType InventorySubTransactionType
		ON SYSTBL_ITC.DF_PL = InventorySubTransactionType.InventoryTransactionTypeCode
WHERE	InventorySubTransactionType.InventoryTransactionTypeCode IS NULL
GO
