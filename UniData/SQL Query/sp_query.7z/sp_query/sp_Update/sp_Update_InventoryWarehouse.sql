
ALTER  PROCEDURE sp_Update_InventoryWarehouse
WITH RECOMPILE
AS

DECLARE	@strMonth	varchar(7)
,	@dtmDate	smalldatetime

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryWarehouse')
BEGIN
	UPDATE	DataWarehouse..InventoryWarehouse
	SET	DefaultABCClassCode = ISNULL(INVWHS.ABC_CALC, '')
	,	OnHandQuantity = ISNULL(INVWHS.QTY_ON_HAND, 0)
	,	InMaterialReviewBoardQuantity = ISNULL(INVWHS_MRB.QTY_ON_HAND, 0)
	,	InReceiptInInspectionQuantity = ISNULL(INVWHS_RII.QTY_ON_HAND, 0)
	,	InTransitQuantity = ISNULL(INVWHS.IN_TRANSIT_QTY, 0)
	,	BookedQuantity = ISNULL(INVWHS.BOOKED_QTY, 0)
	,	ManufacturingAllocationQuantity = ISNULL(INVWHS.MFG_ALLOC, 0)
	,	LastActivityDate = ISNULL(INVWHS.LAST_ACT_DT, '1900-01-01')
	,	ReorderQuantity = ISNULL(INVWHS.REORDER_QTY, 0)
	,	OverrideABCClassCode = ISNULL(INVWHS.ABC_OVERIDE, '')
	,	ABCClassCode = ISNULL(INVWHS.ABC_OVERIDE, ISNULL(INVWHS.ABC_CALC, ''))
	,	PurchaseConsignmentCode = ISNULL(INVWHS.PUR_CON_FLAG, '')
	,	AllocationQuantity = ISNULL(INVWHS.ALLOCATED_QTY, 0)
	FROM	DataWarehouse..InventoryWarehouse InventoryWarehouse
		INNER JOIN Source..INVWHS INVWHS
			ON InventoryWarehouse.WarehouseCode = INVWHS.WAREHOUSE
			AND InventoryWarehouse.ComputerizedPartNumber = INVWHS.CPN
		LEFT JOIN Source..INVWHS INVWHS_MRB
			ON INVWHS_MRB.WAREHOUSE LIKE 'MRB%'
			AND INVWHS.WAREHOUSE = RIGHT(INVWHS_MRB.WAREHOUSE, LEN(INVWHS_MRB.WAREHOUSE) - CHARINDEX('.', INVWHS_MRB.WAREHOUSE))
			AND INVWHS.CPN = INVWHS_MRB.CPN
		LEFT JOIN Source..INVWHS INVWHS_RII
			ON INVWHS_RII.WAREHOUSE LIKE 'RII%'
			AND INVWHS.WAREHOUSE = RIGHT(INVWHS_RII.WAREHOUSE, LEN(INVWHS_RII.WAREHOUSE) - CHARINDEX('.', INVWHS_RII.WAREHOUSE))
			AND INVWHS.CPN = INVWHS_RII.CPN
	WHERE	InventoryWarehouse.DefaultABCClassCode != ISNULL(INVWHS.ABC_CALC, '')
	OR	InventoryWarehouse.OnHandQuantity != ISNULL(INVWHS.QTY_ON_HAND, 0)
	OR	InventoryWarehouse.InMaterialReviewBoardQuantity != ISNULL(INVWHS_MRB.QTY_ON_HAND, 0)
	OR	InventoryWarehouse.InReceiptInInspectionQuantity != ISNULL(INVWHS_RII.QTY_ON_HAND, 0)
	OR	InventoryWarehouse.InTransitQuantity != ISNULL(INVWHS.IN_TRANSIT_QTY, 0)
	OR	InventoryWarehouse.BookedQuantity != ISNULL(INVWHS.BOOKED_QTY, 0)
	OR	InventoryWarehouse.ManufacturingAllocationQuantity != ISNULL(INVWHS.MFG_ALLOC, 0)
	OR	InventoryWarehouse.LastActivityDate != ISNULL(INVWHS.LAST_ACT_DT, '1900-01-01')
	OR	InventoryWarehouse.ReorderQuantity != ISNULL(INVWHS.REORDER_QTY, 0)
	OR	InventoryWarehouse.OverrideABCClassCode != ISNULL(INVWHS.ABC_OVERIDE, '')
	OR	InventoryWarehouse.ABCClassCode != ISNULL(INVWHS.ABC_OVERIDE, ISNULL(INVWHS.ABC_CALC, ''))
	OR	InventoryWarehouse.PurchaseConsignmentCode != ISNULL(INVWHS.PUR_CON_FLAG, '')
	OR	InventoryWarehouse.AllocationQuantity != ISNULL(INVWHS.ALLOCATED_QTY, 0)
END

SELECT	@dtmDate = CONVERT(varchar(10), DATEADD(day, -1, GETDATE()), 120)

SELECT	@strMonth = FiscalTime.FiscalMonth
FROM	DataWarehouse..FiscalTime FiscalTime
WHERE	@dtmDate BETWEEN FiscalTime.StartDate AND FiscalTime.EndDate

EXEC	sp_Update_InventoryWarehouse_Month @strMonth
GO
