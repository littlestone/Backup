CREATE PROCEDURE dbo.sp_Update_SupplierDetails AS
UPDATE	DataWarehouse..SupplierDetails
SET	SupplierPartCode = ISNULL(ITMSUPPACT.PART_NBR, '')
,	SupplierPartDescription = ISNULL(ITMSUPPACT.PART_DESC, '')
,	Company = ISNULL(ITMSUPPACT.COMPANY, '')
,	SupplierCode = ISNULL(ITMSUPPACT.VENDOR, '')
,	SupplierName = ISNULL(ITMSUPPACT.VEN_NAME, '')
FROM	Source..ITMSUPPACT ITMSUPPACT
	INNER JOIN DataWarehouse..SupplierDetails SupplierDetails
		ON ITMSUPPACT.ID = SupplierDetails.SupplierPartCodeCompanyCodeSupplierCode
WHERE	SupplierDetails.SupplierPartCode != ISNULL(ITMSUPPACT.PART_NBR, '')
OR	SupplierDetails.SupplierPartDescription != ISNULL(ITMSUPPACT.PART_DESC, '')
OR	SupplierDetails.Company != ISNULL(ITMSUPPACT.COMPANY, '')
OR	SupplierDetails.SupplierCode != ISNULL(ITMSUPPACT.VENDOR, '')
OR	SupplierDetails.SupplierName != ISNULL(ITMSUPPACT.VEN_NAME, '')

GO
