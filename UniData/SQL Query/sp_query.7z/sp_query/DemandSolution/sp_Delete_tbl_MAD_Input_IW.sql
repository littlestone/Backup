CREATE PROCEDURE dbo.sp_Delete_tbl_MAD_Input_IW
AS

TRUNCATE TABLE	DemandSolutions..tbl_MAD_Input_IW

GO
