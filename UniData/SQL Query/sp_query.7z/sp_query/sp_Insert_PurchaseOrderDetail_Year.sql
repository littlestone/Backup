ALTER      PROCEDURE dbo.sp_Insert_PurchaseOrderDetail_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
BEGIN
	SELECT	@strSQL =	'INSERT	DataWarehouse..PurchaseOrderDetail_' + @strYear + ' ' +
				'	(PurchaseOrderNumber' + ' ' +
				',	ReferenceNumber' + ' ' +
				',	CompanyUnitOfMeasureCode' + ' ' +
				',	PartDescription' + ' ' +
				',	SupplierPartNumber' + ' ' +
				',	ProductCode' + ' ' +
				',	GeneralLedgerAccountCode' + ' ' +
				',	WorkOrderNumber' + ' ' +
				',	ContractQuantity' + ' ' +
				',	ContractUnitPrice' + ' ' +
				',	SupplierUnitOfMeasureCode' + ' ' +
				',	ConversionFactor' + ' ' +
				',	InspectionRequestFlag' + ' ' +
				',	PartRevisionLevel' + ' ' +
				',	RequisitionNumber' + ' ' +
				',	RequestorName' + ' ' +
				',	TaxFlag' + ' ' +
				',	ChargeTypeCode' + ' ' +
				',	ComputerizedPartNumber' + ' ' +
				',	CompanyUnitCost' + ' ' +
				',	CompanyScheduleQuantity' + ' ' +
				',	CompanyBalanceQuantity' + ' ' +
				',	CompanyReceiveQuantity)' + ' ' +
				'SELECT	CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END' + ' ' +
				',	CASE WHEN LEN(PODET.ID) <= 5 THEN '''' ELSE LEFT(PODET.ID, 5) END' + ' ' +
				',	ISNULL(PODET.UM, '''')' + ' ' +
				',	REPLACE(REPLACE(ISNULL(PODET.DESCRIPTION, ''''), CHAR(129), ''''), CHAR(253), '' '')' + ' ' +
				',	ISNULL(PODET.SUPPLIER_PART_NBR, '''')' + ' ' +
				',	CASE PODET.CHARGE_CD WHEN ''P'' THEN ISNULL(PODET.PART_GL_WO, '''') ELSE '''' END' + ' ' +
				',	CASE PODET.CHARGE_CD WHEN ''G'' THEN ISNULL(PODET.PART_GL_WO, '''') ELSE '''' END' + ' ' +
				',	CASE PODET.CHARGE_CD WHEN ''W'' THEN ISNULL(PODET.PART_GL_WO, '''') ELSE '''' END' + ' ' +
				',	ISNULL(PODET.CONTR_QTY, 0)' + ' ' +
				',	ISNULL(PODET.CONTR_PRICE, 0)' + ' ' +
				',	ISNULL(PODET.PCH_UM, '''')' + ' ' +
				',	ISNULL(PODET.CONV_FACTOR, 0)' + ' ' +
				',	ISNULL(PODET.INSP_REQD, '''')' + ' ' +
				',	ISNULL(PODET.REV_LVL, '''')' + ' ' +
				',	ISNULL(PODET.REQ_NBR, '''')' + ' ' +
				',	ISNULL(PODET.REQUESTOR, '''')' + ' ' +
				',	ISNULL(PODET.TAX, '''')' + ' ' +
				',	ISNULL(PODET.CHARGE_CD, '''')' + ' ' +
				',	CASE PODET.CHARGE_CD WHEN ''P'' THEN LEFT(PODET.ID, 5) ELSE '''' END' + ' ' +
				',	0' + ' ' +
				',	0' + ' ' +
				',	0' + ' ' +
				',	0' + ' ' +
				'FROM	Source..PODET PODET' + ' ' +
				'	LEFT JOIN Source..POHDR POHDR' + ' ' +
				'		ON CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END = POHDR.PO_NBR' + ' ' +
				'	LEFT JOIN DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' +
				'		ON POHDR.PO_NBR = PurchaseOrderHeader.PurchaseOrderNumber' + ' ' +
				'		AND ISNULL(POHDR.PO_DT, ''1900-01-01'') = PurchaseOrderHeader.PurchaseOrderDate' + ' ' +
				'	LEFT JOIN DataWarehouse..PurchaseOrderDetail_' + @strYear + ' PurchaseOrderDetail' + ' ' +
				'		ON CASE WHEN LEN(PODET.ID) <= 5 THEN PODET.ID ELSE RIGHT(PODET.ID, LEN(PODET.ID) - 5) END = PurchaseOrderDetail.PurchaseOrderNumber' + ' ' +
				'		AND CASE WHEN LEN(PODET.ID) <= 5 THEN '''' ELSE LEFT(PODET.ID, 5) END = PurchaseOrderDetail.ReferenceNumber' + ' ' +
				'WHERE	POHDR.FISCAL_PERIOD LIKE ''' + @strYear + '%''' + ' ' +
				'AND	PurchaseOrderDetail.PurchaseOrderNumber IS NULL' + ' ' +
				'AND	PurchaseOrderDetail.ReferenceNumber IS NULL'

	EXEC	(@strSQL)
END
GO
