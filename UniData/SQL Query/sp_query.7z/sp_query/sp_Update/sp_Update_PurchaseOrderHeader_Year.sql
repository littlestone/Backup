CREATE     PROCEDURE dbo.sp_Update_PurchaseOrderHeader_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderHeader_' + @strYear)
BEGIN
	SELECT	@strSQL = 'UPDATE DataWarehouse..PurchaseOrderHeader_' + @strYear + ' ' +
			'SET	SupplierCode = ISNULL(POHDR.VENDOR_NBR, '''')' + ' ' +
			',	PurchaseOrderDate = ISNULL(POHDR.PO_DT, ''1900-01-01'')' + ' ' +
			',	BuyerCode = ISNULL(POHDR.BUYER, '''')' + ' ' +
			',	PurchaseOrderTypeCode = ISNULL(POHDR.TYPE, '''')' + ' ' +
			',	ChangeDate = ISNULL(POHDR.CHANGE_DT, ''1900-01-01'')' + ' ' +
			',	ShipToCode = ISNULL(POHDR.DROP_SHIP_ID, '''')' + ' ' +
			',	ShipToName = ISNULL(POHDR.DROP_NM, '''')' + ' ' +
			',	ShipToAddressLine1 = ISNULL(POHDR.DROP_ADD1, '''')' + ' ' +
			',	ShipToAddressLine2 = ISNULL(POHDR.DROP_ADD2, '''')' + ' ' +
			',	ShipToAddressLine3 = ISNULL(POHDR.DROP_ADD3, '''')' + ' ' +
			',	ShipToAddressLine4 = ISNULL(POHDR.DROP_ADD4, '''')' + ' ' +
			',	ShipToAddressLine5 = ISNULL(POHDR.DROP_ADD5, '''')' + ' ' +
			',	ShipToAddressLine6 = ISNULL(POHDR.DROP_ADD6, '''')' + ' ' +
			',	FreightCarrierCode = ISNULL(POHDR.SHIP_TRM_CD, '''')' + ' ' +
			',	FreightOnBoardCode = ISNULL(POHDR.FOB_CD, '''')' + ' ' +
			',	ContactName = ISNULL(POHDR.SLS_NM, '''')' + ' ' +
			',	ConfirmCode = ISNULL(POHDR.CONF_CD, '''')' + ' ' +
			',	PurchasePayTermCode = ISNULL(POHDR.PTM_CD, '''')' + ' ' +
			',	CompanyCode = ISNULL(POHDR.COMPANY, '''')' + ' ' +
			',	ConfirmDate = ISNULL(POHDR.CONFIRM_DATE, ''1900-01-01'')' + ' ' +
			',	CurrencyCode = ISNULL(POHDR.CURR_CD, '''')' + ' ' +
			',	ConversionRate = ISNULL(POHDR.CONV_RATE, 0)' + ' ' +
			',	WarehouseCode = ISNULL(POHDR.WHS, '''')' + ' ' +
			',	PurchaseOrderClassCode = ISNULL(POHDR.PO_CLASS, '''')' + ' ' +
			',	FreightTermCode = ISNULL(POHDR.FREIGHT_TERMS, '''')' + ' ' +
			',	CompanyReferenceNumber = ISNULL(POHDR.IPEX_REFERENCE_NUMBER, '''')' + ' ' +
			',	QuoteNumber = ISNULL(POHDR.QUOTE, '''')' + ' ' +
			',	DivisionCode = ISNULL(POHDR.DF_DIVISION, '''')' + ' ' +
			',	FiscalPeriodCode = ISNULL(POHDR.FISCAL_PERIOD, '''')' + ' ' +
			'FROM	DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' +
			'	INNER JOIN Source..POHDR POHDR' + ' ' +
			'		ON PurchaseOrderHeader.PurchaseOrderNumber = POHDR.PO_NBR' + ' ' +
			'		AND PurchaseOrderHeader.PurchaseOrderDate =  ISNULL(POHDR.PO_DT, ''1900-01-01'')' + ' ' +
			'WHERE	PurchaseOrderHeader.SupplierCode != ISNULL(POHDR.VENDOR_NBR, '''')' + ' ' +
			'OR	PurchaseOrderHeader.PurchaseOrderDate != ISNULL(POHDR.PO_DT, ''1900-01-01'')' + ' ' +
			'OR	PurchaseOrderHeader.BuyerCode != ISNULL(POHDR.BUYER, '''')' + ' ' +
			'OR	PurchaseOrderHeader.PurchaseOrderTypeCode != ISNULL(POHDR.TYPE, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ChangeDate != ISNULL(POHDR.CHANGE_DT, ''1900-01-01'')' + ' ' +
			'OR	PurchaseOrderHeader.ShipToCode != ISNULL(POHDR.DROP_SHIP_ID, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ShipToName != ISNULL(POHDR.DROP_NM, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ShipToAddressLine1 != ISNULL(POHDR.DROP_ADD1, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ShipToAddressLine2 != ISNULL(POHDR.DROP_ADD2, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ShipToAddressLine3 != ISNULL(POHDR.DROP_ADD3, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ShipToAddressLine4 != ISNULL(POHDR.DROP_ADD4, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ShipToAddressLine5 != ISNULL(POHDR.DROP_ADD5, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ShipToAddressLine6 != ISNULL(POHDR.DROP_ADD6, '''')' + ' ' +
			'OR	PurchaseOrderHeader.FreightCarrierCode != ISNULL(POHDR.SHIP_TRM_CD, '''')' + ' ' +
			'OR	PurchaseOrderHeader.FreightOnBoardCode != ISNULL(POHDR.FOB_CD, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ContactName != ISNULL(POHDR.SLS_NM, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ConfirmCode != ISNULL(POHDR.CONF_CD, '''')' + ' ' +
			'OR	PurchaseOrderHeader.PurchasePayTermCode != ISNULL(POHDR.PTM_CD, '''')' + ' ' +
			'OR	PurchaseOrderHeader.CompanyCode != ISNULL(POHDR.COMPANY, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ConfirmDate != ISNULL(POHDR.CONFIRM_DATE, ''1900-01-01'')' + ' ' +
			'OR	PurchaseOrderHeader.CurrencyCode != ISNULL(POHDR.CURR_CD, '''')' + ' ' +
			'OR	PurchaseOrderHeader.ConversionRate != ISNULL(POHDR.CONV_RATE, 0)' + ' ' +
			'OR	PurchaseOrderHeader.WarehouseCode != ISNULL(POHDR.WHS, '''')' + ' ' +
			'OR	PurchaseOrderHeader.PurchaseOrderClassCode != ISNULL(POHDR.PO_CLASS, '''')' + ' ' +
			'OR	PurchaseOrderHeader.FreightTermCode != ISNULL(POHDR.FREIGHT_TERMS, '''')' + ' ' +
			'OR	PurchaseOrderHeader.CompanyReferenceNumber != ISNULL(POHDR.IPEX_REFERENCE_NUMBER, '''')' + ' ' +
			'OR	PurchaseOrderHeader.QuoteNumber != ISNULL(POHDR.QUOTE, '''')' + ' ' +
			'OR	PurchaseOrderHeader.DivisionCode != ISNULL(POHDR.DF_DIVISION, '''')' + ' ' +
			'OR	PurchaseOrderHeader.FiscalPeriodCode != ISNULL(POHDR.FISCAL_PERIOD, '''')'

	EXEC	(@strSQL)
END
GO
