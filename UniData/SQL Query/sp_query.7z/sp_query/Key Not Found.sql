SELECT *
FROM PurchaseOrderHeader_2006
WHERE CompanyCodeSupplierCode = '01*619335'


SELECT *
FROM Supplier
WHERE CompanyCodeSupplierCode = '01*619335'






SELECT *
FROM PurchaseOrderHeader_2006
WHERE CompanyCodeSupplierCode = '01*568925'


SELECT *
FROM Supplier
WHERE CompanyCodeSupplierCode = '01*568925'


