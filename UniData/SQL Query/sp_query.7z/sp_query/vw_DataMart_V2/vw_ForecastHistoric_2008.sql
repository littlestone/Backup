
ALTER  VIEW dbo.vw_ForecastHistoric_2008
AS
SELECT	ForecastHistoric.FiscalPeriodCode
,	ForecastHistoric.ProductGroupCode
,	ISNULL(ForecastRegionGroup.RegionGroupCode, '') AS RegionGroupCode
,	ISNULL(ForecastHistoric.ForecastShippingWeight, 0) AS ForecastShippingWeight
,	ISNULL(ForecastHistoric.AdjustedShippingWeight, 0) AS AdjustedShippingWeight
FROM	DataWarehouse..ForecastHistoric_2008 ForecastHistoric
	LEFT JOIN DataWarehouse..ForecastRegionGroup ForecastRegionGroup
		ON ForecastHistoric.RegionGroupCode = ForecastRegionGroup.RegionGroupCode


