SELECT PurchaseOrderDetailDelivery.PurchaseOrderNumber
,	PurchaseOrderDetailDelivery.ReferenceNumber
,	PurchaseOrderDetailDelivery.CompanyScheduleQuantity
,	PurchaseOrderDetailDelivery.CompanyBalanceQuantity
	INTO	#PurchaseOrderDetailDelivery
	FROM DataWarehouse..PurchaseOrderDetailDelivery_2008 PurchaseOrderDetailDelivery
WHERE 0 = 1

INSERT INTO #PurchaseOrderDetailDelivery
SELECT	PurchaseOrderDetailDelivery.PurchaseOrderNumber
,	PurchaseOrderDetailDelivery.ReferenceNumber
,	ISNULL(SUM(PurchaseOrderDetailDelivery.CompanyScheduleQuantity), 0) CompanyScheduleQuantity
,	ISNULL(SUM(PurchaseOrderDetailDelivery.CompanyBalanceQuantity), 0) CompanyBalanceQuantity
FROM DataWarehouse..PurchaseOrderDetailDelivery_2008 PurchaseOrderDetailDelivery
GROUP BY PurchaseOrderDetailDelivery.PurchaseOrderNumber
,	PurchaseOrderDetailDelivery.ReferenceNumber




SELECT	PurchaseOrderDetailDelivery.PurchaseOrderNumber
,	PurchaseOrderDetailDelivery.ReferenceNumber
,	ISNULL(SUM(PurchaseOrderDetailDelivery.CompanyScheduleQuantity), 0) CompanyScheduleQuantity
FROM DataWarehouse..PurchaseOrderDetailDelivery_2008 PurchaseOrderDetailDelivery
GROUP BY PurchaseOrderDetailDelivery.PurchaseOrderNumber
,	PurchaseOrderDetailDelivery.ReferenceNumber





SELECT COUNT(*)
FROM DataWarehouse..PurchaseOrderDetailDelivery_2008


SELECT * FROM #PurchaseOrderDetailDelivery

DROP TABLE #PurchaseOrderDetailDelivery