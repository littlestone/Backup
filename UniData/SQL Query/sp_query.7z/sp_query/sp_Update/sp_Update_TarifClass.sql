
ALTER PROCEDURE dbo.sp_Update_TarifClass AS
UPDATE	DataWarehouse..TarifClass
SET		TarifClassName = ISNULL(SYSTBL_I34.DF_PL_DESC, '')
,		CanadianHarmonizedSystemTarifCode = ISNULL(SYSTBL_I34.DF_PG, '')
,		AmericanHarmonizedSystemTarifCode = ISNULL(SYSTBL_I34.GL_DB, '')
FROM		Source..SYSTBL_I34 SYSTBL_I34
		INNER JOIN DataWarehouse..TarifClass TarifClass
			ON SYSTBL_I34.DF_PL = TarifClass.TarifClassCode
WHERE	TarifClass.TarifClassName != ISNULL(SYSTBL_I34.DF_PL_DESC, '')
OR 	CanadianHarmonizedSystemTarifCode != ISNULL(SYSTBL_I34.DF_PG, '')
OR	AmericanHarmonizedSystemTarifCode = ISNULL(SYSTBL_I34.GL_DB, '')
GO
