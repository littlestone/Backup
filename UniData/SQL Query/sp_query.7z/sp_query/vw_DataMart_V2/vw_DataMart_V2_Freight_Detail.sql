CREATE   VIEW dbo.vw_DataMart_V2_Freight_Detail
AS
SELECT	BillOfLading.FiscalPeriodCode
,	BillOfLading.ShippingCompanyCode
,	BillOfLading.ShippingDivisionCode
,	BillOfLading.ShippingCompanyCodeShippingDivisionCode
,	BillOfLading.ShippingWarehouseCode
,	BillOfLading.FreightMethodCode
,	BillOfLading.FreightTermCode
,	BillOfLading.FreightCarrierCode
,	BillOfLading.FreightBrokerCode
,	BillOfLading.FreightTransactionTypeCode
,	BillOfLading.ReceivingCompanyCode
,	BillOfLading.ReceivingDivisionCode
,	BillOfLading.ReceivingCompanyCodeReceivingDivisionCode
,	BillOfLading.CustomerCode
,	BillOfLading.ReceivingCompanyCodeCustomerCode
,	BillOfLading.ReceivingWarehouseCode
,	BillOfLading.LocationCode
,	BillOfLading.BillOfLadingTypeCode
,	BillOfLading.OriginWarehouseCode
,	BillOfLading.DestinationWarehouseCode
,	BillOfLading.CrossDockWarehouseCode
,	BillOfLading.BillOfLadingNumber
,	BillOfLading.ShippingDate
,	BillOfLading.ArrivalDate
,	BillOfLading.OrderNumber
,	BillOfLading.ReleaseNumber
,	BillOfLading.InvoiceNumber
,	BillOfLading.ConsolidatedFreightNumber
,	BillOfLading.DirectSaleReleaseNumber
,	BillOfLading.ManualBillOfLadingNumber
,	BillOfLading.LoadReferenceNumber
,	BillOfLading.SealNumber
,	BillOfLading.ShipToName
,	BillOfLading.ShipToAddressLine1
,	BillOfLading.ShipToAddressLine2
,	BillOfLading.ShipToAddressLine3
,	BillOfLading.ShipToAddressLine4
,	BillOfLading.ShipToCityCode
,	BillOfLading.ShipToStateProvinceCode
,	BillOfLading.ShipToCountryCode
,	BillOfLading.ShipToZipPostalCode
,	BillOfLading.ComputerizedPartNumber
,	BillOfLading.LineItemNumber
,	BillOfLading.ShippingQuantity
,	BillOfLading.ShippingWeight
,	BillOfLading.FreightEstimateAmount
,	BillOfLading.ExtendedCostAmount
,	BillOfLading.CustomerFreightEstimateAmount
,	BillOfLading.DropChargeAmount
,	BillOfLading.FreightChargeAmount
,	1 AS LineItemCount
,	Company.CurrencyCode AS CurrencyCode
,	ISNULL(CurrencyRateCAD.CurrencyRate, 1) AS HistoricCurrencyRateCAD
,	ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1) AS HistoricCurrencyRateUSD
,	ISNULL(CurrencyRateCAD_Current.CurrencyRate, 1) AS CurrentCurrencyRateCAD
,	ISNULL(CurrencyRateCAD_Current.CurrencyRate, 1) / ISNULL(CurrencyRateUSD_Current.CurrencyRate, 1) AS CurrentCurrencyRateUSD
FROM	DataWarehouse..BillOfLading_2001 BillOfLading
	INNER JOIN DataWarehouse..Warehouse ShippingWarehouse
		ON BillOfLading.ShippingWarehouseCode = ShippingWarehouse.WarehouseCode
	INNER JOIN DataWarehouse..Warehouse ReceivingWarehouse
		ON BillOfLading.ReceivingWarehouseCode = ReceivingWarehouse.WarehouseCode
	INNER JOIN DataWarehouse..FiscalTime FiscalTime
		ON CONVERT(varchar(10), GETDATE(), 120) BETWEEN FiscalTime.StartDate AND FiscalTime.EndDate
	INNER JOIN DataWarehouse..Company Company
		ON BillOfLading.ShippingCompanyCode = Company.CompanyCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateCAD
		ON Company.CurrencyCode = CurrencyRateCAD.FromCurrencyCode		AND 'CAD' = CurrencyRateCAD.ToCurrencyCode
		AND BillOfLading.FiscalPeriodCode = CurrencyRateCAD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateUSD
		ON 'CAD' = CurrencyRateUSD.FromCurrencyCode
		AND 'USD' = CurrencyRateUSD.ToCurrencyCode
		AND BillOfLading.FiscalPeriodCode = CurrencyRateUSD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateCAD_Current
		ON Company.CurrencyCode = CurrencyRateCAD_Current.FromCurrencyCode
		AND 'CAD' = CurrencyRateCAD_Current.ToCurrencyCode
		AND FiscalTime.FiscalPeriodCode = CurrencyRateCAD_Current.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateUSD_Current
		ON 'CAD' = CurrencyRateUSD_Current.FromCurrencyCode
		AND 'USD' = CurrencyRateUSD_Current.ToCurrencyCode
		AND FiscalTime.FiscalPeriodCode = CurrencyRateUSD_Current.FiscalPeriodCode
WHERE	ShippingWarehouse.PhantomWarehouse = 0
AND	ReceivingWarehouse.PhantomWarehouse = 0
AND	BillOfLading.FreightTransactionTypeCode NOT IN ('MB', 'WM')



















