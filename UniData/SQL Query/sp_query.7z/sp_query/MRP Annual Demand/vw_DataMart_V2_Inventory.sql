ALTER          VIEW vw_DataMart_V2_Inventory
AS
SELECT	InventoryWarehouse.WarehouseCode
,	InventoryWarehouse.ComputerizedPartNumber
,	InventoryWarehouse.FiscalPeriodCode
,	InventoryWarehouse.WarehouseCodeComputerizedPartNumber
,	InventoryWarehouse.OnHandQuantity
,	InventoryWarehouse.InMaterialReviewBoardQuantity
,	InventoryWarehouse.InReceiptInInspectionQuantity
,	InventoryWarehouse.InTransitQuantity
,	InventoryWarehouse.BookedQuantity
,	InventoryWarehouse.ManufacturingAllocationQuantity
,	InventoryWarehouse.SafetyStockQuantity
,	InventoryWarehouse.AllocationQuantity
,	InventoryWarehouse.PurchaseConsignmentQuantity
,	ISNULL(Product.UnitWeight, 0) AS UnitWeight
,	CurrentMaterialCost = ISNULL(CASE
		WHEN ItemCost_CurrentTransfer.CostTypeCode IS NOT NULL THEN ItemCost_CurrentTransfer.MaterialCost
		ELSE ItemCost_Current.MaterialCost
		END, 0)
,	CurrentVariableCost = ISNULL(CASE
		WHEN ItemCost_CurrentTransfer.CostTypeCode IS NOT NULL THEN ItemCost_CurrentTransfer.VariableCost
		ELSE ItemCost_Current.VariableCost
		END, 0)
,	CurrentFixedCost = ISNULL(CASE
		WHEN ItemCost_CurrentTransfer.CostTypeCode IS NOT NULL THEN ItemCost_CurrentTransfer.FixedCost
		ELSE ItemCost_Current.FixedCost
		END, 0)
,	CurrentOutsideCost = ISNULL(CASE
		WHEN ItemCost_CurrentTransfer.CostTypeCode IS NOT NULL THEN ItemCost_CurrentTransfer.OutsideProcessingCost
		ELSE ItemCost_Current.OutsideProcessingCost
		END, 0)
,	CurrentCost = ISNULL(CASE
		WHEN ItemCost_CurrentTransfer.CostTypeCode IS NOT NULL THEN ItemCost_CurrentTransfer.StandardCost
		ELSE ItemCost_Current.StandardCost
		END, 0)
,	CurrentCurrencyRateCAD = ISNULL(CurrencyRateCAD_Current.CurrencyRate, 1)
,	CurrentCurrencyRateUSD = ISNULL(CurrencyRateCAD_Current.CurrencyRate, 1) / ISNULL(CurrencyRateUSD_Current.CurrencyRate, 1)
,	HistoricMaterialCost = ISNULL(CASE
		WHEN ItemCost_HistoricTransfer.CostTypeCode IS NOT NULL THEN ItemCost_HistoricTransfer.MaterialCost
		ELSE ItemCost_Historic.MaterialCost
		END, 0)
,	HistoricVariableCost = ISNULL(CASE
		WHEN ItemCost_HistoricTransfer.CostTypeCode IS NOT NULL THEN ItemCost_HistoricTransfer.VariableCost
		ELSE ItemCost_Historic.VariableCost
		END, 0)
,	HistoricFixedCost = ISNULL(CASE
		WHEN ItemCost_HistoricTransfer.CostTypeCode IS NOT NULL THEN ItemCost_HistoricTransfer.FixedCost
		ELSE ItemCost_Historic.FixedCost
		END, 0)
,	HistoricOutsideCost = ISNULL(CASE
		WHEN ItemCost_HistoricTransfer.CostTypeCode IS NOT NULL THEN ItemCost_HistoricTransfer.OutsideProcessingCost
		ELSE ItemCost_Historic.OutsideProcessingCost
		END, 0)
,	HistoricCost = ISNULL(CASE
		WHEN ItemCost_HistoricTransfer.CostTypeCode IS NOT NULL THEN ItemCost_HistoricTransfer.StandardCost
		ELSE ItemCost_Historic.StandardCost
		END, 0)
,	HistoricCurrencyRateCAD = ISNULL(CurrencyRateCAD_Historic.CurrencyRate, 1)
,	HistoricCurrencyRateUSD = ISNULL(CurrencyRateCAD_Historic.CurrencyRate, 1) / ISNULL(CurrencyRateUSD_Historic.CurrencyRate, 1)
,	ISNULL(InventoryMaterialResourcePlanning.AnnualDemandQuantity, 0) AS AnnualDemandQuantity
FROM	DataWarehouse..InventoryWarehouse_2001 InventoryWarehouse
	INNER JOIN DataWarehouse..FiscalTime FiscalTime
		ON CONVERT(varchar(10), GETDATE(), 120) BETWEEN FiscalTime.StartDate AND FiscalTime.EndDate
	LEFT JOIN DataWarehouse..Product Product
		ON InventoryWarehouse.ComputerizedPartNumber = Product.ComputerizedPartNumber
	LEFT JOIN DataWarehouse..Warehouse Warehouse
		ON InventoryWarehouse.WarehouseCode = Warehouse.WarehouseCode
	LEFT JOIN DataWarehouse..ItemCost_2001 ItemCost_Historic
		ON InventoryWarehouse.ComputerizedPartNumber = ItemCost_Historic.ComputerizedPartNumber
		AND Warehouse.CostTypeCode = ItemCost_Historic.CostTypeCode
		AND InventoryWarehouse.FiscalPeriodCode = ItemCost_Historic.FiscalPeriodCode
	LEFT JOIN DataWarehouse..ItemCost_2001 ItemCost_HistoricTransfer
		ON ItemCost_Historic.ComputerizedPartNumber = ItemCost_HistoricTransfer.ComputerizedPartNumber
		AND ItemCost_Historic.TransferCostTypeCode = ItemCost_HistoricTransfer.CostTypeCode
		AND ItemCost_Historic.FiscalPeriodCode = ItemCost_HistoricTransfer.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CostType CostType_Historic
		ON ISNULL(ItemCost_HistoricTransfer.CostTypeCode, ItemCost_Historic.CostTypeCode) = CostType_Historic.CostTypeCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateCAD_Historic
		ON CostType_Historic.CurrencyCode = CurrencyRateCAD_Historic.FromCurrencyCode		AND 'CAD' = CurrencyRateCAD_Historic.ToCurrencyCode
		AND InventoryWarehouse.FiscalPeriodCode = CurrencyRateCAD_Historic.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateUSD_Historic
		ON 'CAD' = CurrencyRateUSD_Historic.FromCurrencyCode
		AND 'USD' = CurrencyRateUSD_Historic.ToCurrencyCode
		AND InventoryWarehouse.FiscalPeriodCode = CurrencyRateUSD_Historic.FiscalPeriodCode
	LEFT JOIN DataWarehouse..ItemCost ItemCost_Current
		ON InventoryWarehouse.ComputerizedPartNumber = ItemCost_Current.ComputerizedPartNumber
		AND Warehouse.CostTypeCode = ItemCost_Current.CostTypeCode
	LEFT JOIN DataWarehouse..ItemCost ItemCost_CurrentTransfer
		ON ItemCost_Current.ComputerizedPartNumber = ItemCost_CurrentTransfer.ComputerizedPartNumber
		AND ItemCost_Current.TransferCostTypeCode = ItemCost_CurrentTransfer.CostTypeCode
	LEFT JOIN DataWarehouse..CostType CostType_Current
		ON ISNULL(ItemCost_CurrentTransfer.CostTypeCode, ItemCost_Current.CostTypeCode) = CostType_Current.CostTypeCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateCAD_Current
		ON CostType_Current.CurrencyCode = CurrencyRateCAD_Current.FromCurrencyCode		AND 'CAD' = CurrencyRateCAD_Current.ToCurrencyCode
		AND FiscalTime.FiscalPeriodCode = CurrencyRateCAD_Current.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateUSD_Current
		ON 'CAD' = CurrencyRateUSD_Current.FromCurrencyCode
		AND 'USD' = CurrencyRateUSD_Current.ToCurrencyCode
		AND FiscalTime.FiscalPeriodCode = CurrencyRateUSD_Current.FiscalPeriodCode
	LEFT JOIN DataWarehouse..InventoryMaterialResourcePlanning_2001 InventoryMaterialResourcePlanning
		ON InventoryWarehouse.ComputerizedPartNumber = InventoryMaterialResourcePlanning.ComputerizedPartNumber
		AND InventoryWarehouse.WarehouseCode = InventoryMaterialResourcePlanning.WarehouseCode
		AND InventoryWarehouse.FiscalPeriodCode = InventoryMaterialResourcePlanning.FiscalPeriodCode
WHERE	(InventoryWarehouse.BookedQuantity != 0
OR	InventoryWarehouse.OnHandQuantity != 0
OR	InventoryWarehouse.InMaterialReviewBoardQuantity != 0
OR	InventoryWarehouse.InReceiptInInspectionQuantity != 0
OR	InventoryWarehouse.InTransitQuantity != 0
OR	InventoryWarehouse.ManufacturingAllocationQuantity != 0
OR	InventoryWarehouse.AllocationQuantity != 0)
AND 0 = 1


