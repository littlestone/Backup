ALTER  VIEW dbo.vw_Aliaxis_Purchase_Details_2008
AS
SELECT	vw_Invoice.FiscalPeriodCode
,	ShipToCustomer.ShipToCustomerCode
,	ShipToCustomer.ShipToCustomerName
,	Company.CompanyCode
,	Company.CompanyName
,	Product.ProductCode
,	Product.ProductGroupCode
--,	Product.AliaxisPurchaseFlag
,	ISNULL(vw_Invoice.ShippingWeight, 0) AS ShipKgs
,	ROUND(ISNULL(vw_Invoice.VolumeRebateAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS VolumeRebateCAD
,	ROUND(ISNULL(vw_Invoice.VolumeRebateAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS VolumeRebateUSD
,	ROUND(ISNULL(vw_Invoice.CompetitiveMonthlyAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS CMACMDCAD
,	ROUND(ISNULL(vw_Invoice.CompetitiveMonthlyAllowanceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS CMACMDUSD
,	ROUND(ISNULL(vw_Invoice.CashDiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS CashDiscountCAD
,	ROUND(ISNULL(vw_Invoice.CashDiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS CashDiscountUSD
,	ROUND(ISNULL(vw_Invoice.PrepaidFreightAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS PPDFreightCAD
,	ROUND(ISNULL(vw_Invoice.PrepaidFreightAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS PPDFreightUSD
,	ROUND(ISNULL(vw_Invoice.CommissionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS CommissionCAD
,	ROUND(ISNULL(vw_Invoice.CommissionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS CommissionUSD
,	ROUND(ISNULL(vw_Invoice.WarehouseAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS WhseAllowCAD
,	ROUND(ISNULL(vw_Invoice.WarehouseAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS WhseAllowUSD
,	ROUND(ISNULL(vw_Invoice.FreightAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS FreightAllowCAD
,	ROUND(ISNULL(vw_Invoice.FreightAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS FreightAllowUSD
,	ROUND(ISNULL(vw_Invoice.VendorConcessionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS VendorConcessionCAD
,	ROUND(ISNULL(vw_Invoice.VendorConcessionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS VendorConcessionUSD
,	ROUND(ISNULL(vw_Invoice.ExtendedPriceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - ROUND(ISNULL(vw_Invoice.DiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) + ROUND(ISNULL(vw_Invoice.HandlingChargeAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS GrossSalesCAD
,	ROUND(ISNULL(vw_Invoice.ExtendedPriceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - ROUND(ISNULL(vw_Invoice.DiscountAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) + ROUND(ISNULL(vw_Invoice.HandlingChargeAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS GrossSalesUSD
--	NetSalesCAD
,	ROUND(ISNULL(vw_Invoice.ExtendedPriceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - ROUND(ISNULL(vw_Invoice.DiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) + ROUND(ISNULL(vw_Invoice.HandlingChargeAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CashDiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.PrepaidFreightAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.VolumeRebateAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.FreightAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.WarehouseAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CommissionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CompetitiveMonthlyAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) + 
	ROUND(ISNULL(vw_Invoice.VendorConcessionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS NetSalesCAD
--	NetSalesUSD
,	ROUND(ISNULL(vw_Invoice.ExtendedPriceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - ROUND(ISNULL(vw_Invoice.DiscountAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) + ROUND(ISNULL(vw_Invoice.HandlingChargeAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CashDiscountAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.PrepaidFreightAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.VolumeRebateAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.FreightAllowanceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.WarehouseAllowanceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CommissionAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CompetitiveMonthlyAllowanceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) + 
	ROUND(ISNULL(vw_Invoice.VendorConcessionAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS NetSalesUSD
,	ROUND(ISNULL(vw_Invoice.ExtendedCostAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) AS CostCAD
,	ROUND(ISNULL(vw_Invoice.ExtendedCostAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1) / ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) AS CostUSD
--	MarginCAD
,	(ROUND(ISNULL(vw_Invoice.ExtendedPriceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - ROUND(ISNULL(vw_Invoice.DiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) + ROUND(ISNULL(vw_Invoice.HandlingChargeAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CashDiscountAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.PrepaidFreightAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.VolumeRebateAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.FreightAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.WarehouseAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CommissionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CompetitiveMonthlyAllowanceAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2) + 
	ROUND(ISNULL(vw_Invoice.VendorConcessionAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2)) -
	(ROUND(ISNULL(vw_Invoice.ExtendedCostAmount, 0) * ISNULL(CurrencyRateCAD.CurrencyRate, 1), 2)) AS MarginCAD
--	MarginUSD
,	(ROUND(ISNULL(vw_Invoice.ExtendedPriceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - ROUND(ISNULL(vw_Invoice.DiscountAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) + ROUND(ISNULL(vw_Invoice.HandlingChargeAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CashDiscountAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.PrepaidFreightAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.VolumeRebateAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.FreightAllowanceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.WarehouseAllowanceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CommissionAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) - 
	ROUND(ISNULL(vw_Invoice.CompetitiveMonthlyAllowanceAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2) + 
	ROUND(ISNULL(vw_Invoice.VendorConcessionAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2)) -
	(ROUND(ISNULL(vw_Invoice.ExtendedCostAmount, 0) * ISNULL(CurrencyRateUSD.CurrencyRate, 1), 2)) AS MarginUSD
FROM	DataWarehouse..vw_Invoice_2008 vw_Invoice
	LEFT JOIN DataWarehouse..Product Product
		ON vw_Invoice.ComputerizedPartNumber = Product.ComputerizedPartNumber
	LEFT JOIN DataWarehouse..ShipToCustomer OverwriteShipToCustomer
		ON vw_Invoice.CompanyCode = OverwriteShipToCustomer.CompanyCode
		AND vw_Invoice.CustomerCode = OverwriteShipToCustomer.ShipToCustomerCode
	LEFT JOIN DataWarehouse..ShipToCustomer ShipToCustomer
		ON OverwriteShipToCustomer.CompanyCode = ShipToCustomer.CompanyCode
		AND OverwriteShipToCustomer.OverwriteShipToCustomerCode = ShipToCustomer.ShipToCustomerCode
	INNER JOIN DataWarehouse..Company Company
		ON vw_Invoice.CompanyCode = Company.CompanyCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateCAD
		ON Company.CurrencyCode = CurrencyRateCAD.FromCurrencyCode		AND 'CAD' = CurrencyRateCAD.ToCurrencyCode
		AND vw_Invoice.FiscalPeriodCode = CurrencyRateCAD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CurrencyRateUSD
		ON 'CAD' = CurrencyRateUSD.FromCurrencyCode
		AND 'USD' = CurrencyRateUSD.ToCurrencyCode
		AND vw_Invoice.FiscalPeriodCode = CurrencyRateUSD.FiscalPeriodCode
WHERE	AliaxisPurchaseFlag = 'Y'	-- Products purchased from Aliaxis group companies
