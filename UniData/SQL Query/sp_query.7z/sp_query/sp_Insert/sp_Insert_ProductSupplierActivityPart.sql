ALTER PROCEDURE dbo.sp_Insert_ProductSupplierActivityPart AS
INSERT	DataWarehouse..ProductSupplierActivityPart
	(ComputerizedPartNumber
,	CompanyCode
,	SupplierCode
,	SupplierProductCode)
SELECT	ISNULL(LEFT(ITMSUPPACT_PART.ID, CHARINDEX('*', ITMSUPPACT_PART.ID) - 1), '')
,	ISNULL(LEFT(SUBSTRING(ITMSUPPACT_PART.ID, CHARINDEX('*', ITMSUPPACT_PART.ID) + 1, LEN(ITMSUPPACT_PART.ID)), CHARINDEX('*', SUBSTRING(ITMSUPPACT_PART.ID, CHARINDEX('*', ITMSUPPACT_PART.ID) + 1, LEN(ITMSUPPACT_PART.ID))) - 1), '')
,	ISNULL(RIGHT(ITMSUPPACT_PART.ID, CHARINDEX('*', ITMSUPPACT_PART.ID)), '')
,	ISNULL(ITMSUPPACT_PART.SUPPLIER_PART, '')
FROM	Source..ITMSUPPACT_PART ITMSUPPACT_PART
	LEFT JOIN DataWarehouse..ProductSupplierActivityPart ProductSupplierActivityPart
		ON ISNULL(LEFT(ITMSUPPACT_PART.ID, CHARINDEX('*', ITMSUPPACT_PART.ID) - 1), '') = ProductSupplierActivityPart.ComputerizedPartNumber
		AND ISNULL(LEFT(SUBSTRING(ITMSUPPACT_PART.ID, CHARINDEX('*', ITMSUPPACT_PART.ID) + 1, LEN(ITMSUPPACT_PART.ID)), CHARINDEX('*', SUBSTRING(ITMSUPPACT_PART.ID, CHARINDEX('*', ITMSUPPACT_PART.ID) + 1, LEN(ITMSUPPACT_PART.ID))) - 1), '') = ProductSupplierActivityPart.CompanyCode
		AND ISNULL(RIGHT(ITMSUPPACT_PART.ID, CHARINDEX('*', ITMSUPPACT_PART.ID)), '') = ProductSupplierActivityPart.SupplierCode
		AND ISNULL(ITMSUPPACT_PART.SUPPLIER_PART, '') = ProductSupplierActivityPart.SupplierProductCode
WHERE	ProductSupplierActivityPart.ComputerizedPartNumber IS NULL
AND	ProductSupplierActivityPart.CompanyCode IS NULL
AND	ProductSupplierActivityPart.SupplierCode IS NULL
AND	ProductSupplierActivityPart.SupplierProductCode IS NULL



GO
