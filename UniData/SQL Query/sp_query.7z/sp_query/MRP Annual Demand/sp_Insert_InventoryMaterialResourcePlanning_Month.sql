ALTER      PROCEDURE dbo.sp_Insert_InventoryMaterialResourcePlanning_Month
(		@strMonth	varchar(7))
WITH RECOMPILE
AS

DECLARE	@strSQL		varchar(8000)
,	@strYear	varchar(4)

SELECT	@strYear = LEFT(@strMonth, CHARINDEX('-', @strMonth) - 1)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryMaterialResourcePlanning_' + @strYear)
BEGIN
	SELECT	@strSQL =	'INSERT	DataWarehouse..InventoryMaterialResourcePlanning_' + @strYear + ' ' +
				'	(WarehouseCode' + ' ' +
				',	ComputerizedPartNumber' + ' ' +
				',	FiscalPeriodCode' + ' ' +
				',	AnnualDemandQuantity)' + ' ' +
				'SELECT	RIGHT(INVMRP.ID, LEN(INVMRP.ID) - CHARINDEX(''*'', INVMRP.ID))' + ' ' +
				',	LEFT(INVMRP.ID, CHARINDEX(''*'', INVMRP.ID) - 1)' + ' ' +
				',	''' + @strMonth + '''' + ' ' +
				',	ISNULL(INVMRP.ABC_DEMAND, 0)' + ' ' +
				'FROM	Source..INVMRP INVMRP' + ' ' +
				'	LEFT JOIN DataWarehouse..InventoryMaterialResourcePlanning_' + @strYear + ' InventoryMaterialResourcePlanning' + ' ' +
				'		ON RIGHT(INVMRP.ID, LEN(INVMRP.ID) - CHARINDEX(''*'', INVMRP.ID)) = InventoryMaterialResourcePlanning.WarehouseCode' + ' ' +
				'		AND LEFT(INVMRP.ID, CHARINDEX(''*'', INVMRP.ID) - 1) = InventoryMaterialResourcePlanning.ComputerizedPartNumber' + ' ' +
				'		AND ''' + @strMonth + ''' = InventoryMaterialResourcePlanning.FiscalPeriodCode' + ' ' +
				'WHERE	InventoryMaterialResourcePlanning.WarehouseCode IS NULL' + ' ' +
				'AND	InventoryMaterialResourcePlanning.ComputerizedPartNumber IS NULL' + ' ' +
				'AND	InventoryMaterialResourcePlanning.FiscalPeriodCode IS NULL' + ' ' +
				'AND 	InventoryMaterialResourcePlanning.AnnualDemandQuantity IS NULL'
	
	EXEC	(@strSQL)
END



GO
