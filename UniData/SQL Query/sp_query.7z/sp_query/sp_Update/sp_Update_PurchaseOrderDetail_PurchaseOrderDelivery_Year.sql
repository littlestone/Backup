ALTER     PROCEDURE dbo.sp_Update_PurchaseOrderDetail_PurchaseOrderDelivery_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

SELECT PurchaseOrderDetailDelivery.PurchaseOrderNumber
,	PurchaseOrderDetailDelivery.ReferenceNumber
,	PurchaseOrderDetailDelivery.CompanyUnitCost
,	PurchaseOrderDetailDelivery.CompanyScheduleQuantity
,	PurchaseOrderDetailDelivery.CompanyBalanceQuantity
INTO	#PurchaseOrderDetailDelivery
FROM DataWarehouse..PurchaseOrderDetailDelivery_2008 PurchaseOrderDetailDelivery
WHERE 0 = 1

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
	AND EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetailDelivery_' + @strYear)
BEGIN
	SELECT	@strSQL = 'INSERT #PurchaseOrderDetailDelivery' + ' ' +
			'(	PurchaseOrderNumber' + ' ' +
			',	ReferenceNumber' + ' ' +
			',	CompanyUnitCost' + ' ' +
			',	CompanyScheduleQuantity' + ' ' +
			',	CompanyBalanceQuantity)' + ' ' +
			'SELECT	PurchaseOrderDetailDelivery.PurchaseOrderNumber' + ' ' +
			',	PurchaseOrderDetailDelivery.ReferenceNumber' + ' ' +
			',	ISNULL(MAX(PurchaseOrderDetailDelivery.CompanyUnitCost), 0)' + ' ' +
			',	ISNULL(SUM(PurchaseOrderDetailDelivery.CompanyScheduleQuantity), 0)' + ' ' +
			',	ISNULL(SUM(PurchaseOrderDetailDelivery.CompanyBalanceQuantity), 0)' + ' ' +
			'FROM	DataWarehouse..PurchaseOrderDetailDelivery_' + @strYear + ' PurchaseOrderDetailDelivery' + ' ' +
			'GROUP BY PurchaseOrderDetailDelivery.PurchaseOrderNumber' + ' ' +
			',	PurchaseOrderDetailDelivery.ReferenceNumber'
	EXEC	(@strSQL)

	SELECT	@strSQL = 'UPDATE DataWarehouse..PurchaseOrderDetail_' + @strYear + ' ' +
			'SET	CompanyUnitCost = #PurchaseOrderDetailDelivery.CompanyUnitCost' + ' ' +
			',	CompanyScheduleQuantity = #PurchaseOrderDetailDelivery.CompanyScheduleQuantity' + ' ' +
			',	CompanyBalanceQuantity = #PurchaseOrderDetailDelivery.CompanyBalanceQuantity' + ' ' +
			'FROM	DataWarehouse..PurchaseOrderDetail_' + @strYear + ' PurchaseOrderDetail' + ' ' +
			'	LEFT JOIN #PurchaseOrderDetailDelivery' + ' ' +
			'		ON PurchaseOrderDetail.PurchaseOrderNumber = #PurchaseOrderDetailDelivery.PurchaseOrderNumber' + ' ' +
			'		AND PurchaseOrderDetail.ReferenceNumber = #PurchaseOrderDetailDelivery.ReferenceNumber' + ' ' +
			'WHERE	PurchaseOrderDetail.CompanyUnitCost != #PurchaseOrderDetailDelivery.CompanyUnitCost' + ' ' +
			'OR		 PurchaseOrderDetail.CompanyScheduleQuantity != #PurchaseOrderDetailDelivery.CompanyScheduleQuantity' + ' ' +
			'OR		 PurchaseOrderDetail.CompanyBalanceQuantity != #PurchaseOrderDetailDelivery.CompanyBalanceQuantity'

	EXEC	(@strSQL)
END



GO
