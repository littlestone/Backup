SELECT *
INTO Source..PODET
FROM Source..PODET_Backup_200803
WHERE 0=1


SELECT *
INTO Source..PODET_DELIVERY
FROM Source..PODET_DELIVERY_Backup_200803
WHERE 0=1


SELECT *
INTO Source..PODET_RECEIPT
FROM Source..PODET_RECEIPT_Backup_200803
WHERE 0=1


SELECT *
INTO Source..POHDR
FROM Source..POHDR_Backup_200803
WHERE 0=1


SELECT *
INTO Source..POHDR_LINEITEM
FROM Source..POHDR_LINEITEM_Backup_200803
WHERE 0=1


-- For Source Database
TRUNCATE TABLE Source..PODET
TRUNCATE TABLE Source..PODET_DELIVERY
TRUNCATE TABLE Source..PODET_RECEIPT
TRUNCATE TABLE Source..POHDR
TRUNCATE TABLE Source..POHDR_LINEITEM


-- For DataWarehouse Database
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetail_2001
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailDelivery_2001
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailReceipt_2001
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeader_2001
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeaderLineItem_2001

TRUNCATE TABLE DataWarehouse..PurchaseOrderDetail_2002
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailDelivery_2002
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailReceipt_2002
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeader_2002
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeaderLineItem_2002

TRUNCATE TABLE DataWarehouse..PurchaseOrderDetail_2003
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailDelivery_2003
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailReceipt_2003
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeader_2003
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeaderLineItem_2003

TRUNCATE TABLE DataWarehouse..PurchaseOrderDetail_2004
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailDelivery_2004
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailReceipt_2004
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeader_2004
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeaderLineItem_2004

TRUNCATE TABLE DataWarehouse..PurchaseOrderDetail_2005
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailDelivery_2005
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailReceipt_2005
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeader_2005
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeaderLineItem_2005

TRUNCATE TABLE DataWarehouse..PurchaseOrderDetail_2006
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailDelivery_2006
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailReceipt_2006
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeader_2006
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeaderLineItem_2006

TRUNCATE TABLE DataWarehouse..PurchaseOrderDetail_2007
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailDelivery_2007
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailReceipt_2007
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeader_2007
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeaderLineItem_2007

TRUNCATE TABLE DataWarehouse..PurchaseOrderDetail_2008
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailDelivery_2008
TRUNCATE TABLE DataWarehouse..PurchaseOrderDetailReceipt_2008
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeader_2008
TRUNCATE TABLE DataWarehouse..PurchaseOrderHeaderLineItem_2008







