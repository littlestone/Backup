


ALTER   PROCEDURE dbo.sp_Update_ABCDClass_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..ABCDClass
SET	Active = 0
WHERE	NULLIF(ABCDClassCode, '') IS NOT NULL

SELECT	ABCDClass.ABCDClassCode
INTO	#ABCDClass
FROM	DataWarehouse..ABCDClass ABCDClass
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Forecast_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#ABCDClass' + ' ' +
					'	(ABCDClassCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	ISNULL(ProductGroupRegionGroup.ABCCode, '')' + ' ' +
					'FROM	DataWarehouse..Forecast_' + @strYear + ' Forecast' + ' ' +
					'	LEFT JOIN DataWarehouse..ProductGroupRegionGroup ProductGroupRegionGroup' + ' ' +
					'		ON Forecast.ProductGroupCode = ProductGroupRegionGroup.ProductGroupCode' + ' ' +
					'		AND Forecast.RegionGroupCode = ProductGroupRegionGroup.RegionGroupCode'
		EXEC	(@strSQL)
	END

	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..ABCDClass
SET	Active = 1
FROM	DataWarehouse..ABCDClass ABCDClass
	INNER JOIN #ABCDClass
		ON ABCDClass.ABCDClassCode = #ABCDClass.ABCDClassCode

DROP	TABLE #ABCDClass

GO
