ALTER PROCEDURE dbo.sp_Update_Country AS
UPDATE	DataWarehouse..Country
SET	CountryName = ISNULL(SYSTBL_ECC.DF_PL_DESC, '')
FROM	Source..SYSTBL_ECC SYSTBL_ECC
	INNER JOIN DataWarehouse..Country Country
		ON SYSTBL_ECC.DF_PL = Country.CountryCode
WHERE	Country.CountryName != ISNULL(SYSTBL_ECC.DF_PL_DESC, '')

GO
