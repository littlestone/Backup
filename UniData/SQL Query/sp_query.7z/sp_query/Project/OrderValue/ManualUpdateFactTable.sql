SELECT *
INTO SalesOrder_2008_20080911
FROM SalesOrder_2008



DROP TABLE SalesOrder_2008_New

SELECT *
INTO SalesOrder_2008_New
FROM SalesOrder_2008


EXEC sp_Update_SalesOrder_OrderValue_20080910


SELECT OrderNumber
,	SUM(ExtendedPriceAmount)
,	OrderValueCode
FROM SalesOrder_2008_New
WHERE OrderNumber = '66350306'
GROUP BY OrderNumber
,	OrderValueCode
