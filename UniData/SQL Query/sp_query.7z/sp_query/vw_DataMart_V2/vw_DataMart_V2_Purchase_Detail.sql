ALTER   VIEW vw_DataMart_V2_Purchase_Detail
AS
SELECT 	PurchaseOrderHeader.PurchaseOrderNumber
,	PurchaseOrderHeader.BuyerCode
,	PurchaseOrderHeader.FreightCarrierCode
,	PurchaseOrderHeader.WarehouseCode
,	PurchaseOrderHeader.PurchaseOrderClassCode
,	PurchaseOrderHeader.FreightTermCode
,	PurchaseOrderHeader.FreightOnBoardCode
,	PurchaseOrderHeader.FiscalPeriodCode
,	PurchaseOrderHeader.OrderStatusCode
,	PurchaseOrderHeader.CompanyCodeSupplierCode
,	PurchaseOrderHeader.CompanyCodeDivisionCode
,	PurchaseOrderHeaderLineItem.LineItemNumber
,	PurchaseOrderHeaderLineItem.LineItemStatusCode
,	PurchaseOrderDetail.ReferenceNumber
,	PurchaseOrderDetail.CompanyUnitOfMeasureCode
,	PurchaseOrderHeader.CompanyReferenceNumber
,	PurchaseOrderHeader.QuoteNumber
,	PurchaseOrderDetail.PartDescription
,	PurchaseOrderDetail.SupplierPartNumber
,	PurchaseOrderDetail.ProductCode
,	PurchaseOrderDetail.GeneralLedgerAccountCode
,	PurchaseOrderDetail.WorkOrderNumber
,	PurchaseOrderDetail.ContractQuantity
,	PurchaseOrderDetail.ContractUnitPrice
,	PurchaseOrderDetail.SupplierUnitOfMeasureCode
,	PurchaseOrderDetail.ConversionFactor
,	PurchaseOrderDetail.InspectionRequestFlag
,	PurchaseOrderDetail.PartRevisionLevel
,	PurchaseOrderDetail.RequisitionNumber
,	PurchaseOrderDetail.RequestorName
,	PurchaseOrderDetail.TaxFlag
,	PurchaseOrderDetail.ChargeTypeCode
,	PurchaseOrderDetail.ComputerizedPartNumber
,	PurchaseOrderHeader.PurchaseOrderDate
,	PurchaseOrderHeader.ChangeDate
,	PurchaseOrderHeader.ConfirmDate
,	PurchaseOrderHeader.ShipToCode
,	PurchaseOrderHeader.ShipToName
,	PurchaseOrderHeader.ShipToAddressLine1
,	PurchaseOrderHeader.ShipToAddressLine2
,	PurchaseOrderHeader.ShipToAddressLine3
,	PurchaseOrderHeader.ShipToAddressLine4
,	PurchaseOrderHeader.ShipToAddressLine5
,	PurchaseOrderHeader.ShipToAddressLine6
,	PurchaseOrderDetail.CompanyUnitCost
,	PurchaseOrderDetail.CompanyScheduleQuantity
,	PurchaseOrderDetail.CompanyBalanceQuantity
,	PurchaseOrderDetail.CompanyReceiveQuantity
,	ISNULL(Product.UnitWeight, 0) AS UnitWeight
,	ISNULL(CompanyCurrencyRateCAD.CurrencyRate, 1) AS CompanyCurrencyRateCAD
,	ISNULL(CompanyCurrencyRateCAD.CurrencyRate, 1) / ISNULL(CompanyCurrencyRateUSD.CurrencyRate, 1) AS CompanyCurrencyRateUSD
,	1 AS LineItemCount
FROM	DataWarehouse..PurchaseOrderHeader_2001 PurchaseOrderHeader
	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_2001 PurchaseOrderHeaderLineItem
		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber
	INNER JOIN DataWarehouse..PurchaseOrderDetail_2001 PurchaseOrderDetail
		ON PurchaseOrderHeaderLineItem.PurchaseOrderNumber = PurchaseOrderDetail.PurchaseOrderNumber
		AND PurchaseOrderHeaderLineItem.ReferenceNumber = PurchaseOrderDetail.ReferenceNumber
	LEFT JOIN DataWarehouse..Company Company
		ON PurchaseOrderHeader.CompanyCode = Company.CompanyCode
	LEFT JOIN DataWarehouse..CurrencyRate CompanyCurrencyRateCAD
		ON Company.CurrencyCode = CompanyCurrencyRateCAD.FromCurrencyCode		AND 'CAD' = CompanyCurrencyRateCAD.ToCurrencyCode
		AND PurchaseOrderHeader.FiscalPeriodCode = CompanyCurrencyRateCAD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..CurrencyRate CompanyCurrencyRateUSD
		ON 'CAD' = CompanyCurrencyRateUSD.FromCurrencyCode
		AND 'USD' = CompanyCurrencyRateUSD.ToCurrencyCode
		AND PurchaseOrderHeader.FiscalPeriodCode = CompanyCurrencyRateUSD.FiscalPeriodCode
	LEFT JOIN DataWarehouse..Product Product
		ON PurchaseOrderDetail.ComputerizedPartNumber = Product.ComputerizedPartNumber
WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != 'X'
AND	0 = 1





















