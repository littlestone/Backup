CREATE PROCEDURE dbo.sp_Update_FreightOnBoard_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..FreightOnBoard
SET	Active = 0
WHERE	NULLIF(FreightOnBoardCode, '') IS NOT NULL

SELECT	FreightOnBoard.FreightOnBoardCode
INTO	#FreightOnBoard
FROM	DataWarehouse..FreightOnBoard FreightOnBoard
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderHeader_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FreightOnBoard' + ' ' +
					'	(FreightOnBoardCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	PurchaseOrderHeader.FreightOnBoardCode' + ' ' +
					'FROM	DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' + 
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' PurchaseOrderHeaderLineItem' + ' ' +
					'		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X'''
		EXEC	(@strSQL)
	END	


	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..FreightOnBoard
SET	Active = 1
FROM	DataWarehouse..FreightOnBoard FreightOnBoard
	INNER JOIN #FreightOnBoard
		ON FreightOnBoard.FreightOnBoardCode = #FreightOnBoard.FreightOnBoardCode

DROP	TABLE #FreightOnBoard

GO
