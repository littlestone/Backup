
ALTER   PROCEDURE dbo.sp_Update_CountryStateProvinceCity_Active AS

UPDATE	DataWarehouse..CountryStateProvinceCity
SET	Active = 0
WHERE	NULLIF(CountryCode, '') IS NOT NULL
OR	NULLIF(StateProvinceCode, '') IS NOT NULL
OR	NULLIF(CityCode, '') IS NOT NULL

SELECT	CountryStateProvinceCity.CountryCode
,	CountryStateProvinceCity.StateProvinceCode
,	CountryStateProvinceCity.CityCode
INTO	#CountryStateProvinceCity
FROM	DataWarehouse..CountryStateProvinceCity CountryStateProvinceCity
WHERE	0 = 1

INSERT	#CountryStateProvinceCity
	(CountryCode
,	StateProvinceCode
,	CityCode)
SELECT DISTINCT	Warehouse.CountryCode
,	Warehouse.StateProvinceCode
,	Warehouse.CityCode
FROM	DataWarehouse..Warehouse Warehouse
WHERE	Warehouse.Active = 1

INSERT	#CountryStateProvinceCity
	(CountryCode
,	StateProvinceCode
,	CityCode)
SELECT DISTINCT	Supplier.CountryCode
,	Supplier.StateProvinceCode
,	Supplier.CityCode
FROM	DataWarehouse..Supplier Supplier
WHERE	Supplier.Active = 1

-- Set active field based on supplier purchase information
INSERT	#CountryStateProvinceCity
	(CountryCode
,	StateProvinceCode
,	CityCode)
SELECT DISTINCT	Supplier.PurchasingCountryCode
,	Supplier.PurchasingStateProvinceCode
,	Supplier.PurchasingCityCode
FROM	DataWarehouse..Supplier Supplier
WHERE	Supplier.Active = 1

INSERT	#CountryStateProvinceCity
	(CountryCode
,	StateProvinceCode
,	CityCode)
SELECT DISTINCT	ShipToCustomer.CountryCode
,	ShipToCustomer.StateProvinceCode
,	ShipToCustomer.CityCode
FROM	DataWarehouse..ShipToCustomer ShipToCustomer
WHERE	ShipToCustomer.Active = 1

UPDATE	DataWarehouse..CountryStateProvinceCity
SET	Active = 1
FROM	DataWarehouse..CountryStateProvinceCity CountryStateProvinceCity
	INNER JOIN #CountryStateProvinceCity
		ON CountryStateProvinceCity.CountryCode =#CountryStateProvinceCity.CountryCode
		AND CountryStateProvinceCity.StateProvinceCode = #CountryStateProvinceCity.StateProvinceCode
		AND CountryStateProvinceCity.CityCode = #CountryStateProvinceCity.CityCode

DROP	TABLE #CountryStateProvinceCity


GO
