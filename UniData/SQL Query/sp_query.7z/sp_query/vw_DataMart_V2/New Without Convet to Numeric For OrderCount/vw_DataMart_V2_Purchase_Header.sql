ALTER  VIEW vw_DataMart_V2_Purchase_Header
AS
SELECT 	PurchaseOrderHeader.PurchaseOrderNumber
,	PurchaseOrderHeader.BuyerCode
,	PurchaseOrderHeader.FreightCarrierCode
,	PurchaseOrderHeader.WarehouseCode
,	PurchaseOrderHeader.PurchaseOrderClassCode
,	PurchaseOrderHeader.FreightTermCode
,	PurchaseOrderHeader.FiscalPeriodCode
,	PurchaseOrderHeader.OrderStatusCode
,	PurchaseOrderHeader.CompanyCodeSupplierCode
,	PurchaseOrderHeader.CompanyCodeDivisionCode
,	PurchaseOrderHeaderLineItem.LineItemStatusCode
,	PurchaseOrderDetail.ComputerizedPartNumber
,	PurchaseOrderDetail.ProductCode
,	PurchaseOrderDetail.GeneralLedgerAccountCode
,	PurchaseOrderDetail.WorkOrderNumber
,	PurchaseOrderDetail.ChargeTypeCode
,	PurchaseOrderHeader.PurchaseOrderNumber + PurchaseOrderHeader.FiscalPeriodCode AS OrderCount 
FROM	DataWarehouse..PurchaseOrderHeader_2001 PurchaseOrderHeader
	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_2001 PurchaseOrderHeaderLineItem
		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber
	INNER JOIN DataWarehouse..PurchaseOrderDetail_2001 PurchaseOrderDetail
		ON PurchaseOrderHeaderLineItem.PurchaseOrderNumber = PurchaseOrderDetail.PurchaseOrderNumber
		AND PurchaseOrderHeaderLineItem.ReferenceNumber = PurchaseOrderDetail.ReferenceNumber
WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != 'X'
AND 0 = 1