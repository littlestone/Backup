




--Notes: TransactionTypeCode (52->Credit, 51->Debit).
--If credit/debit and pricing error, then zero out quantities and weights.
--If credit, negate the quantities, weights, and $.
--If did not find a DeliveryStatusCode (because no SODEL), 
--	the use appropriate values from LineItem order detail and populate dummy delivery
--	DeliveryStatusCode will take LineItemStatusCode if not found
--If LineItemStatus is cancelled (C), then zero out all quantities, weights, and $.
--Note, in SalesOrder_YYYY table: OrderWeight is per unit weight in Kgs;
--	LineItemCustomerOrderQuantity has same value as LineItemCustomerBalanceDueQuantity

CREATE      VIEW vw_SalesOrder_2008_New
AS
SELECT	SalesOrder.OrderNumber
,	SalesOrder.CompanyCode
,	SalesOrder.CustomerCode
,	SalesOrder.ShipToName
,	SalesOrder.ShipToAddressLine1
,	SalesOrder.ShipToAddressLine2
,	SalesOrder.CountryStateProvinceZipPostalCode
,	SalesOrder.ShipToContact
,	SalesOrder.OrderDate
,	SalesOrder.RequestDate
,	SalesOrder.CustomerOrderDate
,	SalesOrder.OrderSourceCode
,	SalesOrder.TaxCode
,	SalesOrder.DivisionCode
,	SalesOrder.CustomerPurchaseOrderNumber
,	SalesOrder.TransactionTypeCode
,	SalesOrder.OrderStatusCode
,	SalesOrder.SalesPayTermCode
,	SalesOrder.FreightOnBoardCode
,	SalesOrder.ShipToAddressLine3
,	SalesOrder.OperatorCode
,	SalesOrder.OrderTypeCode
,	SalesOrder.QuoteNumber
,	SalesOrder.CountryCode
,	SalesOrder.ElectronicDataInterchangePurchaseOrderKey
,	SalesOrder.ReturnMaterialAuthorizationOrderNumber
,	SalesOrder.JobsiteFlag
,	SalesOrder.SalesOfficeCode
,	SalesOrder.ReleaseNumber
,	SalesOrder.ReleaseDate
,	SalesOrder.DiscountReasonCode
,	SalesOrder.ShipToAddressLine4
,	SalesOrder.CreditDebitReasonCode
,	SalesOrder.OrderReasonCode
,	SalesOrder.CompleteDate
,	SalesOrder.ComputerizedPartNumber
,	LineItemOrderQuantity = SalesOrder.LineItemOrderQuantity 
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	LineItemBalanceDueQuantity = (SalesOrder.LineItemOrderQuantity - SalesOrder.LineItemShipQuantity)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	LineItemShipQuantity = SalesOrder.LineItemShipQuantity
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	SalesOrder.LineItemStatusCode
,	ExtendedCostAmount = SalesOrder.ExtendedCostAmount 
		* (CASE WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DiscountAmount = SalesOrder.DiscountAmount 
		* (CASE WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	ExtendedTaxAmount = SalesOrder.ExtendedTaxAmount 
		* (CASE WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	SalesOrder.WarehouseCode
,	SalesOrder.AdjustmentType
,	SalesOrder.SalesPostingCode
,	SalesOrder.ReturnMaterialAuthorizationLineNumber
,	SalesOrder.CustomerPartNumber
,	ExtendedPriceAmount = SalesOrder.ExtendedPriceAmount 
		* (CASE WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	LineItemCustomerOrderQuantity = (SalesOrder.LineItemCustomerBalanceDueQuantity + SalesOrder.LineItemCustomerShipQuantity)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	LineItemCustomerBalanceDueQuantity = SalesOrder.LineItemCustomerBalanceDueQuantity
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	LineItemCustomerShipQuantity = SalesOrder.LineItemCustomerShipQuantity
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	SalesOrder.PackageQuantity
,	LineItemOrderWeight = SalesOrder.OrderWeight * SalesOrder.LineItemOrderQuantity 
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	HandlingChargeAmount = SalesOrder.HandlingChargeAmount 
		* (CASE WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	SalesOrder.CustomerLineItemNumber
,	DeliveryOrderQuantity = (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN SalesOrder.LineItemOrderQuantity ELSE SalesOrder.DeliveryOrderQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryBalanceDueQuantity = (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN (SalesOrder.LineItemOrderQuantity - SalesOrder.LineItemShipQuantity) ELSE SalesOrder.DeliveryBalanceDueQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryShipQuantity = (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN SalesOrder.LineItemShipQuantity ELSE SalesOrder.DeliveryShipQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryShipAllocationQuantity = (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN 0 ELSE SalesOrder.DeliveryShipAllocationQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	SalesOrder.ScheduleDate
,	DeliveryStatusCode = (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN SalesOrder.LineItemStatusCode ELSE SalesOrder.DeliveryStatusCode END)
,	DeliveryCustomerOrderQuantity = (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN (SalesOrder.LineItemCustomerBalanceDueQuantity + SalesOrder.LineItemCustomerShipQuantity) ELSE SalesOrder.DeliveryCustomerOrderQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryCustomerBalanceDueQuantity = (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN SalesOrder.LineItemCustomerBalanceDueQuantity ELSE SalesOrder.DeliveryCustomerBalanceDueQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryCustomerShipQuantity = (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN SalesOrder.LineItemCustomerShipQuantity ELSE (SalesOrder.DeliveryCustomerOrderQuantity - SalesOrder.DeliveryCustomerBalanceDueQuantity) END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryCustomerShipAllocationQuantity = (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN 0 ELSE SalesOrder.DeliveryCustomerShipAllocationQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryOrderWeight = SalesOrder.OrderWeight * (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN SalesOrder.LineItemOrderQuantity ELSE SalesOrder.DeliveryOrderQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryBalanceDueWeight = SalesOrder.OrderWeight * (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN (SalesOrder.LineItemOrderQuantity - SalesOrder.LineItemShipQuantity) ELSE SalesOrder.DeliveryBalanceDueQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryShipWeight = SalesOrder.OrderWeight * (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN SalesOrder.LineItemShipQuantity ELSE SalesOrder.DeliveryShipQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryShipAllocationWeight = SalesOrder.OrderWeight * (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN 0 ELSE SalesOrder.DeliveryShipAllocationQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode IN ('51', '52') AND SalesOrder.AdjustmentType = 'P' THEN 0
			WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryOrderExtendedPriceAmount = (CASE WHEN SalesOrder.LineItemOrderQuantity = 0 THEN 0 ELSE SalesOrder.ExtendedPriceAmount / SalesOrder.LineItemOrderQuantity END)
		* (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN SalesOrder.LineItemOrderQuantity ELSE SalesOrder.DeliveryOrderQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryBalanceDueExtendedPriceAmount = (CASE WHEN SalesOrder.LineItemOrderQuantity = 0 THEN 0 ELSE SalesOrder.ExtendedPriceAmount / SalesOrder.LineItemOrderQuantity END)
		* (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN (SalesOrder.LineItemOrderQuantity - SalesOrder.LineItemShipQuantity) ELSE SalesOrder.DeliveryBalanceDueQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryShipExtendedPriceAmount = (CASE WHEN SalesOrder.LineItemOrderQuantity = 0 THEN 0 ELSE SalesOrder.ExtendedPriceAmount / SalesOrder.LineItemOrderQuantity END)
		* (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN SalesOrder.LineItemShipQuantity ELSE SalesOrder.DeliveryShipQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	DeliveryShipAllocationExtendedPriceAmount = (CASE WHEN SalesOrder.LineItemOrderQuantity = 0 THEN 0 ELSE SalesOrder.ExtendedPriceAmount / SalesOrder.LineItemOrderQuantity END)
		* (CASE WHEN SalesOrder.DeliveryStatusCode = '' THEN 0 ELSE SalesOrder.DeliveryShipAllocationQuantity END)
		* (CASE WHEN SalesOrder.TransactionTypeCode = '52' THEN -1 ELSE 1 END)
,	SalesOrder.FillRateOrderQuantity
,	SalesOrder.FillRateAllocatedQuantity
,	SalesOrder.FillRateAllocatedDate
,	SalesOrder.OrderValueCode
,	SalesOrder.CompanyCodeDivisionCode
,	SalesOrder.CompanyCodeCustomerCode
,	SalesOrder.WarehouseCodeComputerizedPartNumber
,	SalesOrder.CompanyCodeCustomerCodeComputerizedPartNumber
,	SalesOrder.LineItemNumber
,	SalesOrder.DeliveryNumber
,	SalesOrder.FiscalPeriodCode
,	SalesOrder.FirstShippingDate
FROM	DataWarehouse..SalesOrder_2008_New SalesOrder























