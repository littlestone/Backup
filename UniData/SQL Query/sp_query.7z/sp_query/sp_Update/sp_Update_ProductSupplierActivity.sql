ALTER PROCEDURE dbo.sp_Update_ProductSupplierActivity AS
UPDATE	DataWarehouse..ProductSupplierActivity
SET	ComputerizedPartNumber = ISNULL(ITMSUPPACT.CPN, '')
,	CompanyCode = ISNULL(ITMSUPPACT.COMPANY, '')
,	SupplierCode = ISNULL(ITMSUPPACT.VENDOR, '')
FROM	Source..ITMSUPPACT ITMSUPPACT
	INNER JOIN DataWarehouse..ProductSupplierActivity ProductSupplierActivity
		ON ISNULL(ITMSUPPACT.CPN, '') = ProductSupplierActivity.ComputerizedPartNumber
		AND ISNULL(ITMSUPPACT.COMPANY, '') = ProductSupplierActivity.CompanyCode
		AND ISNULL(ITMSUPPACT.VENDOR, '') = ProductSupplierActivity.SupplierCode
WHERE	ProductSupplierActivity.ComputerizedPartNumber != ISNULL(ITMSUPPACT.CPN, '')
OR	ProductSupplierActivity.CompanyCode != ISNULL(ITMSUPPACT.COMPANY, '')
OR	ProductSupplierActivity.SupplierCode != ISNULL(ITMSUPPACT.VENDOR, '')


GO
