

ALTER   PROCEDURE dbo.sp_Update_Division_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..Division
SET	Active = 0
WHERE	NULLIF(DivisionCode, '') IS NOT NULL

SELECT	Company.CompanyCode
,	Division.DivisionCode
INTO	#Division
FROM	DataWarehouse..Company Company
,	DataWarehouse..Division Division
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryWarehouse_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Division' + ' ' +
					'	(CompanyCode' + ' ' +
					',	DivisionCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	Warehouse.CompanyCode' + ' ' +
					',	Warehouse.DivisionCode' + ' ' +
					'FROM	DataWarehouse..InventoryWarehouse_' + @strYear + ' InventoryWarehouse' + ' ' +
					'	INNER JOIN DataWarehouse..Warehouse Warehouse' + ' ' +
					'		ON InventoryWarehouse.WarehouseCode = Warehouse.WarehouseCode' + ' ' +
					'WHERE	InventoryWarehouse.BookedQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.OnHandQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.InMaterialReviewBoardQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.InReceiptInInspectionQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.InTransitQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.ManufacturingAllocationQuantity != 0' + ' ' +
					'OR	InventoryWarehouse.AllocationQuantity != 0'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'BillOfLading_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Division' + ' ' +
					'	(CompanyCode' + ' ' +
					',	DivisionCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	BillOfLading.ReceivingCompanyCode' + ' ' +
					',	BillOfLading.ReceivingDivisionCode' + ' ' +
					'FROM	DataWarehouse..BillOfLading_' + @strYear + ' BillOfLading'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Invoice_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Division' + ' ' +
					'	(CompanyCode' + ' ' +
					',	DivisionCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	Invoice.CompanyCode' + ' ' +
					',	Invoice.DivisionCode' + ' ' +
					'FROM	DataWarehouse..Invoice_' + @strYear + ' Invoice'
		EXEC	(@strSQL)
	END
	
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Production_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Division' + ' ' +
					'	(CompanyCode' + ' ' +
					',	DivisionCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	Production.CompanyCode' + ' ' +
					',	Production.DivisionCode' + ' ' +
					'FROM	DataWarehouse..Production_' + @strYear + ' Production'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'Budget_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Division' + ' ' +
					'	(CompanyCode' + ' ' +
					',	DivisionCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	Budget.CompanyCode' + ' ' +
					',	Budget.DivisionCode' + ' ' +
					'FROM	DataWarehouse..Budget_' + @strYear + ' Budget'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'SalesOrder_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Division' + ' ' +
					'	(CompanyCode' + ' ' +
					',	DivisionCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	SalesOrder.CompanyCode' + ' ' +
					',	SalesOrder.DivisionCode' + ' ' +
					'FROM	DataWarehouse..SalesOrder_' + @strYear + ' SalesOrder' + ' ' +
					'WHERE	SalesOrder.LineItemStatusCode != ''C'''
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderHeader_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#Division' + ' ' +
					'	(CompanyCode' + ' ' +
					',	DivisionCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	PurchaseOrderHeader.CompanyCode' + ' ' +
					',	PurchaseOrderHeader.DivisionCode' + ' ' +
					'FROM	DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' + 
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' PurchaseOrderHeaderLineItem' + ' ' +
					'		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X''' 
		EXEC	(@strSQL)
	END


	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

INSERT	#Division
	(CompanyCode
,	DivisionCode)
SELECT DISTINCT	Warehouse.CompanyCode
,	Warehouse.DivisionCode
FROM	DataWarehouse..Warehouse Warehouse
WHERE	Warehouse.Active = 1

UPDATE	DataWarehouse..Division
SET	Active = 1
FROM	DataWarehouse..Division Division
	INNER JOIN #Division
		ON Division.CompanyCode = #Division.CompanyCode
		AND Division.DivisionCode = #Division.DivisionCode



GO
