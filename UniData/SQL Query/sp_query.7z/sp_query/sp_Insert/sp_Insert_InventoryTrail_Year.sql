ALTER  PROCEDURE dbo.sp_Insert_InventoryTrail_Year
(	@strYear	varchar(4))
WITH RECOMPILE
AS

DECLARE	@strSQL	varchar(8000)

IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryTrail_' + @strYear)
BEGIN
	SELECT	@strSQL =	'INSERT	DataWarehouse..InventoryTrail_' + @strYear + ' ' +
				'	(ComputerizedPartNumber' + ' ' +
				',	SequenceNumber' + ' ' +
				',	GeneralLedgerGroupCode' + ' ' +
				',	TransactionQuantity' + ' ' +
				',	UnitOfMeasureCode' + ' ' +
				',	InventoryAmount' + ' ' +
				',	ReceiptAmount' + ' ' +
				',	ReferenceNumber' + ' ' +
				',	WarehouseCode' + ' ' +
				',	OnHandQuantity' + ' ' +
				',	AdjustmentReasonCode' + ' ' +
				',	InventoryTransactionTypeCode' + ' ' +
				',	InventorySubTransactionTypeCode' + ' ' +
				',	InventoryTransactionTypeCodeInventorySubTransactionTypeCode' + ' ' +
				',	UserCode' + ' ' +
				',	TransactionDateTime' + ' ' +
				',	EntryDate' + ' ' +
				',	SalesPostingCode' + ' ' +
				',	RegisterTypeCode' + ' ' +
				',	RegisterNumber' + ' ' +
				',	FiscalPeriodCode' + ' ' +
				',	CompanyCode' + ' ' +
				',	CustomerCode' + ' ' +
				',	SupplierCode' + ' ' +
				',	TransferWarehouseCode' + ' ' +
				',	AdjustmentReasonComment)' + ' ' +
				'SELECT	INVTRAIL.CPN' + ' ' +
				',	INVTRAIL.DF_SEQ' + ' ' +
				',	ISNULL(INVTRAIL.GLG_CODE, '''')' + ' ' +
				',	CASE' + ' ' +
				'		WHEN INVTRAIL.CHG_QTY IS NULL THEN CONVERT(numeric(19, 4), 0)' + ' ' +
				'		WHEN INVTRAIL.CHG_QTY LIKE ''[+-]'' THEN CONVERT(numeric(19, 4), 0)' + ' ' +
				'		ELSE CONVERT(numeric(19, 4), INVTRAIL.CHG_QTY)' + ' ' +
				'		END' + ' ' +
				',	ISNULL(INVTRAIL.UM, '''')' + ' ' +
				',	ISNULL(INVTRAIL.INVT_DLRS, 0)' + ' ' +
				',	ISNULL(INVTRAIL.RECPT_DLRS, 0)' + ' ' +
				',	ISNULL(INVTRAIL.REFERENCE, '''')' + ' ' +
				',	ISNULL(RIGHT(INVTRAIL.WHS, LEN(INVTRAIL.WHS) - CHARINDEX(''.'', INVTRAIL.WHS)), '''')' + ' ' +
				',	ISNULL(LEFT(INVTRAIL.PREV_QOH + ''�'', CHARINDEX(''�'', INVTRAIL.PREV_QOH + ''�'') - 1), 0)' + ' ' +
				',	ISNULL(INVTRAIL.ADJ_RSN_CD, '''')' + ' ' +
				',	ISNULL(INVTRAIL.TRAN_CD, '''')' + ' ' +
				',	ISNULL(INVTRAIL.SUB_TRAN_CD, '''')' + ' ' +
				',	ISNULL(INVTRAIL.TRAN_CD, '''')' + '*' + 'ISNULL(INVTRAIL.SUB_TRAN_CD, '''')' + ' ' +
				',	ISNULL(INVTRAIL.USER_ID, '''')' + ' ' +
				',	ISNULL(LEFT(CONVERT(varchar(100), ISNULL(INVTRAIL.TRANS_DATE, INVTRAIL.ENTRY_DT), 120), CHARINDEX('' '', CONVERT(varchar(100), ISNULL(INVTRAIL.TRANS_DATE, INVTRAIL.ENTRY_DT), 120)) - 1), ''1900-01-01'') + '' '' + ISNULL(RIGHT(CONVERT(varchar(100), INVTRAIL.TRANS_TIME, 120), LEN(CONVERT(varchar(100), INVTRAIL.TRANS_TIME, 120)) - CHARINDEX('' '', CONVERT(varchar(100), INVTRAIL.TRANS_TIME, 120))), ''00:00:00'')' + ' ' +
				',	ISNULL(INVTRAIL.ENTRY_DT, ''1900-01-01'')' + ' ' +
				',	ISNULL(INVTRAIL.SPC_CODE, '''')' + ' ' +
				',	CASE' + ' ' +
				'		WHEN INVTRAIL.REGISTER_NAME IS NOT NULL THEN INVTRAIL.REGISTER_NAME' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''40'' THEN ''MTLREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''41'' THEN ''RCVGREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''42'' THEN ''INVAJREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''44'' THEN ''MTLREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''49'' THEN ''ICEREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''50'' THEN ''INVAJREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''52'' THEN ''INVAJREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''60'' THEN ''RTRNREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''97'' THEN ''WTRREG''' + ' ' +
				'		WHEN INVTRAIL.TRAN_CD = ''98'' THEN ''WTRREG''' + ' ' +
				'		ELSE ''''' + ' ' +
				'		END' + ' ' +
				',	ISNULL(INVTRAIL.REGISTER_KEY, '''')' + ' ' +
				',	ISNULL(INVTRAIL.FISCAL_PERIOD, '''')' + ' ' +
				',	''''' + ' ' +
				',	''''' + ' ' +
				',	''''' + ' ' +
				',	''''' + ' ' +
				',	ISNULL(LEFT(INVTRAIL.ADJ_REASON_COMMENTS, 200), '''')' + ' ' +
				'FROM	Source..INVTRAIL INVTRAIL' + ' ' +
				'	LEFT JOIN DataWarehouse..InventoryTrail_' + @strYear + ' InventoryTrail' + ' ' +
				'		ON INVTRAIL.CPN = InventoryTrail.ComputerizedPartNumber' + ' ' +
				'		AND INVTRAIL.DF_SEQ = InventoryTrail.SequenceNumber' + ' ' +
				'WHERE	INVTRAIL.FISCAL_PERIOD LIKE ''' + @strYear + '%''' + ' ' +
				'AND	InventoryTrail.ComputerizedPartNumber IS NULL' + ' ' +
				'AND	InventoryTrail.SequenceNumber IS NULL'
	
	EXEC	(@strSQL)
END


GO
