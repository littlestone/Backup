ALTER   PROCEDURE sp_Update_PurchaseOrderDetail_PurchaseOrderReceipt
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderDetail_' + @strYear)
		EXEC	sp_Update_PurchaseOrderDetail_PurchaseOrderReceipt_Year @strYear

	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear
GO
