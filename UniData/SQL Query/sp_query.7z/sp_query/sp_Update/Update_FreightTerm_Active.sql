
ALTER PROCEDURE dbo.sp_Update_FreightTerm_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..FreightTerm
SET	Active = 0
WHERE	NULLIF(FreightTermCode, '') IS NOT NULL

SELECT	FreightTerm.FreightTermCode
INTO	#FreightTerm
FROM	DataWarehouse..FreightTerm FreightTerm
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'BillOfLading_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FreightTerm' + ' ' +
					'	(FreightTermCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	BillOfLading.FreightTermCode' + ' ' +
					'FROM	DataWarehouse..BillOfLading_' + @strYear + ' BillOfLading'
		EXEC	(@strSQL)
	END

	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'PurchaseOrderHeader_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#FreightTerm' + ' ' +
					'	(FreightTermCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	PurchaseOrderHeader.FreightTermCode' + ' ' +
					'FROM	DataWarehouse..PurchaseOrderHeader_' + @strYear + ' PurchaseOrderHeader' + ' ' + 
					'	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_' + @strYear + ' PurchaseOrderHeaderLineItem' + ' ' +
					'		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber' + ' ' +
					'WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != ''X'''
		EXEC	(@strSQL)
	END	


	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..FreightTerm
SET	Active = 1
FROM	DataWarehouse..FreightTerm FreightTerm
	INNER JOIN #FreightTerm
		ON FreightTerm.FreightTermCode = #FreightTerm.FreightTermCode

DROP	TABLE #FreightTerm
GO
