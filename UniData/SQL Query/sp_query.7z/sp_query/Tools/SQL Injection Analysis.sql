SELECT PressTitle
,	PressID
,	SUBSTRING(PressText, 1, 128)
,	SUBSTRING(PressText, 256, 128)
,	SUBSTRING(PressText, 384, 128)
,	SUBSTRING(PressText, 512, 128)
,	SUBSTRING(PressText, 640, 128)
,	SUBSTRING(PressText, 768, 128)
,	SUBSTRING(PressText, 896, 128)
,	SUBSTRING(PressText, 1024, 128)
,	SUBSTRING(PressText, 1152, 128)
,	SUBSTRING(PressText, 1280, 128)
,	SUBSTRING(PressText, 1408, 128)
,	SUBSTRING(PressText, 1536, 128)
,	SUBSTRING(PressText, 1664, 128)
,	SUBSTRING(PressText, 1792, 128)
,	SUBSTRING(PressText, 1920, 128)
,	SUBSTRING(PressText, 2048, 128)
,	SUBSTRING(PressText, 2176, 128)
,	SUBSTRING(PressText, 2304, 128)
,	SUBSTRING(PressText, 2432, 128)
,	SUBSTRING(PressText, 2560, 128)
,	SUBSTRING(PressText, 2688, 128)
FROM PressReleases
WHERE PressText LIKE '%<script%'

SELECT NewsTitle
,	SUBSTRING(NewsText, 1, 128)
,	SUBSTRING(NewsText, 256, 128)
,	SUBSTRING(NewsText, 384, 128)
,	SUBSTRING(NewsText, 512, 128)
,	SUBSTRING(NewsText, 640, 128)
,	SUBSTRING(NewsText, 768, 128)
,	SUBSTRING(NewsText, 896, 128)
,	SUBSTRING(NewsText, 1024, 128)
,	SUBSTRING(NewsText, 1152, 128)
,	SUBSTRING(NewsText, 1280, 128)
,	SUBSTRING(NewsText, 1408, 128)
FROM News
WHERE NewsText LIKE '%<script%'

SELECT NewsTitle
,	SUBSTRING(NewsText, 1, 128)
,	SUBSTRING(NewsText, 256, 128)
,	SUBSTRING(NewsText, 384, 128)
,	SUBSTRING(NewsText, 512, 128)
,	SUBSTRING(NewsText, 640, 128)
,	SUBSTRING(NewsText, 768, 128)
,	SUBSTRING(NewsText, 896, 128)
,	SUBSTRING(NewsText, 1024, 128)
,	SUBSTRING(NewsText, 1152, 128)
,	SUBSTRING(NewsText, 1280, 128)
,	SUBSTRING(NewsText, 1408, 128)
,	SUBSTRING(NewsText, 1536, 128)
,	SUBSTRING(NewsText, 1664, 128)
,	SUBSTRING(NewsText, 1792, 128)
,	SUBSTRING(NewsText, 1920, 128)
FROM NewsProduct
WHERE NewsText LIKE '%<script%'

SELECT EventTitle
,	SUBSTRING(EventText, 1, 128)
,	SUBSTRING(EventText, 256, 128)
,	SUBSTRING(EventText, 384, 128)
,	SUBSTRING(EventText, 512, 128)
,	SUBSTRING(EventText, 640, 128)
,	SUBSTRING(EventText, 768, 128)
,	SUBSTRING(EventText, 896, 128)
,	SUBSTRING(EventText, 1024, 128)
FROM Events
WHERE EventText LIKE '%<script%'



SELECT CaseTitle
,	SUBSTRING(CaseText, 1, 128)
,	SUBSTRING(CaseText, 256, 128)
,	SUBSTRING(CaseText, 384, 128)
,	SUBSTRING(CaseText, 512, 128)
,	SUBSTRING(CaseText, 640, 128)
,	SUBSTRING(CaseText, 768, 128)
,	SUBSTRING(CaseText, 896, 128)
,	SUBSTRING(CaseText, 1024, 128)
,	SUBSTRING(CaseText, 1152, 128)
,	SUBSTRING(CaseText, 1280, 128)
,	SUBSTRING(CaseText, 1408, 128)
,	SUBSTRING(CaseText, 1536, 128)
,	SUBSTRING(CaseText, 1664, 128)
,	SUBSTRING(CaseText, 1792, 128)
,	SUBSTRING(CaseText, 1920, 128)
,	SUBSTRING(CaseText, 2048, 128)
,	SUBSTRING(CaseText, 2176, 128)
,	SUBSTRING(CaseText, 2304, 128)
,	SUBSTRING(CaseText, 2432, 128)
,	SUBSTRING(CaseText, 2560, 128)
,	SUBSTRING(CaseText, 2688, 128)
,	SUBSTRING(CaseText, 2816, 128)
,	SUBSTRING(CaseText, 2944, 128)
,	SUBSTRING(CaseText, 3072, 128)
,	SUBSTRING(CaseText, 3200, 128)
,	SUBSTRING(CaseText, 3328, 128)
,	SUBSTRING(CaseText, 3456, 128)
,	SUBSTRING(CaseText, 3584, 128)
,	SUBSTRING(CaseText, 3712, 128)
,	SUBSTRING(CaseText, 3840, 128)
,	SUBSTRING(CaseText, 3968, 128)
,	SUBSTRING(CaseText, 4096, 128)
,	SUBSTRING(CaseText, 4224, 128)
,	SUBSTRING(CaseText, 4352, 128)
,	SUBSTRING(CaseText, 4480, 128)
,	SUBSTRING(CaseText, 4608, 128)
FROM CaseStudies
WHERE CaseText LIKE '%<script%'


SELECT SalesRepID
,	SUBSTRING(SalesRepProducts, 1, 128)
,	SUBSTRING(SalesRepProducts, 256, 128)
,	SUBSTRING(SalesRepProducts, 384, 128)
,	SUBSTRING(SalesRepProducts, 512, 128)
,	SUBSTRING(SalesRepProducts, 640, 128)
,	SUBSTRING(SalesRepProducts, 768, 128)
,	SUBSTRING(SalesRepProducts, 896, 128)
,	SUBSTRING(SalesRepProducts, 1024, 128)
,	SUBSTRING(SalesRepProducts, 1152, 128)
,	SUBSTRING(SalesRepProducts, 1280, 128)
,	SUBSTRING(SalesRepProducts, 1408, 128)
,	SUBSTRING(SalesRepProducts, 1536, 128)
,	SUBSTRING(SalesRepProducts, 1664, 128)
,	SUBSTRING(SalesRepProducts, 1792, 128)
,	SUBSTRING(SalesRepProducts, 1920, 128)
,	SUBSTRING(SalesRepProducts, 2048, 128)
,	SUBSTRING(SalesRepProducts, 2176, 128)
,	SUBSTRING(SalesRepProducts, 2304, 128)
,	SUBSTRING(SalesRepProducts, 2432, 128)
,	SUBSTRING(SalesRepProducts, 2560, 128)
,	SUBSTRING(SalesRepProducts, 2688, 128)
FROM SalesRep
WHERE SalesRepProducts LIKE '%<script%'

SELECT WebSiteModuleID
,	SUBSTRING(WebSiteModuleDesc, 1, 128)
,	SUBSTRING(WebSiteModuleDesc, 256, 128)
,	SUBSTRING(WebSiteModuleDesc, 384, 128)
,	SUBSTRING(WebSiteModuleDesc, 512, 128)
,	SUBSTRING(WebSiteModuleDesc, 640, 128)
,	SUBSTRING(WebSiteModuleDesc, 768, 128)
,	SUBSTRING(WebSiteModuleDesc, 896, 128)
,	SUBSTRING(WebSiteModuleDesc, 1024, 128)
,	SUBSTRING(WebSiteModuleDesc, 1152, 128)
,	SUBSTRING(WebSiteModuleDesc, 1280, 128)
,	SUBSTRING(WebSiteModuleDesc, 1408, 128)
,	SUBSTRING(WebSiteModuleDesc, 1536, 128)
,	SUBSTRING(WebSiteModuleDesc, 1664, 128)
,	SUBSTRING(WebSiteModuleDesc, 1792, 128)
,	SUBSTRING(WebSiteModuleDesc, 1920, 128)
,	SUBSTRING(WebSiteModuleDesc, 2048, 128)
,	SUBSTRING(WebSiteModuleDesc, 2176, 128)
,	SUBSTRING(WebSiteModuleDesc, 2304, 128)
,	SUBSTRING(WebSiteModuleDesc, 2432, 128)
,	SUBSTRING(WebSiteModuleDesc, 2560, 128)
,	SUBSTRING(WebSiteModuleDesc, 2688, 128)
FROM WebSiteModulesDetails
WHERE WebSiteModuleDesc LIKE '%<script%'


SELECT *
INTO PressReleases_Backup
FROM PressReleases


UPDATE PressReleases_Backup
SET PressText = LEFT(PressText, CHARINDEX('<', PressText) - 1)
WHERE PressID = '1'

SELECT PATINDEX('%<script%', PressText)
FROM PressReleases
WHERE PATINDEX('%<script%', PressText) <> '0'

SELECT PATINDEX('%<script%', NewsText)
FROM News
WHERE PATINDEX('%<script%', NewsText) <> '0'

SELECT PATINDEX('%<script%', Newstext)
FROM NewsProduct
WHERE PATINDEX('%<script%', NewsText) <> '0'

SELECT PATINDEX('%<script%', EventText)
FROM Events
WHERE PATINDEX('%<script%', EventText) <> '0'
