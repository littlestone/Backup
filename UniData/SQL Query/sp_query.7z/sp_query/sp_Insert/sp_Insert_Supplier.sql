ALTER PROCEDURE dbo.sp_Insert_Supplier AS
INSERT	DataWarehouse..Supplier
	(CompanyCode
,	SupplierCode
,	SupplierFirstName
,	SupplierLastName
,	AddressLine1
,	AddressLine2
,	CityCode
,	StateProvinceCode
,	ZipPostalCode
,	AddressLine3
,	CountryCode
,	SupplierTypeCode
,	CompanyCodeSupplierCode
,	Active
,	ContactName
,	CountryCodeStateProvinceCode
,	CountryCodeStateProvinceCodeCityCode
,	PurchasingAddressLine1
,	PurchasingAddressLine2
,	PurchasingCityCode
,	PurchasingStateProvinceCode
,	PurchasingZipPostalCode
,	PurchasingContactName
,	PurchasingAddressLine3
,	PurchasingCountryCode
,	PurchasingCountryCodeStateProvinceCodeCityCode)
SELECT	SUPPMST.COMPANY
,	SUPPMST.VENDOR
,	ISNULL(SUPPMST.BACK_NAME, '')
,	ISNULL(SUPPMST.FRONT_NAME, '')
,	ISNULL(SUPPMST.ADDRESS1, '')
,	ISNULL(SUPPMST.ADDRESS2, '')
,	ISNULL(SUPPMST.CITY, '')
,	ISNULL(SUPPMST.STATE, '')
,	ISNULL(SUPPMST.POSTAL_CODE, '')
,	ISNULL(SUPPMST.ADDRESS3, '')
,	ISNULL(SUPPMST.COUNTRY, '')
,	ISNULL(SUPPMST.VN_TYPE, '')
,	SUPPMST.COMPANY + '*' + SUPPMST.VENDOR
,	0
,	ISNULL(SUPPMST.CONTACT, '')
,	ISNULL(SUPPMST.COUNTRY, '') + ISNULL(SUPPMST.STATE, '')
,	ISNULL(SUPPMST.COUNTRY, '') + '*' + ISNULL(SUPPMST.STATE, '') + '*' + ISNULL(SUPPMST.CITY, '')
,	ISNULL(SUPPMST.P_ADDRESS1, '')
,	ISNULL(SUPPMST.P_ADDRESS2, '')
,	ISNULL(SUPPMST.P_CITY, '')
,	ISNULL(SUPPMST.P_STATE, '')
,	ISNULL(SUPPMST.P_POSTAL_CD, '')
,	ISNULL(SUPPMST.P_CONTACT, '')
,	ISNULL(SUPPMST.P_ADDRESS3, '')
,	ISNULL(SUPPMST.P_COUNTRY, '')
,	ISNULL(SUPPMST.P_COUNTRY, '') + '*' + ISNULL(SUPPMST.P_STATE, '') + '*' + ISNULL(SUPPMST.P_CITY, '')
FROM	Source..SUPPMST SUPPMST
	LEFT JOIN DataWarehouse..Supplier Supplier
		ON SUPPMST.COMPANY = Supplier.CompanyCode
		AND SUPPMST.VENDOR = Supplier.SupplierCode
WHERE	Supplier.CompanyCode IS NULL
AND	Supplier.SupplierCode IS NULL

GO
