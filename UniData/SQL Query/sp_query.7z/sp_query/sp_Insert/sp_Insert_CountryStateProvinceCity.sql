ALTER PROCEDURE dbo.sp_Insert_CountryStateProvinceCity AS

INSERT	DataWarehouse..CountryStateProvinceCity
	(CountryCode
,	StateProvinceCode
,	CityCode
,	CountryCodeStateProvinceCode
,	CountryCodeStateProvinceCodeCityCode
,	Active)
SELECT	DISTINCT ISNULL(CUSTMST.COUNTRY, '')
,	ISNULL(CUSTMST.STATE, '')
,	ISNULL(CUSTMST.CITY, '')
,	ISNULL(CUSTMST.COUNTRY, '') + '*' + ISNULL(CUSTMST.STATE, '')
,	ISNULL(CUSTMST.COUNTRY, '') + '*' + ISNULL(CUSTMST.STATE, '') + '*' + ISNULL(CUSTMST.CITY, '')
,	0
FROM	Source..CUSTMST CUSTMST
	LEFT JOIN DataWarehouse..CountryStateProvinceCity CountryStateProvinceCity
		ON ISNULL(CUSTMST.COUNTRY, '') = CountryStateProvinceCity.CountryCode
		AND ISNULL(CUSTMST.STATE, '') = CountryStateProvinceCity.StateProvinceCode
		AND ISNULL(CUSTMST.CITY, '') = CountryStateProvinceCity.CityCode
WHERE	CountryStateProvinceCity.CountryCode IS NULL
AND	CountryStateProvinceCity.StateProvinceCode IS NULL
AND	CountryStateProvinceCity.CityCode IS NULL

INSERT	DataWarehouse..CountryStateProvinceCity
	(CountryCode
,	StateProvinceCode
,	CityCode
,	CountryCodeStateProvinceCode
,	CountryCodeStateProvinceCodeCityCode
,	Active)
SELECT	DISTINCT ISNULL(WHSMST.COUNTRY_CODE, '')
,	ISNULL(WHSMST.STATE, '')
,	ISNULL(WHSMST.CITY, '')
,	ISNULL(WHSMST.COUNTRY_CODE, '') + '*' + ISNULL(WHSMST.STATE, '')
,	ISNULL(WHSMST.COUNTRY_CODE, '') + '*' + ISNULL(WHSMST.STATE, '') + '*' + ISNULL(WHSMST.CITY, '')
,	0
FROM	Source..WHSMST WHSMST
	LEFT JOIN DataWarehouse..CountryStateProvinceCity CountryStateProvinceCity
		ON ISNULL(WHSMST.COUNTRY_CODE, '') = CountryStateProvinceCity.CountryCode
		AND ISNULL(WHSMST.STATE, '') = CountryStateProvinceCity.StateProvinceCode
		AND ISNULL(WHSMST.CITY, '') = CountryStateProvinceCity.CityCode
WHERE	CountryStateProvinceCity.CountryCode IS NULL
AND	CountryStateProvinceCity.StateProvinceCode IS NULL
AND	CountryStateProvinceCity.CityCode IS NULL

INSERT	DataWarehouse..CountryStateProvinceCity
	(CountryCode
,	StateProvinceCode
,	CityCode
,	CountryCodeStateProvinceCode
,	CountryCodeStateProvinceCodeCityCode
,	Active)
SELECT	DISTINCT ISNULL(SUPPMST.COUNTRY, '')
,	ISNULL(SUPPMST.STATE, '')
,	ISNULL(SUPPMST.CITY, '')
,	ISNULL(SUPPMST.COUNTRY, '') + '*' + ISNULL(SUPPMST.STATE, '')
,	ISNULL(SUPPMST.COUNTRY, '') + '*' + ISNULL(SUPPMST.STATE, '') + '*' + ISNULL(SUPPMST.CITY, '')
,	0
FROM	Source..SUPPMST SUPPMST
	LEFT JOIN DataWarehouse..CountryStateProvinceCity CountryStateProvinceCity
		ON ISNULL(SUPPMST.COUNTRY, '') = CountryStateProvinceCity.CountryCode
		AND ISNULL(SUPPMST.STATE, '') = CountryStateProvinceCity.StateProvinceCode
		AND ISNULL(SUPPMST.CITY, '') = CountryStateProvinceCity.CityCode
WHERE	CountryStateProvinceCity.CountryCode IS NULL
AND	CountryStateProvinceCity.StateProvinceCode IS NULL
AND	CountryStateProvinceCity.CityCode IS NULL


-- Insert more CountryStateProvinceCitys based on supplier's information
INSERT	DataWarehouse..CountryStateProvinceCity
	(CountryCode
,	StateProvinceCode
,	CityCode
,	CountryCodeStateProvinceCode
,	CountryCodeStateProvinceCodeCityCode
,	Active)
SELECT	DISTINCT ISNULL(SUPPMST.P_COUNTRY, '')
,	ISNULL(SUPPMST.P_STATE, '')
,	ISNULL(SUPPMST.P_CITY, '')
,	ISNULL(SUPPMST.P_COUNTRY, '') + '*' + ISNULL(SUPPMST.P_STATE, '')
,	ISNULL(SUPPMST.P_COUNTRY, '') + '*' + ISNULL(SUPPMST.P_STATE, '') + '*' + ISNULL(SUPPMST.P_CITY, '')
,	0
FROM	Source..SUPPMST SUPPMST
	LEFT JOIN DataWarehouse..CountryStateProvinceCity CountryStateProvinceCity
		ON ISNULL(SUPPMST.P_COUNTRY, '') = CountryStateProvinceCity.CountryCode
		AND ISNULL(SUPPMST.P_STATE, '') = CountryStateProvinceCity.StateProvinceCode
		AND ISNULL(SUPPMST.P_CITY, '') = CountryStateProvinceCity.CityCode
WHERE	CountryStateProvinceCity.CountryCode IS NULL
AND	CountryStateProvinceCity.StateProvinceCode IS NULL
AND	CountryStateProvinceCity.CityCode IS NULL
GO
