

ALTER PROCEDURE dbo.sp_Update_InventorySubTransactionType_Active
WITH RECOMPILE
AS

DECLARE	@strYear	varchar(4)
,	@strSQL		varchar(8000)

UPDATE	DataWarehouse..InventorySubTransactionType
SET	Active = 0
WHERE	NULLIF(InventoryTransactionTypeCode, '') IS NOT NULL

SELECT	InventorySubTransactionType.InventoryTransactionTypeCode
INTO	#InventorySubTransactionType
FROM	DataWarehouse..InventorySubTransactionType InventorySubTransactionType
WHERE	0 = 1

DECLARE	curYear
CURSOR	FOR
SELECT	DISTINCT FiscalYear
FROM	DataWarehouse..FiscalTime
ORDER	BY FiscalYear

OPEN	curYear

FETCH	NEXT
FROM	curYear
INTO	@strYear

WHILE	@@FETCH_STATUS = 0
BEGIN
	IF EXISTS (SELECT * FROM DataWarehouse..sysobjects WHERE name = 'InventoryTrail_' + @strYear)
	BEGIN
		SELECT	@strSQL =	'INSERT	#InventorySubTransactionType' + ' ' +
					'	(InventoryTransactionTypeCode)' + ' ' +
					'SELECT	DISTINCT' + ' ' +
					'	InventoryTrail.InventoryTransactionTypeCode' + ' ' +
					'FROM	DataWarehouse..InventoryTrail_' + @strYear + ' InventoryTrail'
		EXEC	(@strSQL)
	END

	FETCH	NEXT
	FROM	curYear
	INTO	@strYear
END

CLOSE	curYear

DEALLOCATE curYear

UPDATE	DataWarehouse..InventorySubTransactionType
SET	Active = 1
FROM	DataWarehouse..InventorySubTransactionType InventorySubTransactionType
	INNER JOIN #InventorySubTransactionType
		ON InventorySubTransactionType.InventoryTransactionTypeCode = #InventorySubTransactionType.InventoryTransactionTypeCode

DROP	TABLE #InventorySubTransactionType


GO
