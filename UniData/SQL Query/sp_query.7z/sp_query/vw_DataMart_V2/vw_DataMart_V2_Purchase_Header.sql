ALTER  VIEW vw_DataMart_V2_Purchase_Header
AS
SELECT 	PurchaseOrderHeader.PurchaseOrderNumber
,	PurchaseOrderHeader.BuyerCode
,	PurchaseOrderHeader.FreightCarrierCode
,	PurchaseOrderHeader.FreightOnBoardCode
,	PurchaseOrderHeader.WarehouseCode
,	PurchaseOrderHeader.PurchaseOrderClassCode
,	PurchaseOrderHeader.FreightTermCode
,	PurchaseOrderHeader.FiscalPeriodCode
,	PurchaseOrderHeader.OrderStatusCode
,	PurchaseOrderHeader.CompanyCodeSupplierCode
,	PurchaseOrderHeader.CompanyCodeDivisionCode
,	PurchaseOrderHeader.PurchasePayTermCode
,	PurchaseOrderHeaderLineItem.LineItemStatusCode
,	PurchaseOrderDetail.ComputerizedPartNumber
,	PurchaseOrderDetail.ProductCode
,	PurchaseOrderDetail.GeneralLedgerAccountCode
,	PurchaseOrderDetail.WorkOrderNumber
,	PurchaseOrderDetail.ChargeTypeCode
	/* 
	    Algorithm to convert the PurchaseOrderNumber into numeric type which can only hold 15 digits 
	    Step 1. For each character of the PurchaseOrderNumber, If it is an empty string assign a value as 0, Else goto Step 2 
	    Step 2. Get the ASCII value of the character and convert it into numeric type, we call this value as V1 
	    Step 3. For each V1, we do a bitwised shift left operation with a step of 4, we call this value after SHL operation V2 
	    Step 3. IF V2 is larget than 2.0^49(since 2.0^50 is larger than 15 digits), then we do V2 Modulo 2^49, then goto Step 4 
	    Step 4. goto Step 2 and start from 2.0^4 and so on 
	*/
,	(CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 1, 1), '')), 0)) +		-- POWER(2.0, 0) = 1.0
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 2, 1), '')), 0)) * POWER(2.0, 4) +
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 3, 1), '')), 0)) * POWER(2.0, 8) +
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 4, 1), '')), 0)) * POWER(2.0, 12) +
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 5, 1), '')), 0)) *	POWER(2.0, 16) +			
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 6, 1), '')), 0)) * POWER(2.0, 20) +
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 7, 1), '')), 0)) * POWER(2.0, 24) +
 	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 8, 1), '')), 0)) * POWER(2.0, 28) +			
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 9, 1), '')), 0)) *	POWER(2.0, 32) + 				  		
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 10, 1), '')), 0)) * POWER(2.0, 36) + 
 	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 11, 1), '')), 0)) * POWER(2.0, 40) + 
 	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 12, 1), '')), 0)) * POWER(2.0, 44) + 
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 13, 1), '')), 0)) * POWER(2.0, 48) + 			
 	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 14, 1), '')), 0)) * 8 +	-- POWER(2.0, 52) MOD POWER(2.0, 49) = 3, POWER(2.0, 3) = 8 
 	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 15, 1), '')), 0)) * POWER(2.0, 4) + 				
 	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 16, 1), '')), 0)) * POWER(2.0, 8) +
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.PurchaseOrderNumber, 17, 1), '')), 0)) * POWER(2.0, 12)) +
	(CONVERT(numeric(38, 0), ASCII('*')) +	-- Concatenate with FiscalPeriodCode to make it pure unique since some PO_NBRs are not consistent in Source tables
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.FiscalPeriodCode, 1, 1), '')), 0)) +
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.FiscalPeriodCode, 2, 1), '')), 0)) + 
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.FiscalPeriodCode, 3, 1), '')), 0)) +
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.FiscalPeriodCode, 4, 1), '')), 0)) +
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.FiscalPeriodCode, 5, 1), '')), 0)) + 
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.FiscalPeriodCode, 6, 1), '')), 0)) + 
	CONVERT(numeric(38, 0), ISNULL(ASCII(NULLIF(SUBSTRING(PurchaseOrderHeader.FiscalPeriodCode, 7, 1), '')), 0))) AS OrderCount 
FROM	DataWarehouse..PurchaseOrderHeader_2001 PurchaseOrderHeader
	INNER JOIN DataWarehouse..PurchaseOrderHeaderLineItem_2001 PurchaseOrderHeaderLineItem
		ON PurchaseOrderHeader.PurchaseOrderNumber = PurchaseOrderHeaderLineItem.PurchaseOrderNumber
	INNER JOIN DataWarehouse..PurchaseOrderDetail_2001 PurchaseOrderDetail
		ON PurchaseOrderHeaderLineItem.PurchaseOrderNumber = PurchaseOrderDetail.PurchaseOrderNumber
		AND PurchaseOrderHeaderLineItem.ReferenceNumber = PurchaseOrderDetail.ReferenceNumber
WHERE	PurchaseOrderHeaderLineItem.LineItemStatusCode != 'X'
AND	0 = 1




















