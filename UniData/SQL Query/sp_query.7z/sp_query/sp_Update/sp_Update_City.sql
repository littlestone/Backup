ALTER PROCEDURE dbo.sp_Update_City AS

UPDATE	DataWarehouse..City
SET	CityName = ISNULL(CUSTMST.CITY, '')
FROM	Source..CUSTMST CUSTMST
	INNER JOIN DataWarehouse..City City
		ON CUSTMST.CITY = City.CityCode
WHERE	City.CityName != ISNULL(CUSTMST.CITY, '')

UPDATE	DataWarehouse..City
SET	CityName = ISNULL(WHSMST.CITY, '')
FROM	Source..WHSMST WHSMST
	INNER JOIN DataWarehouse..City City
		ON WHSMST.CITY = City.CityCode
WHERE	City.CityName != ISNULL(WHSMST.CITY, '')

UPDATE	DataWarehouse..City
SET	CityName = ISNULL(SUPPMST.CITY, '')
FROM	Source..SUPPMST SUPPMST
	INNER JOIN DataWarehouse..City City
		ON SUPPMST.CITY = City.CityCode
WHERE	City.CityName != ISNULL(SUPPMST.CITY, '')

-- Update city for purchase information
UPDATE	DataWarehouse..City
SET	CityName = ISNULL(SUPPMST.P_CITY, '')
FROM	Source..SUPPMST SUPPMST
	INNER JOIN DataWarehouse..City City
		ON SUPPMST.P_CITY = City.CityCode
WHERE	City.CityName != ISNULL(SUPPMST.P_CITY, '')


GO
