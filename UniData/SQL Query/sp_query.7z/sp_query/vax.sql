INSERT	DataWarehouse_VAX..PurchaseReceipt_2000
	(SupplierCode
,	SupplierName
,	WarehouseCode
,	WarehouseName
,	PurchaseOrderNumber
,	BillOfLadingNumber
,	ReceivingNumber
,	DateReceived
,	ProductCode
,	ProductName
,	ReceiveQuantity
,	FiscalPeriodCode
,	FreightCarrierCode
,	FreightCarrierName)
SELECT	ISNULL(LEFT(PurchaseReceipt.Supplier, CHARINDEX('-', PurchaseReceipt.Supplier) - 1), '')
,	ISNULL(RIGHT(PurchaseReceipt.Supplier, LEN(PurchaseReceipt.Supplier) - (CHARINDEX('-', PurchaseReceipt.Supplier) - 1)), '')
,	ISNULL(LEFT(PurchaseReceipt.Warehouse, CHARINDEX('-', PurchaseReceipt.Warehouse) - 1), '')
,	ISNULL(RIGHT(PurchaseReceipt.Warehouse, LEN(PurchaseReceipt.Warehouse) - (CHARINDEX('-', PurchaseReceipt.Warehouse) - 1)), '')
,	ISNULL(PurchaseReceipt.PurchaseOrderNumber, '')
,	ISNULL(PurchaseReceipt.BillOfLadingNumber, '')
,	ISNULL(PurchaseReceipt.ReceivingNumber, '')
,	ISNULL(PurchaseReceipt.DateReceived, '1900')
,	ISNULL(LEFT(PurchaseReceipt.Product, CHARINDEX('-', PurchaseReceipt.Product) - 1), '')
,	ISNULL(RIGHT(PurchaseReceipt.Product, LEN(PurchaseReceipt.Product) - (CHARINDEX('-', PurchaseReceipt.Product) - 1)), '')
,	ISNULL(CAST(PurchaseReceipt.ReceiveQuantity AS NUMERIC(19, 9)), 0)
,	ISNULL(PurchaseReceipt.FiscalPeriodCode, '')
,	ISNULL(LEFT(PurchaseReceipt.FreightCarrier, CHARINDEX('-', PurchaseReceipt.FreightCarrier) - 1), '')
,	ISNULL(RIGHT(PurchaseReceipt.FreightCarrier, LEN(PurchaseReceipt.FreightCarrier) - (CHARINDEX('-', PurchaseReceipt.FreightCarrier) - 1)), '')
FROM	Source_VAX..PurchaseReceipt PurchaseReceipt
WHERE	CAST(PurchaseReceipt.FiscalPeriodCode AS SMALLINT) BETWEEN 1 AND 12

